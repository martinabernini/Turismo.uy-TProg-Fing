package logica.datatypes;

import java.util.Arrays;
import java.util.Date;
import java.util.Objects;

public class DtActividadTuristica {

    private String nombre;
    private String descripcion;
    private int duracionHrs;
    private float costoPorPersona;
    private String ciudad;
    private Date fechaAlta;
    private String departamento;
    private String proovedor;
    private String[] salidas;
    private String[] paquetes;
    private String imagen;
    private String[] categorias;
    private EnumEstadoActividad estado = EnumEstadoActividad.AGREGADA;

    public DtActividadTuristica() {
    }

    // ----------------------------------------------------------------
    // Getters y Setters
    // ----------------------------------------------------------------

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getDuracionHrs() {
        return duracionHrs;
    }

    public void setDuracionHrs(int duracionHrs) {
        this.duracionHrs = duracionHrs;
    }

    public float getCostoPorPersona() {
        return costoPorPersona;
    }

    public void setCostoPorPersona(float costoPorPersona) {
        this.costoPorPersona = costoPorPersona;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Date getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public String[] getSalidas() {
        return salidas;
    }

    public void setSalidas(String[] salidas) {
        this.salidas = salidas;
    }

    public String[] getPaquetes() {
        return paquetes;
    }

    public void setPaquetes(String[] paquetes) {
        this.paquetes = paquetes;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getProovedor() {
        return proovedor;
    }

    public void setProovedor(String proovedor) {
        this.proovedor = proovedor;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String[] getCategorias() {
        return categorias;
    }

    public void setCategorias(String[] categorias) {
        this.categorias = categorias;
    }

    public EnumEstadoActividad getEstado() {
        return estado;
    }

    public void setEstado(EnumEstadoActividad estado) {
        this.estado = estado;
    }

    // ----------------------------------------------------------------

    @Override
    public String toString() {
        return "DtActividadTuristica [nombre=" + nombre + ", descripcion=" + descripcion + ", duracionHrs="
                + duracionHrs + ", costoPorPersona=" + costoPorPersona + ", ciudad=" + ciudad + ", fechaAlta="
                + fechaAlta + ", salidas=" + Arrays.toString(salidas) + ", paquetes=" + Arrays.toString(paquetes)
                + ", departamento=" + departamento + ", proovedor=" + proovedor + "Imagen=" + imagen + "Estado=" + estado + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DtActividadTuristica other = (DtActividadTuristica) obj;
        return Objects.equals(ciudad, other.ciudad) && costoPorPersona == other.costoPorPersona
                && Objects.equals(departamento, other.departamento) && Objects.equals(descripcion, other.descripcion)
                && duracionHrs == other.duracionHrs && Objects.equals(fechaAlta, other.fechaAlta)
                && Objects.equals(nombre, other.nombre)
                && Objects.equals(proovedor, other.proovedor)
                && (Arrays.equals(paquetes, other.paquetes) || paquetes == null && other.paquetes.length == 0
                || other.paquetes == null && paquetes.length == 0)
                && (Arrays.equals(salidas, other.salidas) || salidas == null && other.salidas.length == 0
                || other.salidas == null && salidas.length == 0);
    }
}
