package logica.datatypes;

import java.util.Date;
import java.util.Objects;

public class DtUsuario {
	private String nickname;
	private String nombre;
	private String apellido;
	private String email;
	private Date fechaNacimiento;
	private String imagen;
	private String password;

	public DtUsuario() {
	}
	
	public DtUsuario(String nickname, String nombre, String apellido, String email, Date fechaNacimiento, String imagen, String password) {
		super();
		this.nickname = nickname;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.fechaNacimiento = fechaNacimiento;
		this.imagen= imagen;
		this.password= password;
	}

	// ----------------------------------------------------------------
	// Getters y Setters
	// ----------------------------------------------------------------


	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	
	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	// ---------------------------------------------------------------


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtUsuario other = (DtUsuario) obj;
		return Objects.equals(apellido, other.apellido) && Objects.equals(email, other.email)
				&& Objects.equals(fechaNacimiento, other.fechaNacimiento) && Objects.equals(nickname, other.nickname)
				&& Objects.equals(nombre, other.nombre);
	}

	@Override
	public String toString() {
		return "DtUsuario [nickname=" + nickname + ", password=" + password + ", nombre=" + nombre + ", apellido=" + apellido + ", email=" + email
				+ ", fechaNacimiento=" + fechaNacimiento + ", imagen=" + imagen  + "] ";
	}
	
	
	
	
	
	
}
