package logica.datatypes;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import logica.entidades.CompraPaquete;


public class DtTurista extends DtUsuario {

	private String nacionalidad;

	private Map<Integer, DtInscripcionSalida> inscripcionesASalidas = new HashMap<>();

	private Map<String, CompraPaquete> comprasPaquetes = new HashMap<String, CompraPaquete>();

	public DtTurista() {
		super();
	}

	// ----------------------------------------------------------------
	// Getters y Setters
	// ----------------------------------------------------------------

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String[] getInscripcionesASalidas() {
		String[] res = new String[inscripcionesASalidas.size()];

		int idx = 0;
		for (DtInscripcionSalida salida : inscripcionesASalidas.values()) {
			res[idx] = salida.getNombreSalidaTuristica();
			idx++;
		}
		return res;
	}
	
	public DtInscripcionSalida[] getDtInscripcionesASalidas() {
		DtInscripcionSalida[] res = new DtInscripcionSalida[inscripcionesASalidas.size()];

		int idx = 0;
		for (DtInscripcionSalida salida : inscripcionesASalidas.values()) {
			res[idx] = salida;
			idx++;
		}
		return res;
	}

	public Map<String, CompraPaquete> getComprasPaquetes() {
		return comprasPaquetes;
	}
	public DtCompraPaquete[] getComprasPaquetesDataType() {
		DtCompraPaquete[] res = new DtCompraPaquete[comprasPaquetes.size()];
		int idx = 0;
		for (CompraPaquete paquete : comprasPaquetes.values()) {
			res[idx] = paquete.newDataType();
			System.out.println(res[idx].toString());
			idx++;
		}
		return res;
	}

	public void setComprasPaquetes(Map<String, CompraPaquete> comprasPaquetes) {
		this.comprasPaquetes = comprasPaquetes;
	}

	public void setInscripcionesASalidas(Map<Integer, DtInscripcionSalida> inscripcionesASalidas) {
		this.inscripcionesASalidas = inscripcionesASalidas;
	}

	// ---------------------------------------------------------------

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtTurista other = (DtTurista) obj;
		return ((Objects.equals(inscripcionesASalidas, other.inscripcionesASalidas)
				|| inscripcionesASalidas == null && (other.inscripcionesASalidas.isEmpty())
				|| inscripcionesASalidas.isEmpty() && other.inscripcionesASalidas == null)
				) && Objects.equals(nacionalidad, other.nacionalidad);
	}

	@Override
	public String toString() {
		return "DtTurista [" + super.toString() + " nacionalidad=" + nacionalidad + ", inscripcionesASalidas="
				+ inscripcionesASalidas + "]";
	}

}
