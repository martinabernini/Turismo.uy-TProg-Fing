package logica.datatypes;

public enum EnumEstadoActividad {
    AGREGADA, CONFIRMADA, RECHAZADA
}
