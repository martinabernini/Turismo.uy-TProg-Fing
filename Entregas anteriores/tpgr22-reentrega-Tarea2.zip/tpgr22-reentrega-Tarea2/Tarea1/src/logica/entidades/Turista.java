package logica.entidades;

import java.util.HashMap;
import java.util.Map;

import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;

public class Turista extends Usuario {

	private String nacionalidad;
	private Map<Integer, InscripcionSalida> inscripciones = new HashMap<>();
	private Map<String, CompraPaquete> comprasPaquetes = new HashMap<String, CompraPaquete>();

	public Turista() {
		super();
	}


	// ----------------------------------------------------------------
	// Getters y setters
	// ----------------------------------------------------------------

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public Map<Integer, InscripcionSalida> getInscripciones() {
		return inscripciones;
	}

	public Map<String, CompraPaquete> getComprasPaquetes() {
		return comprasPaquetes;
	}

	public void agregarCompraPaquete(CompraPaquete compra) {
		comprasPaquetes.put(compra.getIdentificador(), compra);
	}

	public boolean yaComproPaquete(String nombrePaquete) {
		return comprasPaquetes.containsKey(nombrePaquete);
	}

	// -----------------------------------------------------------------

	public void agregarInscripcionASalida(InscripcionSalida inscripcion) {
		this.inscripciones.put(inscripcion.getIdentificador(), inscripcion);
	}

	public DtUsuario newDataType() {

		DtTurista dtTurista = new DtTurista();

		dtTurista.setNickname(this.getNickname());
		dtTurista.setNombre(this.getNombre());
		dtTurista.setApellido(this.getApellido());
		dtTurista.setEmail(this.getEmail());
		dtTurista.setFechaNacimiento(this.getFechaNacimiento());
		
		Map<Integer, DtInscripcionSalida> dtInscripciones = new HashMap<>();
		
		dtTurista.setNacionalidad(this.getNacionalidad());
		for (InscripcionSalida inscripcion : this.getInscripciones().values()) {
				DtInscripcionSalida dtInscripcion = inscripcion.newDataType();
				dtInscripcion.setNickname(this.getNickname());
				dtInscripciones.put(inscripcion.getIdentificador(), dtInscripcion);
		}
		
		dtTurista.setInscripcionesASalidas(dtInscripciones);
		dtTurista.setImagen(this.getImagen());
		dtTurista.setPassword(this.getPassword());
		dtTurista.setComprasPaquetes(this.getComprasPaquetes());

		return dtTurista;

	}

	@Override
	public String toString() {
		return "Turista [nacionalidad=" + nacionalidad + ", inscripciones=" + inscripciones + ", paquetes=" + comprasPaquetes
				+ ", nickname=" + this.getNickname() + ", nombre=" + this.getNombre() + ", apellido=" + this.getApellido() + ", email=" + this.getApellido()
				+ ", fechaNacimiento=" + this.getFechaNacimiento() + ", imagen=" + this.getImagen() + ", password=" + this.getPassword() + "]";
	}



	// -----------------------------------------------------------------

}
