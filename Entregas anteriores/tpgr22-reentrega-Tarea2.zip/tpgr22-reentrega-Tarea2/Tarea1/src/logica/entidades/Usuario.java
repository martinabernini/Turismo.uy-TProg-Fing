package logica.entidades;

import java.util.Date;

import logica.datatypes.DtUsuario;

public abstract class Usuario {
	
	private String nickname;
	private String nombre;
	private String apellido;
	private String email;
	private Date fechaNacimiento;
	private String imagen;
	private String password;

	public Usuario() {
	}
	
	public Usuario(String nickname, String nombre, String apellido, String email, Date fechaNacimiento, String imagen, String password) {
		this.nickname = nickname;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.fechaNacimiento = fechaNacimiento;
		this.imagen=imagen;
		this.password=password;
	}

	// -----------------------------------------------------------------
	// Getters y Setters
	// -----------------------------------------------------------------

	public String getNickname() {
		return nickname;
	}
	
	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public String getImagen() {
		return imagen;
	}

	public String getPassword() {
		return password;
	}
	
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setFechaNacimiento(Date fecha) {
		this.fechaNacimiento = fecha;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	// -----------------------------------------------------------------
	public abstract DtUsuario newDataType();

	@Override
	public String toString() {
		return "Usuario [nickname=" + nickname + ", password=" + password + ", nombre=" + nombre + ", apellido=" + apellido + ", email=" + email
				+ ", fechaNacimiento=" + fechaNacimiento + ", imagen=" + imagen  + "]";
	}
	
}
