package logica.entidades;

import logica.datatypes.DtCompraPaquete;

import java.util.Date;
import java.util.Objects;

public class CompraPaquete {

    private String identificador;
    private Date fechaCompra;
    private int cantidadTuristas;
    private int salidasDisponibles;
    private Date validoHasta;
    private float costoTotal;
    private PaqueteActividades paquete;

    public CompraPaquete() {
    }

    // ------------------------------------------------------------------------
    // Getters y Setters
    // ------------------------------------------------------------------------


    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public Date getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(Date fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public int getCantidadTuristas() {
        return cantidadTuristas;
    }

    public void setCantidadTuristas(int cantidadTuristas) {
        this.cantidadTuristas = cantidadTuristas;
    }

    public int getSalidasDisponibles() {
        return salidasDisponibles;
    }

    public void setSalidasDisponibles(int salidasDisponibles) {
        this.salidasDisponibles = salidasDisponibles;
    }

    public Date getValidoHasta() {
        return validoHasta;
    }

    public void setValidoHasta(Date validoHasta) {
        this.validoHasta = validoHasta;
    }

    public float getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(float costoTotal) {
        this.costoTotal = costoTotal;
    }

    public PaqueteActividades getPaquete() {
        return paquete;
    }

    public void setPaquete(PaqueteActividades paquete) {
        this.paquete = paquete;
    }

    // ------------------------------------------------------------------------

    public void agregarSalida(SalidaTuristica salida) {
        this.salidasDisponibles--;
    }

    public void quitarSalida(SalidaTuristica salida) {
        this.salidasDisponibles++;
    }

    public void agregarTurista() {
        this.cantidadTuristas++;
    }

    public void quitarTurista() {
        this.cantidadTuristas--;
    }

    public void calcularCostoTotal() {
        this.costoTotal = this.paquete.calularCosto() * this.cantidadTuristas;
    }


    // ------------------------------------------------------------------------

    public DtCompraPaquete newDataType() {

        DtCompraPaquete dtCompraPaquete = new DtCompraPaquete();

        dtCompraPaquete.setNombrePaquete(this.getIdentificador());
        dtCompraPaquete.setFechaCompra(this.getFechaCompra());
        dtCompraPaquete.setPrecio(this.getCostoTotal());
        dtCompraPaquete.setValidoHasta(this.getValidoHasta());
        dtCompraPaquete.setCantidadTuristas(this.getCantidadTuristas());
        dtCompraPaquete.setSalidasDisponibles(this.getSalidasDisponibles());

        return dtCompraPaquete;

    }

    @Override
    public int hashCode() {
        return Objects.hash(cantidadTuristas, costoTotal, fechaCompra, identificador, paquete, salidasDisponibles,
                validoHasta);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CompraPaquete other = (CompraPaquete) obj;
        return cantidadTuristas == other.cantidadTuristas
                && Float.floatToIntBits(costoTotal) == Float.floatToIntBits(other.costoTotal)
                && Objects.equals(fechaCompra, other.fechaCompra) && identificador == other.identificador
                && Objects.equals(paquete, other.paquete) && salidasDisponibles == other.salidasDisponibles
                && Objects.equals(validoHasta, other.validoHasta);
    }

    @Override
    public String toString() {
        return "CompraPaquete [identificador=" + identificador + ", fechaCompra=" + fechaCompra + ", cantidadTuristas="
                + cantidadTuristas + ", salidasDisponibles=" + salidasDisponibles + ", validoHasta=" + validoHasta
                + ", costoTotal=" + costoTotal + ", paquete=" + paquete.getNombre() + ", costoPaquete=" + paquete.calularCosto() + "]";
    }


}
