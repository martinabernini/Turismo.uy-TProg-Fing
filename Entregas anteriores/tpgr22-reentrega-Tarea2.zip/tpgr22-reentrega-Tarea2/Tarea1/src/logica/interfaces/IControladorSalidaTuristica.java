package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.MaximoDeTuristasAlcanzadoException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtSalidaTuristica;

public interface IControladorSalidaTuristica {
	
	void darDeAltaSalidaTuristica(DtSalidaTuristica nuevaSalida) throws CampoInvalidoException, EntidadRepetidaException ;
	
	String[] listarSalidasAsociadasAActividadTuristica(String nombreActividad) throws NoHayEntidadesParaListarException, CampoInvalidoException;
	
	DtSalidaTuristica getSalidaTuristica(String nombre) throws EntidadNoExisteException, CampoInvalidoException;
	
	String[] listarSalidasVigentesAsociadasAActividadTuristica(String nombreActividad) throws NoHayEntidadesParaListarException, CampoInvalidoException ;
	
	void inscribirTuristaASalidaTuristica(DtInscripcionSalida nuevaInscripcion) throws EntidadRepetidaException, CampoInvalidoException, MaximoDeTuristasAlcanzadoException;
	
}
