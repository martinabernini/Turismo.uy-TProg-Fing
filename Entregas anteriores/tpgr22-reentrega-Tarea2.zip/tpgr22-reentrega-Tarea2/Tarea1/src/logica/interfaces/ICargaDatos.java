package logica.interfaces;

public interface ICargaDatos {

	void cargar();
	
}
