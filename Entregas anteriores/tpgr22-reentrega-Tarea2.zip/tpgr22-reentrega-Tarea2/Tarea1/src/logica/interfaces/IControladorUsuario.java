package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtUsuario;

public interface IControladorUsuario {
	
	void darDeAltaUsuario(DtUsuario nuevoUsuario) throws CampoInvalidoException, EntidadRepetidaException;
	
	String[] listarUsuarios() throws NoHayEntidadesParaListarException;
	
	DtUsuario getUsuario(String nickname) throws EntidadNoExisteException, CampoInvalidoException;

	DtUsuario getUsuarioLogin(String nicknameOrEmail) throws EntidadNoExisteException, CampoInvalidoException;

	void modificarUsuario(DtUsuario usuarioModificado) throws CampoInvalidoException;
	
	String[] listarTuristas() throws NoHayEntidadesParaListarException;
	
	String[] listarProveedores() throws NoHayEntidadesParaListarException;

	boolean esLoginValido(String nicknameOrEmail, String password);

}
