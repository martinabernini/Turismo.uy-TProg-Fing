package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
//import logica.datatypes.DtInscripcionSalida;

public interface IControladorActividadTuristica {

    void darDeAltaActividadTuristica(DtActividadTuristica nuevaActividad)
            throws CampoInvalidoException, EntidadRepetidaException;

    String[] listarActividadesAsociadasADepartamento(String nombre)
            throws NoHayEntidadesParaListarException, CampoInvalidoException;

    String[] listarActividadesAsociadasADepartamentoConfirmadas(String nombre)
            throws NoHayEntidadesParaListarException, CampoInvalidoException;

    String[] listarActividadesAsociadasACategoriaConfirmadas(String nombre)
            throws NoHayEntidadesParaListarException, CampoInvalidoException;

    DtActividadTuristica getActividadTuristica(String nombre)
            throws EntidadNoExisteException, CampoInvalidoException;

    String[] listarActividadesAsocadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete)
            throws NoHayEntidadesParaListarException, CampoInvalidoException;

    String[] listarAllActividades()
            throws NoHayEntidadesParaListarException;

    String[] listarActividadesEnEstadoAgregada()
            throws NoHayEntidadesParaListarException;

    String[] listarActividadesEnEstadoConfirmada()
            throws NoHayEntidadesParaListarException;


    String[] listarActividadesDeProveedorNoConfirmadas(String nombreProveedor)
            throws NoHayEntidadesParaListarException, CampoInvalidoException;


    void darDeAltaCategoria(String nombre) throws EntidadRepetidaException, CampoInvalidoException;

    public String[] listarTodasLasCategorias() throws NoHayEntidadesParaListarException;

    void rechazarAceptarActividad(String nombre, boolean aceptada) throws EntidadNoExisteException, CampoInvalidoException;

}
