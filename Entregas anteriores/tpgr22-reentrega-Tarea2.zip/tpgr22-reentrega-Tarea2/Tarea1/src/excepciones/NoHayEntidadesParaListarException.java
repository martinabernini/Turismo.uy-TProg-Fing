package excepciones;

public class NoHayEntidadesParaListarException extends Exception {
	public NoHayEntidadesParaListarException(String string) {
		super(string);
	}
	
}
