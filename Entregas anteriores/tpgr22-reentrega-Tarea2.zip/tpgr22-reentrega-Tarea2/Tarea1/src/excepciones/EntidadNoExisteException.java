package excepciones;

public class EntidadNoExisteException extends Exception {
    public EntidadNoExisteException(String string) {
        super(string);
    }
}
