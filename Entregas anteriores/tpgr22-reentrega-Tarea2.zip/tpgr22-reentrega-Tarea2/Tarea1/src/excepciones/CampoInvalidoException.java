package excepciones;

public class CampoInvalidoException extends Exception  {
    
	public CampoInvalidoException(String string) {
        super(string);
    }
	
}
