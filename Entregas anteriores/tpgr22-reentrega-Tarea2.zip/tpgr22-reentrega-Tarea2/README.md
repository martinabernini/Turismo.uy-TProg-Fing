# Tprog Tarea 1:

## Cosas para hacer

### Casos de uso
#### Mayor prioridad
Primera semana:

- [ ] Inicio/cierre de sesión
  - Crear en el servidor web 
- [ ] Alta de usuario 
  - Actualizar lógica: agregar imagen y password
  - Actualizar presentación: agregar imagen y password
  - Actualizar tests: agregar imagen y password
  - Crear la parte del servidor web
- [ ] Consulta de usuario
  - Actualizar lógica: agregar imagen
  - Actualizar presentación: agregar imagen
  - Actualizar tests: agregar imagen y password
  - Crear la parte del servidor web
- [ ] Alta de Categoría 
  - Crear presentación en swing
  - Crear lógica en servidor web
- [ ] Aceptar o rechazar una Actividad Turística
  - Crear presentación en swing
  - Crear lógica en servidor web

Segunda semana:
- [ ] Alta de Actividad Turística
  - Actualizar lógica: agregar imagen 
  - Actualizar presentación en swing
  - Crear lógica en servidor web
- [ ] Consulta de Actividad Turística
  - Actualizar lógica: agregar imagen 
  - Actualizar presentación en swing
  - Crear lógica en servidor web
- [ ] Alta de Salida
  - Crear lógica en servidor web
- [ ] Consulta de Salida
  - Crear lógica en servidor web
- [ ] Inscripción a Salida
  - Crear lógica en servidor web


---
Menor prioridad
- [ ] Modificar datos de usuario
  - Actualizar lógica: agregar imagen y password
  - Actualizar presentación: agregar imagen y password
  - Actualizar tests: agregar imagen y password
  - Crear la parte del servidor web
- [ ] Agregar actividades turísticas a Paquete  (opcional)
- [ ] Todas las de paquetes

---


## Cambios
### Resumen
- [ ] Controlador Usuario
- [ ] Controlador Actividad
- [ ] Controlador Salida
- [ ] Controlador Categoriad

- [ ] Controlador paquete (no es obligatorio)

### Modelo de dominio
- Usuario
  - [x] se agrega: password
  - [x] se agrega: imagen
- Actividad Turistica
  - [x] se agrega: estado
  - [x] se agrega: imagen
  - [x] se agrega: link a categoria
  
- [x] Categoria (se crea)

- [x] se agrega: EnumeradoEstadoActividad

### Datatypes
- DtUsuario
  - [x] se agrega: password
  - [x] se agrega: imagen
- DtActividadTuristica
  - [x] se agrega: estado
  - [x] se agrega: categoria
  - [x] se agrega: imagen

### DCD
- Controlador Actividad Turistica
  - [x] se agrega: darDeAltaCategoria(nombre: String)
  - [x] se agrega: rechazarAceptarActividadTuristica(actividad: DtActividadTuristica , aceptar: bool)

- Se crea:
  - [x] ManejadorCategoria
  - [x] IManejadorCategoria

- Actividad Turistica (entidad)
  - [x] Se le agrega metodo listarCategorias()
  
 
### Otros
- [ ] actualizar validador
- [ ] actualizar swing (proximamente...)

---
# TODOs
- [ ] actualizar equals
- [ ] actualizar toString
---

## Progreso

### Casos de Uso:
- Alta de Usuario
  - [x] Implementar
  - [x] Testear
- Consulta de Usuario
    - [x] Implementar
    - [x] Testear
- Modificar datos de Usuario - OPCIONAL
  - [x] Implementar
  - [x] Testear
- Alta de Actividad Turística
    - [x] Implementar
    - [x] Testear
- Consulta de Actividad Turística
    - [x] Implementar
    - [x] Testear
- Alta de Salida Turística
  - [x] Implementar
  - [x] Testear
- Consulta de Salida Turística
    - [x] Implementar
    - [x] Testear
- Inscripcion a Salida Turística
  - [x] Implementar
  - [x] Testear
- Crear Paquete de Actividades Turísticas - OPCIONAL
    - [ ] Implementar
    - [ ] Testear
- Agregar Actividad Turística a Paquete - OPCIONAL
  - [ ] Implementar
  - [ ] Testear
- Consulta de Paquete de Actividades Turísticas - OPCIONAL
    - [ ] Implementar
    - [ ] Testear
- Alta de Departamento
    - [x] Implementar (SOLO LÓGICA)
    - [x] Testear


---

### Controlador Usuario:
- darDeAltaUsuario(nuevoUsuario: DtUsuario)
  - [x] Implementar
  - [x] Testear
- listarUsuarios(): Set(String)
    - [x] Implementar
    - [x] Testear
- getUsuario(nickname: String): DtUsuario
  - [x] Implementar
  - [x] Testear
- modificarUsuario(usuarioModificado: DtUsuario)
    - [x] Implementar
    - [x] Testear
- listarTuristas(): Set(String)
  - [x] Implementar
  - [x] Testear
- listarProveedores(): Set(String)
    - [x] Implementar
    - [x] Testear

### Controlador Actividad Turística 
***(Falta implementar alguno chequeos de validez)***

- darDeAltaActividadTuristica(nuevaActividad: DtActividadTuristica)
  - [x] Implementar
  - [x] Testear
- listarActividadesAsociadasADepartamento(nombreDepartamento: String): Set(String)
    - [x] Implementar
    - [x] Testear
- getActividadTuristica(nombre: String): DtActividadTuristica
  - [x] Implementar
  - [x] Testear
- listarActividadesAsociadasADepartamentoNoEnPaquete(nombreDepartamento: String, nombrePaquete:String): Set(String)
    - [x] Implementar
    - [x] Testear

### Controlador Departamento
- listarDepartamentos(): Set(String)
  - [x] Implementar
  - [x] Testear
- darDeAltaDepartamento(nombre: String, descripcion: String, url: URL)
    - [x] Implementar
    - [x] Testear

### Controlador Salida Turística
- darDeAltaSalidaTuristica(nuevaSalida: DtSalidaTuristica) 
  - [x] Implementar    **(falta checkear la validez de las fechas)**
  - [x] Testear
- listarSalidasAsociadasAActividadTuristica(nombreActividad: String): Set(String)
    - [x] Implementar
    - [x] Testear
- getSalidaTuristica(nombre: String): DtSalidaTuristica
  - [x] Implementar
  - [x] Testear
- listarSalidasVigentesAsociadasAActividadTuristica(nombreActividad: String): Set(String)
    - [x] Implementar    **(falta ver como se calcula la validez)**
    - [x] Testear
- inscribirTuristaASalidaTuristica(nuevaInscripcion: DtInscipcionSalida)
    - [x] Implementar  
    - [x] Testear

### Controlador Paquete Actividades
- darDeAltaPaquete(nuevoPaquete: DtPaqueteActvididades)
  - [ ] Implementar
  - [ ] Testear
- listarPaquetes(): Set(String)
    - [ ] Implementar
    - [ ] Testear
- ingresarActividadTuristicaAPaquete(nombreActividad: String, nombrePaquete: String)
  - [ ] Implementar
  - [ ] Testear
- getPaquete(nombre: String): DtPaquete
    - [ ] Implementar
    - [ ] Testear

---

### Data Types
- DtActividadTuristica
  - [x] Implementar
  - [ ] Testear
- DtInscipcionSalida
    - [x] Implementar
    - [ ] Testear
- DtProveedor
  - [x] Implementar
  - [ ] Testear
- DtSalidaTuristica
    - [x] Implementar
    - [ ] Testear
- DtTurista
  - [x] Implementar
  - [ ] Testear
- DtUsuario
    - [x] Implementar
    - [ ] Testear

---
### Entidades
- [x] ActividadTuristica
- [ ] CompraPaquete
- [x] Departamento
- [x] InscripcionSalida 
- [x] PaqueteActividades
- [x] Proveedor
- [x] SalidaTuristica
- [x] Turista
- [x] Usuario
---

### Manejadores:
- [x] Manejador Usuario
- [x] Manejador Actividad Turística
- [x] Manejador Salida Turística
- [x] Manejador Departamento
- [x] Manejador Paquete Actividades
- [x] Manejador Inscripcion Salida

---
### Fabrica
- [x] getIControladorActividadTuristica
- [x] getIControladorActividad
- [x] getIControladorDepartamento
- [x] getIControladorPaqueteActividades
- [x] getIControladorSalidaTuristica
- [x] getIControladorUsuario

- [x] getIManejadorActividadTuristica
- [x] getIManejadorActividad
- [x] getIManejadorDepartamento
- [x] getIManejadorPaqueteActividades
- [x] getIManejadorSalidaTuristica
- [x] getIManejadorUsuario
---

## Bugs - Problemas
- [ ] 000 - ejemplo de bug abierto
- [x] ~~001 - ejemplo de bug resuelto~~
- [x] ~~002 - falta implementar chequeos de validez en controladorSalida~~
- [ ] 003 - falta implementar mensajes de error en controladorSalida
