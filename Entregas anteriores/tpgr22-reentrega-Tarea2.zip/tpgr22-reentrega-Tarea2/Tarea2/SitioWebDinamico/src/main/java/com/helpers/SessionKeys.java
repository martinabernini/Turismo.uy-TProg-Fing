package com.helpers;

public class SessionKeys {

    /*
     * Se usa para saber si el usuario está logueado o no
     */
    public static String ESTADO_SESION = "ESTADO_SESION";
    /*
     * Se usa para el DtUsuario que está logueado
     */
    public static String USUARIO_LOGUEADO = "USUARIO_LOGUEADO";

    public static String PAGINA_ANTERIOR = "PAGINA_ANTERIOR";


}
