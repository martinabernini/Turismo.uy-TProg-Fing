package com.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.helpers.ErrorHandler;
import com.helpers.EstadoSesionHelper;
import com.helpers.ImagePathHelper;
import com.helpers.RequestKeys;
import com.helpers.Endpoints;

import excepciones.*;
import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtSalidaTuristica;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IControladorSalidaTuristica;
import utils.Fabrica;


/**
 * Servlet implementation class InscripcionSalidaTuristica
 */
@WebServlet(Endpoints.INSCRIPCION_SALIDA_TURISTICA_SERVLET)
public class InscripcionSalidaTuristica extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public InscripcionSalidaTuristica() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Fabrica fabrica = Fabrica.getInstance();

        IControladorDepartamento controladorDepartamento = fabrica.getIControladorDepartamento();
        IControladorActividadTuristica controladorActividadTuristica = fabrica.getIControladorActividadTuristica();
        IControladorSalidaTuristica controladorSalidaTuristica = fabrica.getIControladorSalidaTuristica();

        ErrorHandler.guardarErrorDelQueryEnAttributeDelRequest(request);

        if (EstadoSesionHelper.hayTuristaLogueado(request)) {

            // Los posibles filtros de la búsqueda se reciben como parámetros
            // categoria, departamento, actividad

            // si no hay filtros -> se muesta la pagina de filstros de busqueda categorias y
            // departamentos
            // si hay categoria -> se muestra la lista de actividades de esa categoria
            // si hay departamento -> se muestra la lista de actividades de ese departamento
            // si hay actividad -> se muestra la lista de salidas de esa actividad para
            // inscribirse

            // si no hay filtros
            if (request.getParameter("categoria") == null && request.getParameter("departamento") == null
                    && request.getParameter("actividad") == null) {
                // se muestra la pagina de filtros de busqueda categorias y departamentos

                try {
                    String[] departamentos = controladorDepartamento.listarDepartamentos();
                    String[] categorias = controladorActividadTuristica.listarTodasLasCategorias();

                    request.setAttribute(RequestKeys.FILTRO_INSCRIPCION_SALIDA_INICIAL, true);
                    request.setAttribute(RequestKeys.LISTA_DEPARTAMENTOS, departamentos);
                    request.setAttribute(RequestKeys.LISTA_CATEGORIAS, categorias);

                    request.getRequestDispatcher("/WEB-INF/views/actividades/filtrosIncripcionSalida.jsp")
                            .forward(request, response);
                    return;

                } catch (NoHayEntidadesParaListarException e) {
                    // TODO redireccionar a pagina de error
                    ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                    return;
                }
            }

            // si hay solo categoria
            if (request.getParameter("categoria") != null && request.getParameter("departamento") == null
                    && request.getParameter("actividad") == null) {

                // se muestra la lista de actividades de esa categoria
                String categoria = request.getParameter("categoria");

                try {
                    String[] actividades = controladorActividadTuristica
                            .listarActividadesAsociadasACategoriaConfirmadas(categoria);

                    request.setAttribute(RequestKeys.FILTRO_INSCRIPCION_SALIDA_INICIAL, false);
                    request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, actividades);
                    request.getRequestDispatcher("/WEB-INF/views/actividades/filtrosIncripcionSalida.jsp")
                            .forward(request, response);
                    return;

                } catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
                    // TODO redireccionar a pagina de error
                    ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                    return;
                }
            }

            // si hay solo departamento
            if (request.getParameter("departamento") != null && request.getParameter("categoria") == null
                    && request.getParameter("actividad") == null) {

                // se muestra la lista de actividades de ese departamento
                String departamento = request.getParameter("departamento");

                try {
                    String[] actividades = controladorActividadTuristica
                            .listarActividadesAsociadasADepartamentoConfirmadas(departamento);
                    request.setAttribute(RequestKeys.FILTRO_INSCRIPCION_SALIDA_INICIAL, false);
                    request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, actividades);
                    request.getRequestDispatcher("/WEB-INF/views/actividades/filtrosIncripcionSalida.jsp")
                            .forward(request, response);
                    return;
                } catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
                    // TODO redireccionar a pagina de error
                    ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                    return;
                }
            }

            // si hay solo actividad
            if (request.getParameter("actividad") != null && request.getParameter("categoria") == null
                    && request.getParameter("departamento") == null) {


                ErrorHandler.guardarErrorDelQueryEnAttributeDelRequest(request);

                // se muestra la lista de salidas de esa actividad para inscribirse
                String actividad = request.getParameter("actividad");
                try {
                    String[] listaSalidas = controladorSalidaTuristica
                            .listarSalidasVigentesAsociadasAActividadTuristica(actividad);

                    String[] test = controladorSalidaTuristica.listarSalidasAsociadasAActividadTuristica(actividad);

                    System.out.println("HOLA MARTINA ME METI A LA INSCRIPCION");
                    
                    DtActividadTuristica actTuristica = null;
					try {
						actTuristica = controladorActividadTuristica.getActividadTuristica(actividad);
					} catch (EntidadNoExisteException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

                    java.util.List<DtSalidaTuristica> salidas = new ArrayList<>();

                    for (String salida : listaSalidas) {
                        try {
                            DtSalidaTuristica dtSalida = controladorSalidaTuristica.getSalidaTuristica(salida);
                            dtSalida.setImagen(ImagePathHelper.conPrefijo(dtSalida.getImagen()));
                            salidas.add(dtSalida);

                        } catch (EntidadNoExisteException e) {
                            // TODO redireccionar a pagina de error o no se
                            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                            return;
                        }
                    }
                    
                    
                    request.setAttribute(RequestKeys.COSTO_SALIDA, actTuristica.getCostoPorPersona());
                    request.setAttribute(RequestKeys.LISTA_SALIDAS, salidas);
                    request.getRequestDispatcher("/WEB-INF/views/actividades/inscripcionSalidaTuristica.jsp")
                            .forward(request, response);
                    return;
                } catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
                    // TODO redireccionar a pagina de error
                    ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                    return;
                }
            }

        }

        if (EstadoSesionHelper.hayProveedorLogueado(request)) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 401);
            return;
        }
        response.sendRedirect(request.getContextPath() + Endpoints.INICIAR_SESION_SERVLET);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {

        // Casos que lanza
        // inscripcion se pasa de turistas
        // ya esta inscripto

        String salidaTuristica = request.getParameter("salidaSeleccionada");
        int cantTuristas = 0;

        if (request.getParameter("cantTuristas") != null) {
            try {
                cantTuristas = Integer.parseInt(request.getParameter("cantTuristas"));
            } catch (NumberFormatException nfe) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, "La cantidad de turistas debe" +
                        " ser un numero");
                return;
            }
        }

        if (cantTuristas == 0) {
            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, "La cantidad de turistas debe ser mayor a 0");
            return;
        }

        DtInscripcionSalida inscripcion = new DtInscripcionSalida();

        inscripcion.setCantidadTuristas(cantTuristas);
        inscripcion.setNombreSalidaTuristica(salidaTuristica);
        inscripcion.setFechaInscripcion(new Date());
        inscripcion.setNickname(EstadoSesionHelper.getUsuarioLogueado(request).getNickname());

        try {
            Fabrica.getInstance().getIControladorSalidaTuristica().inscribirTuristaASalidaTuristica(inscripcion);

        } catch (EntidadRepetidaException | CampoInvalidoException | MaximoDeTuristasAlcanzadoException e) {
            request.setAttribute(RequestKeys.ERROR, e.getMessage());

            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());

            return;
        }

        response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);

    }


}
