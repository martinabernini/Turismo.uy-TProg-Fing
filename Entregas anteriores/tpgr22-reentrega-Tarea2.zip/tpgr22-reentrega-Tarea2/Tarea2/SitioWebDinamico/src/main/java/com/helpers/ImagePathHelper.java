package com.helpers;

public class ImagePathHelper {
	
	public static String conPrefijo(String filepath) {
		return Endpoints.DISPLAY_IMAGE + "?identificador=media/img/" + filepath;
	}

}
