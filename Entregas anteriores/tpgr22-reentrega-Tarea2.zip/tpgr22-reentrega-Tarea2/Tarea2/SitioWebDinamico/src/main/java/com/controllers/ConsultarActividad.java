package com.controllers;

import com.helpers.*;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.*;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IControladorSalidaTuristica;
import utils.Fabrica;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class ConsultaUsuario
 */
@WebServlet("/ConsultarActividad")
public class ConsultarActividad extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final IControladorActividadTuristica controladorActividadTuristica = Fabrica.getInstance().getIControladorActividadTuristica();
    private static final IControladorSalidaTuristica controladorSalidaTuristica = Fabrica.getInstance().getIControladorSalidaTuristica();
    private static final IControladorPaqueteActividades controladorPaquete = Fabrica.getInstance().getIControladorPaqueteActividades();


    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarActividad() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        String actividad = request.getParameter("actividad"); // viene del query string

        try {
            DtActividadTuristica act = controladorActividadTuristica.getActividadTuristica(actividad);
            act.setImagen(ImagePathHelper.conPrefijo(act.getImagen()));

            request.setAttribute(RequestKeys.ACTIVIDAD_CONSULTA, act);
            try {
                String[] salidas = controladorSalidaTuristica.listarSalidasAsociadasAActividadTuristica(actividad);

                List<DtSalidaTuristica> listaSalidas = new ArrayList<>();

                for (String salida : salidas) {
                    listaSalidas.add(controladorSalidaTuristica.getSalidaTuristica(salida));
                }
                request.setAttribute(RequestKeys.SALIDAS_ACTIVIDAD_A_CONSULTAR, listaSalidas);

            } catch (NoHayEntidadesParaListarException e) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                return;
            }

            String[] paquetes = act.getPaquetes();
            List<DtPaqueteActividades> listaPaquetes = new ArrayList<>();

            for (String paquete : paquetes) {
                try {
                    listaPaquetes.add(controladorPaquete.find(paquete));
                } catch (EntidadNoExisteException e) {
                }
            }

            request.setAttribute(RequestKeys.LISTA_PAQUETES_ACT, listaPaquetes);


        } catch (EntidadNoExisteException | CampoInvalidoException e) {
            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/actividades/consultarActividad/consultarActividad.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

