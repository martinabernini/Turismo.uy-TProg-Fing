package com.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.helpers.*;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

/**
 * Servlet implementation class ConsultarPaquetes
 */
@WebServlet(Endpoints.CONSULTAR_PAQUETES_SERVLET)
public class ConsultarPaquetes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarPaquetes() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");
        
        IControladorPaqueteActividades controladorPaquete = Fabrica.getInstance().getIControladorPaqueteActividades();
        
        String[] paquetes;
		try {
			paquetes = controladorPaquete.listarPaquetes();
			
			List<DtPaqueteActividades> listaPaquetes = new ArrayList<>();
        
        	for (String paquete : paquetes) {
        		
        		DtPaqueteActividades paqueteDt = controladorPaquete.find(paquete);
        		paqueteDt.setImagen(ImagePathHelper.conPrefijo(paqueteDt.getImagen())); //CONSEGUIR LA IMAGEN NUEVA CON PREFIJO
        		listaPaquetes.add(paqueteDt);
            }
        	
        	request.setAttribute(RequestKeys.LISTA_PAQUETES_CONSULTA, listaPaquetes);
        	request.getRequestDispatcher("/WEB-INF/views/paquetes/consultarPaquete/consultarPaquetes.jsp").forward(request, response);
        	
		} catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
			response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
		}
                   
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
