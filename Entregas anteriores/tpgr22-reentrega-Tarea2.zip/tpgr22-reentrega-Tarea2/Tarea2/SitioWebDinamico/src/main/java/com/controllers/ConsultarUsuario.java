package com.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.helpers.Endpoints;
import com.helpers.EstadoSesionHelper;
import com.helpers.ImagePathHelper;
import com.helpers.RequestKeys;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtCompraPaquete;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtSalidaTuristica;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.datatypes.EnumEstadoActividad;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

/**
 * Servlet implementation class ConsultaUsuario
 */
@WebServlet(Endpoints.CONSULTAR_USUARIO_SERVLET)
public class ConsultarUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        String nick = request.getParameter("nickname"); // viene del query string

        boolean esMiPerfil = false;
        if (EstadoSesionHelper.hayUsuarioLogueado(request)) {
            DtUsuario user = EstadoSesionHelper.getUsuarioLogueado(request);
            request.setAttribute(RequestKeys.ES_MI_PERFIL, user.getNickname().equals(nick));
            esMiPerfil = user.getNickname().equals(nick);
        } else {
            request.setAttribute(RequestKeys.ES_MI_PERFIL, esMiPerfil);
        }

        IControladorUsuario controladorUsuario = Fabrica.getInstance().getIControladorUsuario();
        IControladorSalidaTuristica controladorSalidaTuristica = Fabrica.getInstance().getIControladorSalidaTuristica();
        IControladorActividadTuristica controladorActividadTuristica = Fabrica.getInstance().getIControladorActividadTuristica();

        try {
            DtUsuario usuarioAConsultar = controladorUsuario.getUsuario(nick);

            usuarioAConsultar.setImagen(ImagePathHelper.conPrefijo(usuarioAConsultar.getImagen()));

            request.setAttribute("usuarioConsultar", usuarioAConsultar);


            if (usuarioAConsultar instanceof DtTurista) {

                String[] salidas = ((DtTurista) usuarioAConsultar).getInscripcionesASalidas();
                DtInscripcionSalida[] inscripcionSalidas = ((DtTurista) usuarioAConsultar).getDtInscripcionesASalidas();
                
                Map<String, DtInscripcionSalida> inscripciones = new HashMap<>();

                List<DtSalidaTuristica> listaSalidas = new ArrayList<>();

                for (String salida : salidas) {
                    listaSalidas.add(controladorSalidaTuristica.getSalidaTuristica(salida));
                }
                //TODO chequiar null
                for(DtInscripcionSalida inscripcion : inscripcionSalidas) {
                	inscripciones.put(inscripcion.getNombreSalidaTuristica(), inscripcion);
                }
                
                request.setAttribute(RequestKeys.SALIDAS_PERFIL_A_CONSULTAR, listaSalidas);
                request.setAttribute(RequestKeys.INSCRIPCIONES_SALIDAS_PERFIL_A_CONSULTAR, inscripciones);

                if (esMiPerfil) {
                    List<DtCompraPaquete> listaPaquetes = new ArrayList<>();

                    DtCompraPaquete[] paquetes = ((DtTurista) usuarioAConsultar).getComprasPaquetesDataType();

                    request.setAttribute(RequestKeys.LISTA_PAQUETES, paquetes);
                }

                // SI SOY UN PROVEEDOR

            } else if (usuarioAConsultar instanceof DtProveedor) {

                String[] actividades = ((DtProveedor) usuarioAConsultar).getActividadesTuristicas();

                List<DtActividadTuristica> listaActividades = new ArrayList<>();
                List<DtSalidaTuristica> listaSalidas = new ArrayList<>();

                for (String actividad : actividades) {

                	if (controladorActividadTuristica.getActividadTuristica(actividad).getEstado().equals(EnumEstadoActividad.CONFIRMADA)) {
                		listaActividades.add(controladorActividadTuristica.getActividadTuristica(actividad));
                	}
                       
                    try {
                        String[] salidas = controladorSalidaTuristica.listarSalidasVigentesAsociadasAActividadTuristica(actividad);

                        String[] test = controladorSalidaTuristica.listarSalidasAsociadasAActividadTuristica(actividad);

                        for (String salida : salidas) {
                            listaSalidas.add(controladorSalidaTuristica.getSalidaTuristica(salida));
                        }
                    } catch (NoHayEntidadesParaListarException e) {
                        // Nada
                    }
                }

                if (esMiPerfil) {

                    List<DtActividadTuristica> listaActividadesNoConfirmadas = new ArrayList<>();
                    try {

                        String[] actividadesNoConfirmadas = controladorActividadTuristica.listarActividadesDeProveedorNoConfirmadas(nick);
                        for (String actividad : actividadesNoConfirmadas) {
                            listaActividadesNoConfirmadas.add(controladorActividadTuristica.getActividadTuristica(actividad));
                        }
                    } catch (NoHayEntidadesParaListarException e) {
                    }

                    request.setAttribute(RequestKeys.ACTIVIDADES_MI_PERFIL_PROVEEDOR, listaActividadesNoConfirmadas);
                }


                request.setAttribute(RequestKeys.ACTIVIDADES_PERFIL_A_CONSULTAR_PROVEEDOR, listaActividades);
                request.setAttribute(RequestKeys.SALIDAS_PERFIL_A_CONSULTAR, listaSalidas);
            }

        } catch (EntidadNoExisteException | CampoInvalidoException e) {
            System.out.println("Error: " + e.getMessage());
            // TODO: redirigir a error 500
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
            return;
        }

        request.getRequestDispatcher("/WEB-INF/views/usuarios/perfil/perfil.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

