package com.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.helpers.Endpoints;
import com.helpers.SessionKeys;
import com.helpers.EstadoSesionHelper;
import com.model.EstadoSesion;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

/**
 * Servlet implementation class IniciarSesion
 */
@WebServlet(Endpoints.INICIAR_SESION_SERVLET)
public class IniciarSesion extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public IniciarSesion() {
        super();
        Fabrica.getInstance().getICargaDatos().cargar();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();

        if (session.getAttribute(SessionKeys.ESTADO_SESION) == EstadoSesion.LOGIN_CORRECTO) {
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
        } else {
            request.setAttribute("login-error", false);
            request.getRequestDispatcher("/WEB-INF/views/sesion/iniciarSesion.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        String usernameOrEmail = request.getParameter("login-form-nickname-email");
        String password = request.getParameter("login-form-password");

        IControladorUsuario controladorUsuario = Fabrica.getInstance().getIControladorUsuario();

        HttpSession session = request.getSession();

        if (controladorUsuario.esLoginValido(usernameOrEmail, password)) {
            EstadoSesionHelper.setEstado(request, EstadoSesion.LOGIN_CORRECTO);

            DtUsuario usuario = null;
            try {
                usuario = controladorUsuario.getUsuarioLogin(usernameOrEmail);

            } catch (EntidadNoExisteException | CampoInvalidoException ignored) {
            }
            session.setAttribute(SessionKeys.USUARIO_LOGUEADO, usuario);
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
        } else {
            // aca no uso el SessionKeys porque es una variable que quiero que viva solo duante este request
            request.setAttribute("login-error", true);
            request.getRequestDispatcher("/WEB-INF/views/sesion/iniciarSesion.jsp").forward(request, response);
        }
    }

}
