package com.controllers;

import com.helpers.*;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.*;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import utils.Fabrica;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class ConsultarSalidas
 */
@WebServlet(Endpoints.CONSULTAR_SALIDAS_SERVLET)
public class ConsultarSalidas extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarSalidas() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        IControladorActividadTuristica controladorActividadTuristica = Fabrica.getInstance().getIControladorActividadTuristica();
        IControladorSalidaTuristica controladorSalidaTuristica = Fabrica.getInstance().getIControladorSalidaTuristica();

        // Los posibles filtros de la búsqueda se reciben como parámetros
        // categoria, departamento, actividad

        // si no hay filtros -> se muesta la pagina de filstros de busqueda categorias y departamentos
        // si hay categoria -> se muestra la lista de actividades de esa categoria
        // si hay departamento -> se muestra la lista de actividades de ese departamento
        // si hay actividad -> se muestra la lista de salidas de esa actividad para
        // inscribirse

        ErrorHandler.guardarErrorDelQueryEnAttributeDelRequest(request);

        /*	-------------- SI NO HAY FILTROS NI CATEGORIAS SELECCIONADAS 	--------------  */
        // si no hay filtros
        if (request.getParameter("categoria") == null && request.getParameter("departamento") == null
                && request.getParameter("actividad") == null) {
        	
        	System.out.println("MARTINA ENTRE AL INICIO");
        	
            try {
                String[] actividades = controladorActividadTuristica.listarActividadesEnEstadoConfirmada();

                List<DtActividadTuristica> listaActividades = new ArrayList<>();

                for (String actividad : actividades) {
                    DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                    actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                    listaActividades.add(actividadDt);
                }

                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarSalida/consultarSalidasAct.jsp").forward(request, response);
                return;

            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                return;
            }
        }
        
        
        
        
        /*	-------------- SI YA SELECCIONE UNA CATEGORIA 	--------------  */
        // si hay solo categoria
        if (request.getParameter("categoria") != null && request.getParameter("departamento") == null
                && request.getParameter("actividad") == null) {

        	System.out.println("MARTINA ENTRE A CATEGORIA");
        	
            try {
                String categoria = request.getParameter("categoria");
                String[] actividades = controladorActividadTuristica.listarActividadesAsociadasACategoriaConfirmadas(categoria);
                List<DtActividadTuristica> listaActividades = new ArrayList<>();

                for (String actividad : actividades) {
                    DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                    actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                    listaActividades.add(actividadDt);
                }

                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarSalida/consultarSalidasAct.jsp").forward(request, response);
                return;
            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                return;
            }
        }
        
        
        
        
		/*	-------------- SI FILTRO POR DEPARTAMENTO 	--------------  */
        // si hay solo departamento
        if (request.getParameter("departamento") != null && request.getParameter("categoria") == null
                && request.getParameter("actividad") == null) {
        		
        	System.out.println("MARTINA ENTRE A DEPARTAMENTO");
        	
                try {
                    String departamento = request.getParameter("departamento");
                    String[] actividades = controladorActividadTuristica.listarActividadesAsociadasADepartamentoConfirmadas(departamento);
                    List<DtActividadTuristica> listaActividades = new ArrayList<>();

                    for (String actividad : actividades) {
                        DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                        actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                        listaActividades.add(actividadDt);
                    }

                    request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
                    request.getRequestDispatcher("/WEB-INF/views/actividades/consultarSalida/consultarSalidasAct.jsp").forward(request, response);
                    return;
                } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                    ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                    return;
                }
            
        }
        
        
        
        /*	-------------- SI YA SELECCIONE UNA ACTIVIDAD 	--------------  */
        // si hay solo actividad
        if (request.getParameter("actividad") != null && request.getParameter("categoria") == null && request.getParameter("departamento") == null) {
        	
        	
        	System.out.println("MARTINA ENTRE A ACTIVIDAD");
        	
        	try {
                String actividad = request.getParameter("actividad");

                String[] salidas = controladorSalidaTuristica.listarSalidasAsociadasAActividadTuristica(actividad);
                
                System.out.println(salidas.toString());
                List<DtSalidaTuristica> listaSalidas = new ArrayList<>();

                for (String salida : salidas) {
                    DtSalidaTuristica salidaDt = controladorSalidaTuristica.getSalidaTuristica(salida);
                    salidaDt.setImagen(ImagePathHelper.conPrefijo(salidaDt.getImagen()));
                    listaSalidas.add(salidaDt);
                }
                request.setAttribute(RequestKeys.LISTA_SALIDAS_CONSULTA, listaSalidas);
                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarSalida/consultarSalidas.jsp").forward(request, response);
                return;
            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
                return;
            } 

        }
        	
        
        
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
