package com.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.helpers.Endpoints;
import com.helpers.ErrorHandler;
import logica.interfaces.IControladorDepartamento;
import org.apache.tomcat.util.http.fileupload.IOUtils;

import com.helpers.EstadoSesionHelper;
import com.helpers.RequestKeys;
import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtSalidaTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorActividadTuristica;
import utils.Fabrica;

/**
 * Servlet implementation class AltaSalida
 */
@WebServlet(Endpoints.ALTA_SALIDA_SERVLET)
@MultipartConfig
public class AltaSalida extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final IControladorDepartamento controladorDepartamento = Fabrica.getInstance().getIControladorDepartamento();
    private static final IControladorActividadTuristica controladorActividad = Fabrica.getInstance().getIControladorActividadTuristica();
    private static final IControladorSalidaTuristica controladorSalida = Fabrica.getInstance().getIControladorSalidaTuristica();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AltaSalida() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ErrorHandler.guardarErrorDelQueryEnAttributeDelRequest(request);
        request.setCharacterEncoding("UTF-8");

        // Si no hay un usuario logueado, redirigir al login
        if (!EstadoSesionHelper.hayUsuarioLogueado(request)) {
            ErrorHandler.redirigirAlLogin(request, response, Endpoints.ALTA_SALIDA);
            return;
        }

        // Si hay un usuario logueado pero es un cliente, redirigir a la página de error con 401
        if (EstadoSesionHelper.hayTuristaLogueado(request)) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 401);
            return;
        }

        // Si hay un usuario logueado y es un proveedor
        // Dar a elegir en cual departamento quiere dar de alta una salida turística
        if (request.getParameter("departamento") == null) {
            try {
                String[] dptos = controladorDepartamento.listarDepartamentos();

                request.setAttribute(RequestKeys.LISTA_DEPARTAMENTOS, dptos);
                request.getRequestDispatcher("/WEB-INF/views/actividades/dptoAltaSalida.jsp").forward(request, response);

            } catch (NoHayEntidadesParaListarException e) {
                ErrorHandler.redirigirConErrorSinMantenerQueryString(request, response, e.getMessage());
            }
            return;
        }

        try {
            String nombreDpto = request.getParameter("departamento");
            String[] actividades = controladorActividad.listarActividadesAsociadasADepartamentoConfirmadas(nombreDpto);

            request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, actividades);
            request.getRequestDispatcher("/WEB-INF/views/actividades/altaSalida.jsp").forward(request, response);

        } catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
            ErrorHandler.redirigirConErrorSinMantenerQueryString(request, response, e.getMessage());
        }

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        if (!EstadoSesionHelper.hayProveedorLogueado(request)) {
            response.sendRedirect(request.getContextPath() + Endpoints.INICIAR_SESION_SERVLET);
            return;
        }

        String nombreAct = request.getParameter("nombreActividad");
        String nombre = request.getParameter("nombreSalida");
        int cantidad = 0;
        if (request.getParameter("cantTuristas") != null) {
            try {
                cantidad = Integer.parseInt(request.getParameter("cantTuristas"));
            } catch (NumberFormatException e) {
                ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, "revisa la cantidad de turistas");
                return;
            }
        }

        String fechaSalidastr = request.getParameter("fechaSalida");
        Date fechaSalida = null;
        try {
            fechaSalida = new SimpleDateFormat("yyyy-MM-dd").parse(fechaSalidastr);
        } catch (ParseException e1) {
            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, "La fecha es inválida");
            return;
        }
        String lugar = request.getParameter("lugarSalida");
        Part partImagen = request.getPart("imagenSalida");

        DtSalidaTuristica nuevaSalida = new DtSalidaTuristica();

        nuevaSalida.setNombreActividad(nombreAct);
        nuevaSalida.setNombreSalida(nombre);
        nuevaSalida.setCantidadMaximaTuristas(cantidad);
        nuevaSalida.setFechaAlta(new Date());
        nuevaSalida.setFechaSalida(fechaSalida);
        nuevaSalida.setLugarSalida(lugar);


        if (partImagen == null || partImagen.getSize() == 0) {
            nuevaSalida.setImagen("imagenDefaultActividad.jpg");
        } else {
            InputStream data = partImagen.getInputStream();
            String extension = "";
            int i = partImagen.getContentType().lastIndexOf('/');
            if (i > 0) {
                extension = partImagen.getContentType().substring(i + 1);
            }

            OutputStream outputStream = null;
            try {
                File file = new File("src/main/webapp/media/img/" + nombre + "." + extension);
                outputStream = new FileOutputStream(file);
                IOUtils.copy(data, outputStream);
            } finally {
                if (outputStream != null) {
                    outputStream.close();
                }
            }
            nuevaSalida.setImagen(nombre + "." + extension);
        }

        try {
            controladorSalida.darDeAltaSalidaTuristica(nuevaSalida);
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
        } catch (CampoInvalidoException | EntidadRepetidaException e) {
            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
        }

    }
}
