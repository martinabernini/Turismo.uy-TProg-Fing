package com.controllers;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.helpers.Endpoints;
import com.helpers.ErrorHandler;
import org.apache.tomcat.util.http.fileupload.IOUtils;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

/**
 * Servlet implementation class AltaUsuario
 */
@WebServlet(Endpoints.ALTA_USUARIO_SERVLET)
@MultipartConfig

public class AltaUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AltaUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

    private static final IControladorUsuario controladorUsuario = Fabrica.getInstance().getIControladorUsuario();


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getParameter("tipoUsuario") == null) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 404);
            return;
        }

        String tipo = request.getParameter("tipoUsuario");

        if (!tipo.equals("Turista") && !tipo.equals("Proveedor")) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 404);
            return;
        }

        request.getRequestDispatcher("/WEB-INF/views/usuarios/altaDeUsuario.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String tipo = request.getParameter("tipoUsuario");

        String nickname = request.getParameter("nicknameUsuario");
        String nombre = request.getParameter("nombreUsuario");
        String apellido = request.getParameter("apellidoUsuario");
        String password = request.getParameter("contrasenaUsuario");
        String email = request.getParameter("emailUsuario");
        String passwordConfirmacion = request.getParameter("contrasenaUsuarioConfimracion");

        String nacionalidad = request.getParameter("nacionalidadUsuario");
        String descripcion = request.getParameter("descripcionUsuario");

        String sitioWeb = request.getParameter("sitiowebUsuario");

        String fechaNacimientostr = request.getParameter("fechaNacimiento");
        Date fechaNacimiento = null;

        try {
            fechaNacimiento = new SimpleDateFormat("yyyy-MM-dd").parse(fechaNacimientostr);

        } catch (ParseException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        Part partImagen = request.getPart("imagenUsuario");

        if (!password.equals(passwordConfirmacion)) {
            request.setAttribute("signup-error", "ContrasenaNoCoincide");
            request.getRequestDispatcher("/WEB-INF/views/usuarios/altaDeUsuario.jsp").forward(request, response);
            return;
        }

        DtUsuario nuevoUsuario = null;

        if (tipo == null) {
            //TODO revisar esto
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
            return;
        }

        if (tipo.equals("Turista")) {

            nuevoUsuario = new DtTurista();

            nuevoUsuario.setNickname(nickname);
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellido(apellido);
            nuevoUsuario.setPassword(password);
            nuevoUsuario.setEmail(email);

            nuevoUsuario.setFechaNacimiento(fechaNacimiento);
            ((DtTurista) nuevoUsuario).setNacionalidad(nacionalidad);

        } else if (tipo.equals("Proveedor")) {

            nuevoUsuario = new DtProveedor();

            nuevoUsuario.setNickname(nickname);
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellido(apellido);
            nuevoUsuario.setPassword(password);
            nuevoUsuario.setEmail(email);

            nuevoUsuario.setFechaNacimiento(fechaNacimiento);
            ((DtProveedor) nuevoUsuario).setDescripcion(descripcion);
            ((DtProveedor) nuevoUsuario).setUrlSitioWeb(sitioWeb);

        }

        System.out.println(partImagen.getSize());

        if (partImagen.getSize() != 0) {
            InputStream data = partImagen.getInputStream();
            String extension = "";
            int i = partImagen.getContentType().lastIndexOf('/');
            if (i > 0) {
                extension = partImagen.getContentType().substring(i + 1);
            }

            OutputStream outputStream = null;
            try {
                File file = new File("src/main/webapp/media/img/" + nickname + "." + extension);
                outputStream = new FileOutputStream(file);
                IOUtils.copy(data, outputStream);
            } finally {
                if (outputStream != null) {
                    //  outputStream.close();
                }
            }

            nuevoUsuario.setImagen(nickname + "." + extension);

        } else {
            nuevoUsuario.setImagen("defaultUserImg.jpg");
        }

        try {
            controladorUsuario.darDeAltaUsuario(nuevoUsuario);
            //TODO ver si te redirige a donde
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);

        } catch (EntidadRepetidaException e) {
            request.setAttribute("signup-error", "EntidadRepetida");
            request.getRequestDispatcher("/WEB-INF/views/usuarios/altaDeUsuario.jsp").forward(request, response);

        } catch (CampoInvalidoException e) {
            request.setAttribute("signup-error", "CampoInvalido");
            request.getRequestDispatcher("/WEB-INF/views/usuarios/altaDeUsuario.jsp").forward(request, response);
        }

    }

}
