package com.controllers;

import com.helpers.*;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.entidades.Usuario;
import logica.interfaces.IControladorUsuario;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import utils.Fabrica;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ModificarUsuario
 */
@WebServlet(Endpoints.MODIFICAR_USUARIO_SERVLET)
@MultipartConfig

public class ModificarUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final IControladorUsuario controladorUsuario = Fabrica.getInstance().getIControladorUsuario();

    public ModificarUsuario() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (!EstadoSesionHelper.hayUsuarioLogueado(request)) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 401);
            return;
        }

        try {
            DtUsuario usuario = controladorUsuario.getUsuario(EstadoSesionHelper.getUsuarioLogueado(request).getNickname());
            usuario.setImagen(ImagePathHelper.conPrefijo(usuario.getImagen()));

            request.setAttribute(RequestKeys.USUARIO_A_MODIFICAR, usuario);
            request.getRequestDispatcher("/WEB-INF/views/usuarios/modificarUsuario/modificarUsuario.jsp").forward(request, response);

        } catch (EntidadNoExisteException | CampoInvalidoException e) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 404);
        }

    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {

            if (!EstadoSesionHelper.hayUsuarioLogueado(request)) {
                ErrorHandler.redirigirAPaginaDeError(request, response, 401);
                return;
            }

            Date fechaNacimiento;
            try {
                if (request.getParameter("fechaNacimiento") != null) {
                    fechaNacimiento = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("fechaNacimiento"));
                } else {
                    request.setAttribute(ErrorHandler.getRequestErrorKey(), "Fecha de nacimiento invalida");
                    doGet(request, response);
                    return;
                }

            } catch (ParseException e1) {
                request.setAttribute(ErrorHandler.getRequestErrorKey(), "Fecha de nacimiento invalida");
                doGet(request, response);
                return;
            }

            DtUsuario usuarioAModificar = null;
            try {
                usuarioAModificar = controladorUsuario.getUsuario(EstadoSesionHelper.getUsuarioLogueado(request).getNickname());

            } catch (EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirAPaginaDeError(request, response, 404);
                return;
            }

            usuarioAModificar.setNombre(request.getParameter("nombre"));
            usuarioAModificar.setApellido(request.getParameter("apellido"));
            usuarioAModificar.setFechaNacimiento(fechaNacimiento);
            usuarioAModificar.setPassword(request.getParameter("password"));

            String imagen;
            // obtengo la imagen
            Part partImagen = request.getPart("imagenUsuario");
            if (partImagen.getSize() != 0) {
                InputStream data = partImagen.getInputStream();
                String extension = "";
                int i = partImagen.getContentType().lastIndexOf('/');
                if (i > 0) {
                    extension = partImagen.getContentType().substring(i + 1);
                }

                OutputStream outputStream = null;
                try {
                    File file = new File("src/main/webapp/media/img/" + usuarioAModificar.getNickname() + "." + extension);
                    outputStream = new FileOutputStream(file);
                    IOUtils.copy(data, outputStream);
                } finally {
                    if (outputStream != null) {
                        //  outputStream.close();
                    }
                }
                imagen = usuarioAModificar.getNickname() + "." + extension;

            } else {
                imagen = "defaultUserImg.jpg";
            }
            usuarioAModificar.setImagen(imagen);


            if (EstadoSesionHelper.hayProveedorLogueado(request)) {
                DtProveedor proveedorModificado = (DtProveedor) usuarioAModificar;
                proveedorModificado.setDescripcion(request.getParameter("descripcion"));
                proveedorModificado.setUrlSitioWeb(request.getParameter("sitioWeb"));

                try {
                    controladorUsuario.modificarUsuario(proveedorModificado);
                } catch (CampoInvalidoException e) {
                    request.setAttribute(ErrorHandler.getRequestErrorKey(), e.getMessage());
                    doGet(request, response);
                    return;
                }

            }

            if (EstadoSesionHelper.hayTuristaLogueado(request)) {
                DtTurista turistaModificado = (DtTurista) usuarioAModificar;
                turistaModificado.setNacionalidad(request.getParameter("nacionalidad"));

                try {
                    controladorUsuario.modificarUsuario(usuarioAModificar);
                } catch (CampoInvalidoException e) {
                    request.setAttribute(ErrorHandler.getRequestErrorKey(), e.getMessage());
                    doGet(request, response);
                    return;
                }
            }

            try {
                DtUsuario usuarioActualizado =
                        controladorUsuario.getUsuario(EstadoSesionHelper.getUsuarioLogueado(request).getNickname());
                EstadoSesionHelper.setUsuarioLogueado(request, usuarioActualizado);
            } catch (EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirAPaginaDeError(request, response, 404);
                return;
            }

            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);

        } catch (Exception e) {
            ErrorHandler.redirigirAPaginaDeError(request, response, 500);
        }
    }

}
