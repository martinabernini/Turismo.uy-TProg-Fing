package com.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.helpers.*;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
import logica.interfaces.IControladorActividadTuristica;
import utils.Fabrica;

/**
 * Servlet implementation class ConsultitaTest
 */
@WebServlet(Endpoints.CONSULTAR_ACTIVIDADES_SERVLET)
public class ConsultarActividades extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final IControladorActividadTuristica controladorActividadTuristica = Fabrica.getInstance().getIControladorActividadTuristica();

    public ConsultarActividades() {
        super();
        Fabrica.getInstance().getICargaDatos().cargar();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        // Los posibles filtros de la búsqueda se reciben como parámetros
        // categoria, departamento, actividad

        // si no hay filtros -> se muesta la pagina de filstros de busqueda categorias y departamentos
        // si hay categoria -> se muestra la lista de actividades de esa categoria
        // si hay departamento -> se muestra la lista de actividades de ese departamento
        // si hay actividad -> se muestra la lista de salidas de esa actividad para
        // inscribirse

        ErrorHandler.guardarErrorDelQueryEnAttributeDelRequest(request);

        // si no hay filtros
        if (request.getParameter("categoria") == null && request.getParameter("departamento") == null) {
            try {
                String[] actividades = controladorActividadTuristica.listarActividadesEnEstadoConfirmada();

                List<DtActividadTuristica> listaActividades = new ArrayList<>();

                for (String actividad : actividades) {
                    DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                    actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                    listaActividades.add(actividadDt);
                }
                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarActividad/consultarActividades.jsp").forward(request, response);
                return;

            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorSinMantenerQueryString(request, response, e.getMessage());
                return;
            }
        }

        // si solo hay categorias
        if (request.getParameter("categoria") != null && request.getParameter("departamento") == null) {
            try {
                String categoria = request.getParameter("categoria");
                String[] actividades = controladorActividadTuristica.listarActividadesAsociadasACategoriaConfirmadas(categoria);
                List<DtActividadTuristica> listaActividades = new ArrayList<>();

                for (String actividad : actividades) {
                    DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                    actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                    listaActividades.add(actividadDt);
                }

                HttpSession session = request.getSession();

                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);

                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarActividad/consultarActividades.jsp").forward(request, response);
                return;
            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorSinMantenerQueryString(request, response, e.getMessage());
                return;
            }
        }

        // si solo hay departamentos
        if (request.getParameter("departamento") != null && request.getParameter("categoria") == null) {
            try {
                String departamento = request.getParameter("departamento");
                String[] actividades = controladorActividadTuristica.listarActividadesAsociadasADepartamentoConfirmadas(departamento);
                List<DtActividadTuristica> listaActividades = new ArrayList<>();

                for (String actividad : actividades) {
                    DtActividadTuristica actividadDt = controladorActividadTuristica.getActividadTuristica(actividad);
                    actividadDt.setImagen(ImagePathHelper.conPrefijo(actividadDt.getImagen()));
                    listaActividades.add(actividadDt);
                }

                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
                request.getRequestDispatcher("/WEB-INF/views/actividades/consultarActividad/consultarActividades" +
                        ".jsp").forward(request, response);
                return;
            } catch (NoHayEntidadesParaListarException | EntidadNoExisteException | CampoInvalidoException e) {
                ErrorHandler.redirigirConErrorSinMantenerQueryString(request, response, e.getMessage());
                return;
            }
        }


    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
