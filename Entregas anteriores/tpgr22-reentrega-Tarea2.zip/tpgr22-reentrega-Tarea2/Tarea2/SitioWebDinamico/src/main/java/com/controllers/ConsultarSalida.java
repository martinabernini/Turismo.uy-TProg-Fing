package com.controllers;

import com.helpers.*;
import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.*;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class ConsultarSalida
 */
@WebServlet("/ConsultarSalida")
public class ConsultarSalida extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarSalida() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        String nombreSalida = request.getParameter("salida"); // viene del query string

        IControladorSalidaTuristica controladorSalidaTuristica = Fabrica.getInstance().getIControladorSalidaTuristica();

        try {
            DtSalidaTuristica salida = controladorSalidaTuristica.getSalidaTuristica(nombreSalida);
            salida.setImagen(ImagePathHelper.conPrefijo(salida.getImagen()));

            request.setAttribute(RequestKeys.SALIDA_CONSULTA, salida);
            request.getRequestDispatcher("/WEB-INF/views/actividades/consultarSalida/consultarSalida.jsp").forward(request, response);
            return;
            	
        } catch (EntidadNoExisteException | CampoInvalidoException e) {
            ErrorHandler.redirigirConErrorMenteniendoQueryString(request, response, e.getMessage());
            return;
        }
        
        
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
