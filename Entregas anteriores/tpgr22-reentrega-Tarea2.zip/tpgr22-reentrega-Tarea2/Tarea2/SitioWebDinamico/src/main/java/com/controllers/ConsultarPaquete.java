package com.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.helpers.Endpoints;
import com.helpers.EstadoSesionHelper;
import com.helpers.ImagePathHelper;
import com.helpers.RequestKeys;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtActividadTuristica;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorPaqueteActividades;
import utils.Fabrica;

/**
 * Servlet implementation class ConsultarPaquete
 */
@WebServlet(Endpoints.CONSULTAR_PAQUETE_SERVLET)
public class ConsultarPaquete extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsultarPaquete() {
        super();
        // TODO Auto-generated constructor stub
    }

    private static final IControladorPaqueteActividades controladorPaquete = Fabrica.getInstance().getIControladorPaqueteActividades();
    private static final IControladorActividadTuristica controladorActividadTuristica = Fabrica.getInstance().getIControladorActividadTuristica();

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");

        String nombrePaquete = request.getParameter("paquete"); // viene del query string

        try {
            DtPaqueteActividades paquete = controladorPaquete.find(nombrePaquete);
            
            request.setAttribute(RequestKeys.PAQUETE_CONSULTA, paquete);

            String[] actividades = paquete.getNombreActividades();
            List<DtActividadTuristica> listaActividades = new ArrayList<>();

            if (actividades != null && actividades.length != 0) {
                for (String actividad : actividades) {
                    DtActividadTuristica dtActividad = controladorActividadTuristica.getActividadTuristica(actividad);
                    listaActividades.add(dtActividad);
                }
                request.setAttribute(RequestKeys.LISTA_ACTIVIDADES, listaActividades);
            }

            
            request.getRequestDispatcher("/WEB-INF/views/paquetes/consultarPaquete/consultarPaquete.jsp").forward(request, response);

        } catch (EntidadNoExisteException | CampoInvalidoException e) {
            response.sendRedirect(request.getContextPath() + Endpoints.HOME_SERVLET);
        }

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
