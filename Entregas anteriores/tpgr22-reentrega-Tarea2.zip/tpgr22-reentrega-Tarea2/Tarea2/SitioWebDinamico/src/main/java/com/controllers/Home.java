package com.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.helpers.Endpoints;
import com.helpers.EstadoSesionHelper;

import utils.Fabrica;


/**
 * Servlet implementation class Home
 */
@WebServlet(Endpoints.HOME_SERVLET)
public class Home extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Home() {
        super();
        Fabrica.getInstance().getICargaDatos().cargar();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EstadoSesionHelper.initSession(request);
        request.setCharacterEncoding("UTF-8");
        request.getRequestDispatcher("/WEB-INF/views/home/home.jsp").forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

}


