package presentacion.usuario;

import javax.swing.JInternalFrame;

import logica.datatypes.DtProovedor;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorUsuario;
import logica.interfaces.ILogger;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import com.toedter.calendar.JDateChooser;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.NoHayEntidadesParaListarException;

public class ModificarUsuario extends JInternalFrame {

	private IControladorUsuario controladorUsuario;
	private static ILogger logger;
	
	private JLabel lblUsuarios;
	private JComboBox comboBoxUsuarios;
	
	
	private JLabel lblNombre;
	private JLabel lblApellido;
	private JLabel lblFechaDeNacimiento;
	private JLabel lblNacionalidad;
	private JLabel lblDescripcion;
	private JLabel lblSitioWeburl;
	
	
	private JLabel lblInformacionUsuario;
	
		
	private JTextField textFieldNombre;
	private JTextField textFieldApellido;
	private JTextField textFieldNacionalidad;
	private JTextField textFieldDescripcion;
	private JTextField textFieldURL;
	
	private JDateChooser dateChooser;
	
	private String usuario;
	
	
	
	
	
	private JButton btnModificar;
	private JButton btnCerrar;
	
	
	
	private GridBagConstraints gbc_textFieldNombre;
	private GridBagConstraints gbc_textFieldApellido;
	private GridBagConstraints gbc_textFieldNacionalidad;
	private GridBagConstraints gbc_textFieldDescripcion;
	private GridBagConstraints gbc_textFieldURL;


	public ModificarUsuario(IControladorUsuario controladorUsuario, ILogger logger) {
		
		this.controladorUsuario = controladorUsuario;
		this.logger = logger;
		
		setResizable(true);
		setIconifiable(true);
		setMaximizable(true);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setClosable(true);
		setTitle("Modificar usuario");
		setBounds(10, 40, 501, 340);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {30, 97, 229, 97, 10};
		gridBagLayout.rowHeights = new int[]{10, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		lblUsuarios = new JLabel("Usuarios:");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		getContentPane().add(lblUsuarios, gbc_lblNewLabel);
		
		lblDescripcion = new JLabel("Descripcion:");
		GridBagConstraints gbc_lblDescripcion = new GridBagConstraints();
		gbc_lblDescripcion.anchor = GridBagConstraints.EAST;
		gbc_lblDescripcion.insets = new Insets(0, 0, 5, 5);
		gbc_lblDescripcion.gridx = 1;
		gbc_lblDescripcion.gridy = 7;
		getContentPane().add(lblDescripcion, gbc_lblDescripcion);
		
		textFieldDescripcion = new JTextField();
		textFieldDescripcion.setEnabled(false);
		textFieldDescripcion.setEditable(false);
		textFieldDescripcion.setColumns(10);
		GridBagConstraints gbc_textField_3;
		gbc_textFieldDescripcion = new GridBagConstraints();
		gbc_textFieldDescripcion.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldDescripcion.fill = GridBagConstraints.BOTH;
		gbc_textFieldDescripcion.gridx = 2;
		gbc_textFieldDescripcion.gridy = 7;
		getContentPane().add(textFieldDescripcion, gbc_textFieldDescripcion);
		
		
		lblSitioWeburl = new JLabel("Sitio web (URL):");
		GridBagConstraints gbc_lblSitioWeburl = new GridBagConstraints();
		gbc_lblSitioWeburl.anchor = GridBagConstraints.EAST;
		gbc_lblSitioWeburl.insets = new Insets(0, 0, 5, 5);
		gbc_lblSitioWeburl.gridx = 1;
		gbc_lblSitioWeburl.gridy = 8;
		getContentPane().add(lblSitioWeburl, gbc_lblSitioWeburl);
		
		textFieldURL = new JTextField();
		textFieldURL.setEnabled(false);
		textFieldURL.setEditable(false);
		textFieldURL.setColumns(10);
		GridBagConstraints gbc_textField_4;
		gbc_textFieldURL = new GridBagConstraints();
		gbc_textFieldURL.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldURL.fill = GridBagConstraints.BOTH;
		gbc_textFieldURL.gridx = 2;
		gbc_textFieldURL.gridy = 8;
		getContentPane().add(textFieldURL, gbc_textFieldURL);
		
		comboBoxUsuarios = new JComboBox();
		try {
			comboBoxUsuarios.setModel(new DefaultComboBoxModel<String>(controladorUsuario.listarUsuarios()));
		} catch (NoHayEntidadesParaListarException e1) {
			JOptionPane.showMessageDialog(new JFrame(), "NO SE CARGAN WEY" , "Inscripcion salida turistica" , JOptionPane.ERROR_MESSAGE);
		}
		comboBoxUsuarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 textFieldNombre.setEditable(true);
				 textFieldNombre.setEnabled(true);
				 
				 textFieldApellido.setEditable(true);
				 textFieldApellido.setEnabled(true);

				 textFieldNacionalidad.setEditable(true);
				 textFieldNacionalidad.setEnabled(true);
				 
				 textFieldDescripcion.setEditable(true);
				 textFieldDescripcion.setEnabled(true);
				 
				 textFieldURL.setEditable(true);
				 textFieldURL.setEnabled(true);
				 
				 dateChooser.setEnabled(true);
				 
				 usuario= comboBoxUsuarios.getSelectedItem().toString();
					 
				 ingresarDatos(usuario);
			}
		});
		GridBagConstraints gbc_comboBoxUsuarios = new GridBagConstraints();
		gbc_comboBoxUsuarios.insets = new Insets(0, 0, 5, 5);
		gbc_comboBoxUsuarios.fill = GridBagConstraints.BOTH;
		gbc_comboBoxUsuarios.gridx = 2;
		gbc_comboBoxUsuarios.gridy = 1;
		getContentPane().add(comboBoxUsuarios, gbc_comboBoxUsuarios);
		
		lblInformacionUsuario = new JLabel("Informacion de usuario");
		GridBagConstraints gbc_lblInformacionUsuario = new GridBagConstraints();
		gbc_lblInformacionUsuario.insets = new Insets(0, 0, 5, 5);
		gbc_lblInformacionUsuario.gridx = 2;
		gbc_lblInformacionUsuario.gridy = 2;
		getContentPane().add(lblInformacionUsuario, gbc_lblInformacionUsuario);
		
		lblNombre = new JLabel("Nombre:");
		GridBagConstraints gbc_lblNombre = new GridBagConstraints();
		gbc_lblNombre.anchor = GridBagConstraints.EAST;
		gbc_lblNombre.insets = new Insets(0, 0, 5, 5);
		gbc_lblNombre.gridx = 1;
		gbc_lblNombre.gridy = 3;
		getContentPane().add(lblNombre, gbc_lblNombre);
		
		textFieldNombre = new JTextField();
		textFieldNombre.setEnabled(false);
		textFieldNombre.setEditable(false);
		GridBagConstraints gbc_textField;
		gbc_textFieldNombre = new GridBagConstraints();
		gbc_textFieldNombre.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldNombre.fill = GridBagConstraints.BOTH;
		gbc_textFieldNombre.gridx = 2;
		gbc_textFieldNombre.gridy = 3;
		getContentPane().add(textFieldNombre, gbc_textFieldNombre);
		textFieldNombre.setColumns(10);
		
		
		lblApellido = new JLabel("Apellido:");
		GridBagConstraints gbc_lblApellido = new GridBagConstraints();
		gbc_lblApellido.anchor = GridBagConstraints.EAST;
		gbc_lblApellido.insets = new Insets(0, 0, 5, 5);
		gbc_lblApellido.gridx = 1;
		gbc_lblApellido.gridy = 4;
		getContentPane().add(lblApellido, gbc_lblApellido);
		
		textFieldApellido = new JTextField();
		textFieldApellido.setEnabled(false);
		textFieldApellido.setEditable(false);
		textFieldApellido.setColumns(10);
		GridBagConstraints gbc_textField_1;
		gbc_textFieldApellido = new GridBagConstraints();
		gbc_textFieldApellido.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldApellido.fill = GridBagConstraints.BOTH;
		gbc_textFieldApellido.gridx = 2;
		gbc_textFieldApellido.gridy = 4;
		getContentPane().add(textFieldApellido, gbc_textFieldApellido);
		
		lblFechaDeNacimiento = new JLabel("Fecha de nacimiento:");
		GridBagConstraints gbc_lblFechaDeNacimiento = new GridBagConstraints();
		gbc_lblFechaDeNacimiento.anchor = GridBagConstraints.EAST;
		gbc_lblFechaDeNacimiento.insets = new Insets(0, 0, 5, 5);
		gbc_lblFechaDeNacimiento.gridx = 1;
		gbc_lblFechaDeNacimiento.gridy = 5;
		getContentPane().add(lblFechaDeNacimiento, gbc_lblFechaDeNacimiento);
		
		dateChooser = new JDateChooser();
		dateChooser.setEnabled(false);
		GridBagConstraints gbc_dateChooser = new GridBagConstraints();
		gbc_dateChooser.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooser.fill = GridBagConstraints.BOTH;
		gbc_dateChooser.gridx = 2;
		gbc_dateChooser.gridy = 5;
		getContentPane().add(dateChooser, gbc_dateChooser);
		
		lblNacionalidad = new JLabel("Nacionalidad:");
		GridBagConstraints gbc_lblNacionalidad = new GridBagConstraints();
		gbc_lblNacionalidad.anchor = GridBagConstraints.EAST;
		gbc_lblNacionalidad.insets = new Insets(0, 0, 5, 5);
		gbc_lblNacionalidad.gridx = 1;
		gbc_lblNacionalidad.gridy = 6;
		getContentPane().add(lblNacionalidad, gbc_lblNacionalidad);
		
		textFieldNacionalidad = new JTextField();
		textFieldNacionalidad.setEditable(false);
		textFieldNacionalidad.setEnabled(false);
		textFieldNacionalidad.setColumns(10);
		GridBagConstraints gbc_textField_2;
		gbc_textFieldNacionalidad = new GridBagConstraints();
		gbc_textFieldNacionalidad.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldNacionalidad.fill = GridBagConstraints.BOTH;
		gbc_textFieldNacionalidad.gridx = 2;
		gbc_textFieldNacionalidad.gridy = 6;
		getContentPane().add(textFieldNacionalidad, gbc_textFieldNacionalidad);

		
		

		
		btnModificar = new JButton("       Modificar      ");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						verificarCampos();
						actualizarDatos(usuario);
						limpiarFormulario();
					
				} catch (CampoInvalidoException e1) {
					JOptionPane.showMessageDialog(new JFrame(), e1.getMessage() , "Modificar usuario" , JOptionPane.ERROR_MESSAGE);
				}
				
			}	
		});
		GridBagConstraints gbc_btnModificar = new GridBagConstraints();
		gbc_btnModificar.anchor = GridBagConstraints.EAST;
		gbc_btnModificar.insets = new Insets(0, 0, 0, 5);
		gbc_btnModificar.gridx = 2;
		gbc_btnModificar.gridy = 9;
		getContentPane().add(btnModificar, gbc_btnModificar);
		
		btnCerrar = new JButton("Cerrar");
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiarFormulario();
				setVisible(false);
			}
		});
		GridBagConstraints gbc_btnCerrar = new GridBagConstraints();
		gbc_btnCerrar.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnCerrar.gridx = 3;
		gbc_btnCerrar.gridy = 9;
		getContentPane().add(btnCerrar, gbc_btnCerrar);



	}
	
	
	private void ingresarDatos(String usuario) {
		try {
			DtUsuario user= controladorUsuario.getUsuario(usuario);
			textFieldNombre.setText(user.getNombre());
			textFieldApellido.setText(user.getApellido());
			dateChooser.setDate(user.getFechaNacimiento());
			if (user instanceof DtTurista) {
				textFieldNacionalidad.setEnabled(true);
				textFieldNacionalidad.setText(((DtTurista) user).getNacionalidad());
				textFieldDescripcion.setText("");
				textFieldURL.setText("");
				textFieldDescripcion.setEnabled(false);
				textFieldURL.setEnabled(false);
			} 
			if (user instanceof DtProovedor) {
				textFieldNacionalidad.setText("");
				textFieldDescripcion.setEnabled(true);
				textFieldURL.setEnabled(true);
				textFieldNacionalidad.setEnabled(false);
				
				
				String des= ((DtProovedor) user).getDescripcion();
				String url= ((DtProovedor) user).getUrlSitioWeb();
				logger.log("hola la descripcion es: " + des);
				logger.log("hola el url es: "+ url);
				textFieldDescripcion.setText(((DtProovedor) user).getDescripcion());
				
				textFieldURL.setText(((DtProovedor) user).getUrlSitioWeb());
			}
		} catch (EntidadNoExisteException | CampoInvalidoException e) {
			
		}
		
	}
	
	private void actualizarDatos(String usuario) {
		try {
			verificarCampos();
			DtUsuario u= controladorUsuario.getUsuario(usuario); 
			
			
			String nombre= textFieldNombre.getText();
			String apellido= textFieldApellido.getText();
			Date fecha= dateChooser.getDate();
			if (u instanceof DtTurista) {
				String nacionalidad = textFieldNacionalidad.getText();
				DtTurista user= new DtTurista(usuario, nombre, apellido, u.getEmail(), fecha, nacionalidad);
				controladorUsuario.modificarUsuario(user);
			} else {
				String descripcion= textFieldDescripcion.getText();
				String url= textFieldURL.getText();
				DtProovedor user= new DtProovedor(usuario, nombre, apellido, u.getEmail(), fecha, descripcion, url);
				controladorUsuario.modificarUsuario(user);
			}
			
			JOptionPane.showMessageDialog(new JFrame(), "Usuario modificado con exito" , "Modificar usuario" , JOptionPane.PLAIN_MESSAGE);
			setVisible(false);
			limpiarFormulario();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(), e.getMessage() , "Modificar usuario" , JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void verificarCampos() throws CampoInvalidoException {
		if (textFieldNombre.getText().isBlank()) {
			throw new CampoInvalidoException("Error: nombre de usuario invalido");
		}
		if (textFieldApellido.getText().isBlank()) {
			throw new CampoInvalidoException("Error: apellido de usuario invalido");
		}
		if (( dateChooser.isValid())) {
			throw new CampoInvalidoException("Error: fecha de nacimiento invalida");
		}
		if (textFieldDescripcion.isEnabled()) {
			if (textFieldDescripcion.getText().isBlank()) {
				throw new CampoInvalidoException("Error: descripcion de usuario invalido");
			}	
			
		} else {
			if (textFieldNacionalidad.getText().isBlank()) {
				throw new CampoInvalidoException("Error: nacionalidad de usuario invalida");
			}	
		}
	}
	
	private void limpiarFormulario() {
		textFieldNombre.setText("");
		textFieldApellido.setText("");
		textFieldNacionalidad.setText("");
		textFieldDescripcion.setText("");
		textFieldURL.setText("");
	}
}