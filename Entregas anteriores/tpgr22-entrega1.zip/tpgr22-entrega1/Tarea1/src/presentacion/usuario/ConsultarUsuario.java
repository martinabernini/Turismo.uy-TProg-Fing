package presentacion.usuario;

import javax.swing.JInternalFrame;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import excepciones.UsuarioNoExisteException;
import logica.datatypes.DtProovedor;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorUsuario;
import logica.interfaces.ILogger;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

@SuppressWarnings("serial")
public class ConsultarUsuario extends JInternalFrame {

	private IControladorUsuario controladorUsuario;
	private ILogger logger;

	private JLabel lblUsuarios;
	private JButton btnCerrar;
	private JLabel lblInfoUsuario;
	private JComboBox<String> comboBoxUsuario;

	private JLabel lblNombre;
	private JLabel lblTipo;
	private JLabel lblFechadeNacimiento;
	private JLabel lblEmail;
	private JLabel lblApellido;

	private JLabel lblInfoFecha;
	private JLabel lblInfoTIPO;
	private JLabel lblInfoNombre;
	private JLabel lblInfoApellido;
	private JLabel lblInfoEmail;
	
	private DtUsuario usuarioSeleccionado;

	private JLabel lblActividaesTuristicas;
	private JComboBox<String> comboBoxActividades;
	private JLabel lblSalidasTuristicasInscr;
	private JComboBox<String> comboBoxSalidas;

	public ConsultarUsuario(IControladorUsuario controladorUsuario, ILogger logger) {

		this.controladorUsuario = controladorUsuario;
		this.logger = logger;

		
		try {

			if (controladorUsuario.listarUsuarios().length != 0) {

				setResizable(true);
				setIconifiable(true);
				setMaximizable(true);
				setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				setClosable(true);
				setTitle("Consulta de Usuario");
				setBounds(10, 30, 450, 490);
				getContentPane().setLayout(null);

				// Labels descriptivos
				
				comboBoxSalidas = new JComboBox<String>();
				comboBoxSalidas.setModel(new DefaultComboBoxModel<String>(new String[] { " " }));
				comboBoxSalidas.setBounds(160, 360, 250, 30);
				getContentPane().add(comboBoxSalidas);
				comboBoxSalidas.setEditable(false);
				comboBoxSalidas.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String salidaAct = comboBoxSalidas.getSelectedItem().toString();
						presentacion.Principal.crearConsultaSalidaConSalidaSeleccionaInternalFrame(salidaAct);
					}
			});
				
				comboBoxActividades = new JComboBox<String>();
				comboBoxActividades.setModel(new DefaultComboBoxModel<String>(new String[] { " " }));
				comboBoxActividades.setBounds(160, 310, 250, 30);
				getContentPane().add(comboBoxActividades);
				comboBoxActividades.setEditable(false);
				comboBoxActividades.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						presentacion.Principal.crearConsultaActividadConActividadSeleccionadaInternalFrame(
								comboBoxActividades.getSelectedItem().toString());
					}
				});

				lblInfoUsuario = new JLabel("Informacion de Usuario:");
				lblInfoUsuario.setBounds(145, 70, 180, 14);
				lblInfoUsuario.setFont(new Font("Tahoma", Font.PLAIN, 13));
				getContentPane().add(lblInfoUsuario);

				lblUsuarios = new JLabel("Usuarios:");
				lblUsuarios.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblUsuarios.setBounds(10, 16, 73, 30);
				getContentPane().add(lblUsuarios);

				
				lblTipo = new JLabel("Tipo:");
				lblTipo.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblTipo.setBounds(10, 94, 73, 30);
				//lblTipo.setAlignmentX(CENTER_ALIGNMENT);
				getContentPane().add(lblTipo);

				lblEmail = new JLabel("Email:");
				lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblEmail.setBounds(10, 217, 73, 30);
				getContentPane().add(lblEmail);

				lblApellido = new JLabel("Apellido:");
				lblApellido.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblApellido.setBounds(10, 176, 73, 30);
				getContentPane().add(lblApellido);

				lblNombre = new JLabel("Nombre:");
				lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblNombre.setBounds(10, 135, 73, 30);
				getContentPane().add(lblNombre);

				lblFechadeNacimiento = new JLabel("Fecha de nacimiento:");
				lblFechadeNacimiento.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblFechadeNacimiento.setBounds(10, 258, 160, 30);
				getContentPane().add(lblFechadeNacimiento);

				lblActividaesTuristicas = new JLabel("Actividades Turisticas:");
				lblActividaesTuristicas.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblActividaesTuristicas.setBounds(10, 310, 150, 30);
				getContentPane().add(lblActividaesTuristicas);

				lblSalidasTuristicasInscr = new JLabel("Salidas Turisticas:");
				lblSalidasTuristicasInscr.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblSalidasTuristicasInscr.setBounds(10, 360, 150, 30);
				getContentPane().add(lblSalidasTuristicasInscr);

				// Labels con info cargada

				lblInfoTIPO = new JLabel("");
				lblInfoTIPO.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblInfoTIPO.setBounds(160, 95, 73, 30);
				getContentPane().add(lblInfoTIPO);

				lblInfoNombre = new JLabel(" ");
				lblInfoNombre.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblInfoNombre.setBounds(160, 136, 150, 30);
				getContentPane().add(lblInfoNombre);

				lblInfoApellido = new JLabel(" ");
				lblInfoApellido.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblInfoApellido.setBounds(160, 177, 153, 30);
				getContentPane().add(lblInfoApellido);

				lblInfoFecha = new JLabel(" ");
				lblInfoFecha.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblInfoFecha.setBounds(160, 259, 250, 30);
				getContentPane().add(lblInfoFecha);

				lblInfoEmail = new JLabel(" ");
				lblInfoEmail.setFont(new Font("Tahoma", Font.PLAIN, 13));
				lblInfoEmail.setBounds(160, 218, 250, 30);
				getContentPane().add(lblInfoEmail);

				comboBoxUsuario = new JComboBox();
				comboBoxUsuario.setModel(new DefaultComboBoxModel<String>(controladorUsuario.listarUsuarios()));
				comboBoxUsuario.setBounds(93, 16, 153, 30);
				getContentPane().add(comboBoxUsuario);
				comboBoxUsuario.setEditable(false);
				comboBoxUsuario.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String nombreUser= comboBoxUsuario.getSelectedItem().toString();
						try {
							usuarioSeleccionado = controladorUsuario.getUsuario(nombreUser);
							if (usuarioSeleccionado instanceof DtTurista) {
								comboBoxActividades.setModel(new DefaultComboBoxModel<String>(new String[]{"No aplica"}));
								comboBoxActividades.setEnabled(false);
								comboBoxSalidas.setEnabled(true);
								comboBoxSalidas.setModel(new DefaultComboBoxModel<String>(((DtTurista) usuarioSeleccionado).getInscripcionesASalidas()));
							} else {
								
								comboBoxSalidas.setModel(new DefaultComboBoxModel<String>(new String[]{"No aplica"}));
								comboBoxSalidas.setEnabled(false);
								comboBoxActividades.setModel(new DefaultComboBoxModel<String>(((DtProovedor) usuarioSeleccionado).getActividadesTuristicas()));
							}
						} catch (EntidadNoExisteException | CampoInvalidoException e1) {
						}						
						cmdBuscarUsuarioActionPerformed(nombreUser);

					}

				});

				btnCerrar = new JButton("Cerrar");
				btnCerrar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// limpiarFormulario();
						setVisible(false);
					}
				});
				btnCerrar.setBounds(260, 16, 95, 30);
				getContentPane().add(btnCerrar);

			}

		} catch (NoHayEntidadesParaListarException e) {

			JOptionPane.showMessageDialog(this, e.getMessage(), "Consutar Usuario", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void cmdBuscarUsuarioActionPerformed(String nickname) {

			

			if (usuarioSeleccionado instanceof DtTurista) {
				lblInfoTIPO.setText("Turista");
			} else {
				lblInfoTIPO.setText("Proveedor");
			}

			lblInfoNombre.setText(usuarioSeleccionado.getNombre());
			lblInfoApellido.setText(usuarioSeleccionado.getApellido());
			lblInfoEmail.setText(usuarioSeleccionado.getEmail());
			lblInfoFecha.setText(usuarioSeleccionado.getFechaNacimiento().toString());
			
			logger.log("hola antes del if");
			if (usuarioSeleccionado instanceof DtTurista) {
				DtTurista turista = ((DtTurista) usuarioSeleccionado);
				
				
				

				if (turista.getInscripcionesASalidas() != null && turista.getInscripcionesASalidas().length > 0) {
					logger.log("fdasar if" + turista.getInscripcionesASalidas()[0]);
					comboBoxSalidas.setModel(new DefaultComboBoxModel<String>(turista.getInscripcionesASalidas()));
					comboBoxSalidas.setEnabled(true);
					comboBoxSalidas.setVisible(true);
				} 
				
			} else {
				
				DtProovedor proveedor = ((DtProovedor) usuarioSeleccionado);

				if (proveedor.getActividadesTuristicas() != null && proveedor.getActividadesTuristicas().length > 0) {

					logger.log("fdasar if" + proveedor.getActividadesTuristicas()[0]);
					comboBoxActividades
							.setModel(new DefaultComboBoxModel<String>(proveedor.getActividadesTuristicas()));
					comboBoxActividades.setEnabled(true);
					comboBoxActividades.setVisible(true);
					
				}
			}

		

	}

	private void limpiarFormulario() {
		lblInfoNombre.setText("");
		lblInfoApellido.setText("");
		lblInfoEmail.setText("");
		lblInfoTIPO.setText("");
		lblInfoFecha.setText("");
		comboBoxSalidas.setModel(new DefaultComboBoxModel<String>(new String[] { " " }));
		comboBoxSalidas.setVisible(false);
		comboBoxActividades.setModel(new DefaultComboBoxModel<String>(new String[] { " " }));
		comboBoxActividades.setVisible(false);

	}

}
