package presentacion.salidaturistica;

import javax.swing.JInternalFrame;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import excepciones.UsuarioNoExisteException;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IControladorUsuario;
import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtSalidaTuristica;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import com.toedter.calendar.JDateChooser;

public class AltaSalidaTur extends JInternalFrame {
	private JTextField textFieldNombre;
	private JTextField textFieldCantidad;
	private JTextField textFieldHora;
	private JTextField textFieldLugar;
	private IControladorActividadTuristica controladorAct;
	private IControladorDepartamento controladorDpto;
	private IControladorSalidaTuristica controladorSal;
	private JComboBox comboBoxDepartamento;
	private JComboBox comboBoxActividades;
	private JDateChooser dateChooserFechaAlta;
	private JDateChooser dateChooserFecha;
	private JLabel lblActividades;
	private JLabel lblNombre;
	private JLabel lblLugarDeSalida;
	private JLabel lblDepartamento;
	private JLabel lblCantTuristas;
	private JLabel lblFecha;
	private JButton btnInscribir;
	private JLabel lblHora;
	private JLabel lblFechaDeAlta;
	private JButton btnCerrar;

	public AltaSalidaTur() {

	};

	public AltaSalidaTur(IControladorSalidaTuristica controladorSalida,
			IControladorDepartamento controladorDepartamento, IControladorActividadTuristica controladorActividad) {

		this.controladorAct = controladorActividad;
		this.controladorDpto = controladorDepartamento;
		this.controladorSal = controladorSalida;

		try {
			String[] listaDepartamentos = controladorDpto.listarDepartamentos();
			
			setResizable(true);
			setIconifiable(true);
			setMaximizable(true);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setClosable(true);
			setTitle("Alta salida turistica");
			setBounds(10, 40, 500, 367);
			getContentPane().setLayout(null);

			lblDepartamento = new JLabel("Departamento:  ");
			lblDepartamento.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblDepartamento.setBounds(5, 16, 150, 15);
			getContentPane().add(lblDepartamento);
			lblDepartamento.setHorizontalAlignment(SwingConstants.RIGHT);

			comboBoxActividades = new JComboBox();
			comboBoxActividades.setBounds(155, 41, 269, 25);
			getContentPane().add(comboBoxActividades);

			comboBoxDepartamento = new JComboBox();
			comboBoxDepartamento.setBounds(155, 11, 269, 25);
			getContentPane().add(comboBoxDepartamento);
			comboBoxDepartamento.setModel(new DefaultComboBoxModel<String>(listaDepartamentos));
			comboBoxDepartamento.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cmdBuscarActividadesActionPerformed(comboBoxDepartamento.getSelectedItem().toString());
				}

			});

			lblActividades = new JLabel("Actividades:  ");
			lblActividades.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblActividades.setBounds(5, 46, 150, 15);
			getContentPane().add(lblActividades);
			lblActividades.setHorizontalAlignment(SwingConstants.RIGHT);

			textFieldNombre = new JTextField();
			textFieldNombre.setColumns(10);
			textFieldNombre.setBounds(155, 78, 269, 23);
			getContentPane().add(textFieldNombre);

			lblCantTuristas = new JLabel("Cantidad de turistas: ");
			lblCantTuristas.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblCantTuristas.setBounds(5, 231, 150, 15);
			getContentPane().add(lblCantTuristas);
			lblCantTuristas.setHorizontalAlignment(SwingConstants.RIGHT);

			textFieldCantidad = new JTextField();
			textFieldCantidad.setColumns(10);
			textFieldCantidad.setBounds(155, 226, 45, 25);
			getContentPane().add(textFieldCantidad);

			lblNombre = new JLabel("Nombre:  ");
			lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblNombre.setBounds(5, 83, 150, 15);
			getContentPane().add(lblNombre);
			lblNombre.setHorizontalAlignment(SwingConstants.RIGHT);

			lblFecha = new JLabel("Fecha salida:  ");
			lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblFecha.setBounds(5, 118, 150, 15);
			getContentPane().add(lblFecha);
			lblFecha.setHorizontalAlignment(SwingConstants.RIGHT);

			dateChooserFecha = new JDateChooser();
			dateChooserFecha.setBounds(155, 113, 269, 25);
			getContentPane().add(dateChooserFecha);

			lblHora = new JLabel("Hora salida:  ");
			lblHora.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblHora.setBounds(5, 157, 150, 15);
			getContentPane().add(lblHora);
			lblHora.setHorizontalAlignment(SwingConstants.RIGHT);

			textFieldHora = new JTextField();
			textFieldHora.setColumns(10);
			textFieldHora.setBounds(155, 153, 39, 23);
			getContentPane().add(textFieldHora);

			lblLugarDeSalida = new JLabel("Lugar de salida:  ");
			lblLugarDeSalida.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblLugarDeSalida.setBounds(5, 195, 150, 15);
			getContentPane().add(lblLugarDeSalida);
			lblLugarDeSalida.setHorizontalAlignment(SwingConstants.RIGHT);

			textFieldLugar = new JTextField();
			textFieldLugar.setColumns(10);
			textFieldLugar.setBounds(155, 193, 269, 23);
			getContentPane().add(textFieldLugar);

			lblFechaDeAlta = new JLabel("Fecha de alta:  ");
			lblFechaDeAlta.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblFechaDeAlta.setBounds(5, 267, 150, 15);
			getContentPane().add(lblFechaDeAlta);
			lblFechaDeAlta.setHorizontalAlignment(SwingConstants.RIGHT);
			
			dateChooserFechaAlta = new JDateChooser();
			dateChooserFechaAlta.setBounds(155, 263, 269, 25);
			getContentPane().add(dateChooserFechaAlta);

			btnInscribir = new JButton();
			btnInscribir.setText("Aceptar");
			btnInscribir.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btnInscribir.setBounds(65, 296, 148, 30);
			getContentPane().add(btnInscribir);
			btnInscribir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cmdRegistroSalidaTuristicaActionPerformed(e);
					//limpiarFormulario();
					//setVisible(false);
				}
			});

			btnCerrar = new JButton();
			btnCerrar.setText("Cerrar");
			btnCerrar.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btnCerrar.setBounds(218, 296, 151, 30);
			getContentPane().add(btnCerrar);
			btnCerrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					limpiarFormulario();
					setVisible(false);
					doDefaultCloseAction();
				}
			});
		} catch (NoHayEntidadesParaListarException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Alta salida turistica", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void cmdBuscarActividadesActionPerformed(String dpto) {
		try {
			comboBoxActividades.setModel(
					new DefaultComboBoxModel<String>(controladorAct.listarActividadesAsociadasADepartamento(dpto)));
			comboBoxActividades.setVisible(true);
		} catch (NoHayEntidadesParaListarException e) {

			JOptionPane.showMessageDialog(this, e.getMessage(), "Alta salida turistica", JOptionPane.ERROR_MESSAGE);
			comboBoxActividades.setVisible(false);
			comboBoxActividades.setModel(new DefaultComboBoxModel<String>(new String[] { " " }));
		} catch (CampoInvalidoException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	protected void cmdRegistroSalidaTuristicaActionPerformed(ActionEvent arg0) {
		String nombreActividad = this.comboBoxActividades.getSelectedItem().toString();
		String nombreSalida = this.textFieldNombre.getText();
		int cantidadMax = Integer.valueOf(this.textFieldCantidad.getText()).intValue();
		Date fechaAlta = this.dateChooserFechaAlta.getDate();

		Date fecha = this.dateChooserFecha.getDate();
		try {
			fecha.setHours(Integer.parseInt(textFieldHora.getText()));
			String lugar = this.textFieldLugar.getText();
			DtSalidaTuristica dtSalida = new DtSalidaTuristica(nombreActividad, nombreSalida, cantidadMax, fechaAlta,
					fecha, lugar);
			controladorSal.darDeAltaSalidaTuristica(dtSalida);
			JOptionPane.showMessageDialog(this, "La salida tur�stica se ha realizado con exito",
					"Alta salida turistica", JOptionPane.INFORMATION_MESSAGE);
			setVisible(false);
			limpiarFormulario();

		} catch (EntidadRepetidaException e) {
			// Muestro error de registro
			JOptionPane.showMessageDialog(this, e.getMessage(), "Alta salida turistica", JOptionPane.ERROR_MESSAGE);
			
		} catch (CampoInvalidoException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Alta salida turistica", JOptionPane.ERROR_MESSAGE);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "Ingrese foramto hora correcta", "Alta salida turistica",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void limpiarFormulario() {
		textFieldNombre.setText("");
		textFieldCantidad.setText("");
		textFieldHora.setText("");
		textFieldLugar.setText("");
		dateChooserFecha.setCalendar(null);
		dateChooserFechaAlta.setCalendar(null);
	}
}