package logica.entidades;

import java.util.Date;
import java.util.Objects;

public class InscripcionSalida {

	private int id;
	private Date fechaInscripcin;
	private int cantidadTuristas;
	private SalidaTuristica salida;
	private float costoTotal = 0;

	// ----------------------------------------------------------------
	// Constructores

	public InscripcionSalida(int id, Date fechaInscripcin, int cantidadTuristas, SalidaTuristica salida,
			float costoSalida) {
		this.id = id;
		this.fechaInscripcin = fechaInscripcin;
		this.cantidadTuristas = cantidadTuristas;
		this.salida = salida;
		this.costoTotal = calcularCostoTotal(cantidadTuristas, costoSalida);
	}

	// ----------------------------------------------------------------
	// Getters y Setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getFechaInscripcin() {
		return fechaInscripcin;
	}

	public void setFechaInscripcin(Date fechaInscripcin) {
		this.fechaInscripcin = fechaInscripcin;
	}

	public int getCantidadTuristas() {
		return cantidadTuristas;
	}

	public void setCantidadTuristas(int cantidadTuristas) {
		this.cantidadTuristas = cantidadTuristas;
	}

	public SalidaTuristica getSalida() {
		return salida;
	}

	public void setSalida(SalidaTuristica salida) {
		this.salida = salida;
	}

	public float getCostoTotal() {
		return costoTotal;
	}

	// ----------------------------------------------------------------
	// Otros metodos


	// ----------------------------------------------------------------
	// Metodos auxliares

	private float calcularCostoTotal(int cantidadTuristas, float costoSalida) {
		return (cantidadTuristas * costoSalida);
	}

	// ----------------------------------------------------------------
	// Metodos de sobrecarga

	@Override
	public String toString() {
		return "InscripcionSalida [id=" + id + ", fechaInscripcin=" + fechaInscripcin + ", cantidadTuristas="
				+ cantidadTuristas + ", salida=" + salida + ", costoTotal=" + costoTotal + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cantidadTuristas, costoTotal, fechaInscripcin, id, salida);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InscripcionSalida other = (InscripcionSalida) obj;
		return cantidadTuristas == other.cantidadTuristas
				&& Float.floatToIntBits(costoTotal) == Float.floatToIntBits(other.costoTotal)
				&& Objects.equals(fechaInscripcin, other.fechaInscripcin) && id == other.id
				&& Objects.equals(salida, other.salida);
	};

}
