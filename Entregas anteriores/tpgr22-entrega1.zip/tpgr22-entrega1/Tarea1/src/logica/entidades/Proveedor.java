package logica.entidades;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import logica.datatypes.DtProovedor;
import logica.datatypes.DtUsuario;

public class Proveedor extends Usuario {
	
	//Atributos
	private String descripcion;
	private String urlSitioWeb;
	private List<ActividadTuristica> actividadesTuristicas;
		
	//Constructor

	public Proveedor(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,String descripcion, String urlSitioWeb) {
		//super();
		
		this.nickname = nickname;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.fechaNacimiento = fechaNacimiento;
		this.descripcion = descripcion;
		this.urlSitioWeb = urlSitioWeb;
		this.actividadesTuristicas = new ArrayList<ActividadTuristica>();
	}
	
	//Getters y setters
	

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUrlSitioWeb() {
		return urlSitioWeb;
	}

	public void setUrlSitioWeb(String urlSitioWeb) {
		this.urlSitioWeb = urlSitioWeb;
	}

	public List<ActividadTuristica> getActividadesTuristicas() {
		return actividadesTuristicas;
	}

	public void setActividadesTuristicas(List<ActividadTuristica> actividadesTuristicas) {
		this.actividadesTuristicas = actividadesTuristicas;
	}

	public DtUsuario newDataType() {
		String [] actividades = new String[]{};
		if(this.actividadesTuristicas != null) {
			actividades = new String[this.actividadesTuristicas.size()];
			for (int i = 0; i < this.actividadesTuristicas.size(); i++) {
				actividades[i] = this.actividadesTuristicas.get(i).getNombre();
			}
		}
		
		DtProovedor res = new DtProovedor(this.nickname, this.nombre, this.apellido, this.email, this.fechaNacimiento,
				this.descripcion, this.urlSitioWeb, actividades);
		return res;
	}


	
	// ---------------------------------------------------------------------------------------------
	
	public void agregarActividadTuristica(ActividadTuristica nuevaActividad) {
		actividadesTuristicas.add(nuevaActividad);
	}
	
	
	// ---------------------------------------------------------------------------------------------
	

	@Override
	public String toString() {
		return "Proveedor [descripcion=" + descripcion + ", urlSitioWeb=" + urlSitioWeb + ", actividadesTuristicas="
				+ actividadesTuristicas + ", nickname=" + nickname + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", email=" + email + ", fechaNacimiento=" + fechaNacimiento + "]";
	}
	
	
	
	
}
