package logica.entidades;

import java.util.Date;

import logica.datatypes.DtUsuario;

public abstract class Usuario {
	
	// Atributos
	
	protected String nickname;
	protected String nombre;
	protected String apellido;
	protected String email;
	protected Date fechaNacimiento;
	
	// Constructores
	
	public Usuario() {
	}
	
	// Getters y Setters
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setFechaNacimiento(Date Fecha) {
		this.fechaNacimiento = Fecha;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public abstract DtUsuario newDataType();
	

	//@Override
	//public String toString() {
	//	return "Usuario [nickname=" + nickname + ", nombre=" + nombre + ", apellido=" + apellido + ", email=" + email
	//			+ ", fechaNacimiento=" + fechaNacimiento + "]";
	//}
	
	
	
}
