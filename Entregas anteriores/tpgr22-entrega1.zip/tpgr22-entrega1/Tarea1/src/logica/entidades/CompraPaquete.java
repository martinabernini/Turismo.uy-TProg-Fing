package logica.entidades;

public class CompraPaquete {

}
