package logica.controladores;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtPaqueteActividades;
import logica.entidades.ActividadTuristica;
import logica.entidades.PaqueteActividades;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorPaqueteActividades;

public class ControladorPaqueteActividades implements IControladorPaqueteActividades {

	private IManejadorPaqueteActividades manejadorPaqueteActividades;
	private IManejadorActividadTuristica manejadorActividadTuristica;
	private ILogger logger;

	public ControladorPaqueteActividades(IManejadorPaqueteActividades manejadorPaqueteActividades,
			IManejadorActividadTuristica manejadorActividadTuristica, ILogger logger) {
		this.manejadorPaqueteActividades = manejadorPaqueteActividades;
		this.manejadorActividadTuristica = manejadorActividadTuristica;
		this.logger = logger;
	}

	// ---------------------------------------------------------------------------------------------------------
	// NO ESTAN IMPLEMENTADO LOS CHEQUEOS, ES SOLO PARA QUE FUNCIONE CON LOS DATOS
	// DE CARGA, LO QUE ESTA ACA ES TEMPORAL
	// ---------------------------------------------------------------------------------------------------------
	
	public void darDeAlta(DtPaqueteActividades nuevoPaquete)throws CampoInvalidoException, EntidadRepetidaException {
		logger.log("NO IMPLEMENTADO:    " + "- ControladorPaqueteActividades.darDeAltaPaquete   " + nuevoPaquete);

		// FALTAN TODOS LOS CHEQUEOS

		PaqueteActividades paquete = new PaqueteActividades();
		paquete.setNombre(nuevoPaquete.getNombre());
		paquete.setDescripcion(nuevoPaquete.getDescripcion());
		paquete.setDescuento(nuevoPaquete.getDescuento());
		paquete.setNombre(nuevoPaquete.getNombre());
		paquete.setFechaAlta(nuevoPaquete.getFechaAlta());
		paquete.setValidezEnDias(nuevoPaquete.getValidezEnDias());

		manejadorPaqueteActividades.add(paquete);
	}

	public String[] listarPaquetes() throws NoHayEntidadesParaListarException {
		logger.log("NO IMPLEMENTADO:    " + "- ControladorPaqueteActividades.listarPaquetes  ");

		// HAY QUE TIRAR ERRORES EN REALIDAD

		PaqueteActividades[] paquetes = manejadorPaqueteActividades.getAll();
		if (paquetes == null || paquetes.length == 0) {
			// en realidad habria que tirar errores
			return new String[] { "" };
		}
		;
		String[] listaNombres = new String[paquetes.length];

		for (int i = 0; i < paquetes.length; i++) {
			listaNombres[i] = paquetes[i].getNombre();
		}

		return listaNombres;
	}

	public String[] listarActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepartamento,
			String nombrePaquete) throws NoHayEntidadesParaListarException, CampoInvalidoException {
		logger.log("NO IMPLEMENTADO:    "
				+ "- ControladorPaqueteActividades.listarActividadesAsociadasADepartamentoNoEnPaquete   nombreDepartamento: '"
				+ nombreDepartamento + "', nombrePaquete: '" + nombrePaquete + "'");

		return null;
	}

	public void ingresarActividadTuristicaAPaquete(String nombreActividad, String nombrePaquete) throws EntidadRepetidaException, CampoInvalidoException {
		logger.log("NO IMPLEMENTADO:    "
				+ "- ControladorPaqueteActividades.ingresarActividadTuristicaAPaquete   nombreActividad: '"
				+ nombreActividad + "', nombrePaquete: '" + nombrePaquete + "'");

		// FALTAN TODOS LO CHEQUEOS Y TIRADAS DE ERROR
		
		PaqueteActividades paquete = manejadorPaqueteActividades.find(nombrePaquete);
		ActividadTuristica actividad = manejadorActividadTuristica.find(nombreActividad);
		
		paquete.agregarActividad(actividad);
		manejadorPaqueteActividades.update(paquete);

		actividad.agregarPaqueteAsociado(paquete);
		manejadorActividadTuristica.update(actividad);
	}

	public DtPaqueteActividades find(String nombre) throws EntidadRepetidaException, CampoInvalidoException {
		logger.log("NO IMPLEMENTADO:    " + "- ControladorPaqueteActividades.getPaquete   nombre: '" + nombre + "'");
		
		// FALTAN TODOS LO CHEQUEOS Y TIRADAS DE ERROR
		
		if (manejadorPaqueteActividades.contains(nombre)) {
			return manejadorPaqueteActividades.find(nombre).newDataType();
		}
		
		return null;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

}
