package logica.controladores;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtTurista;
import logica.datatypes.DtProovedor;
import logica.datatypes.DtUsuario;
import logica.entidades.Proveedor;
import logica.entidades.Turista;
import logica.entidades.Usuario;
import logica.interfaces.IControladorUsuario;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorUsuario;

public class ControladorUsuario implements IControladorUsuario {

	private IManejadorUsuario manejadorUsuario;
	private ILogger logger;
	
	public ControladorUsuario(IManejadorUsuario manejadorUsuario, ILogger logger) {
		this.manejadorUsuario = manejadorUsuario;
		this.logger = logger;
	}
	
	public void darDeAltaUsuario(DtUsuario nuevoUsuario) throws CampoInvalidoException, EntidadRepetidaException {

		logger.log("- ControladorUsuario.darDeAltaUsuario   " + nuevoUsuario);
	
		if (manejadorUsuario.contains(nuevoUsuario.getNickname())) {
			throw new EntidadRepetidaException("Ya hay un usuario registrado con ese nickname");
		}
		
		if (manejadorUsuario.emailYaRegistrado(nuevoUsuario.getEmail())) {
			throw new EntidadRepetidaException("Ya hay un usuario registrado con ese mail");
		}

		if (nuevoUsuario instanceof DtTurista) {
			DtTurista nuevoTurista = (DtTurista) nuevoUsuario;

			if (hayCampoInvalidoDtTurista(nuevoTurista)) {
				throw new CampoInvalidoException(mensajeErrorParaCampoInvalidoTurista(nuevoTurista));
			}

			Turista turista = new Turista(nuevoTurista.getNickname(), nuevoTurista.getNombre(),
					nuevoTurista.getApellido(), nuevoTurista.getEmail(), nuevoTurista.getFechaNacimiento(),
					nuevoTurista.getNacionalidad());

			manejadorUsuario.add(turista);
			return;
		}

		DtProovedor nuevoProveedor = (DtProovedor) nuevoUsuario;

		if (hayCampoInvalidoDtProveedor(nuevoProveedor)) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalidoProveedor(nuevoProveedor));
		}

		Proveedor proveedor = new Proveedor(nuevoProveedor.getNickname(), nuevoProveedor.getNombre(),
				nuevoProveedor.getApellido(), nuevoProveedor.getEmail(), nuevoProveedor.getFechaNacimiento(),
				nuevoProveedor.getDescripcion(), nuevoProveedor.getUrlSitioWeb());

		manejadorUsuario.add(proveedor);

	}

	public String[] listarUsuarios() throws NoHayEntidadesParaListarException {
		
		logger.log("- ControladorUsuario.listarUsuarios ");
		
		Usuario[] listaUsuarios = manejadorUsuario.getAll();

		if (listaUsuarios == null) {
			throw new NoHayEntidadesParaListarException("No hay usuarios para listar");
		}

		String[] listaNicknames = new String[listaUsuarios.length];

		for (int i = 0; i < listaUsuarios.length; i++) {
			listaNicknames[i] = listaUsuarios[i].getNickname();
		}

		return listaNicknames;
	}

	public DtUsuario getUsuario(String nickname) throws EntidadNoExisteException, CampoInvalidoException {

		logger.log("- ControladorUsuario.getUsuario  nickname: '" + nickname + "'");

		if (nickname.isEmpty()) {
			throw new CampoInvalidoException("Nickname invalido");
		}

		if (!manejadorUsuario.contains(nickname)) {
			throw new EntidadNoExisteException("No existe usuario con ese nombre");
		}

		return manejadorUsuario.find(nickname).newDataType();
	}

	public void modificarUsuario(DtUsuario usuarioModificado) throws CampoInvalidoException {
		
		logger.log("- ControladorUsuario.modificarUsuario   " + usuarioModificado);
		
		if (hayCampoInvalidoModificarDtUsuario(usuarioModificado)) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalidoModificarUsuario(usuarioModificado));
		}
		if (!manejadorUsuario.contains(usuarioModificado.getNickname())) {
			throw new CampoInvalidoException("No hay usuario con ese nickname en el sistema");
		}

		Usuario viejoUsuario = manejadorUsuario.find(usuarioModificado.getNickname());

		if (usuarioModificado instanceof DtTurista) {

			DtTurista dtTuristaModificado = (DtTurista) usuarioModificado;

			if (!(viejoUsuario instanceof Turista)) {
				throw new CampoInvalidoException("No hay turista con ese nickname en el sistema");
			}

			Turista viejoTurista = (Turista) viejoUsuario;

			viejoTurista.setNombre(dtTuristaModificado.getNombre());
			viejoTurista.setApellido(dtTuristaModificado.getApellido());
			viejoTurista.setFechaNacimiento(dtTuristaModificado.getFechaNacimiento());
			viejoTurista.setNacionalidad(dtTuristaModificado.getNacionalidad());

			manejadorUsuario.add(viejoTurista);
			return;
		}

		DtProovedor dtProveedorModificado = (DtProovedor) usuarioModificado;

		if (!(viejoUsuario instanceof Proveedor)) {
			throw new CampoInvalidoException("No hay proveedor con ese nickname en el sistema");
		}

		Proveedor viejoProveedor = (Proveedor) viejoUsuario;

		viejoProveedor.setNombre(dtProveedorModificado.getNombre());
		viejoProveedor.setApellido(dtProveedorModificado.getApellido());
		viejoProveedor.setFechaNacimiento(dtProveedorModificado.getFechaNacimiento());
		viejoProveedor.setDescripcion(dtProveedorModificado.getDescripcion());
		viejoProveedor.setUrlSitioWeb(dtProveedorModificado.getUrlSitioWeb());

		manejadorUsuario.add(viejoProveedor);
	}

	public String[] listarTuristas() throws NoHayEntidadesParaListarException {
		
		logger.log("- ControladorUsuario.listarTuristas ");
		
		Turista[] listaUsuarios = manejadorUsuario.getAllTuristas();

		if (listaUsuarios == null) {
			throw new NoHayEntidadesParaListarException("No hay turistas para listar");
		}

		String[] listaNicknames = new String[listaUsuarios.length];

		for (int i = 0; i < listaUsuarios.length; i++) {
			listaNicknames[i] = listaUsuarios[i].getNickname();
		}

		return listaNicknames;
	}

	public String[] listarProveedores() throws NoHayEntidadesParaListarException {
		
		logger.log("- ControladorUsuario.listarProveedores ");
		
		
		Proveedor[] listaUsuarios = manejadorUsuario.getAllProveedores();

		if (listaUsuarios == null) {
			throw new NoHayEntidadesParaListarException("No hay proveedores para listar");
		}

		String[] listaNicknames = new String[listaUsuarios.length];

		for (int i = 0; i < listaUsuarios.length; i++) {
			listaNicknames[i] = listaUsuarios[i].getNickname();
		}

		return listaNicknames;
	}

	// ----------------------------------------------------------------
	// Metodos auxiliares

	private Boolean hayCampoInvalidoModificarDtUsuario(DtUsuario usuario) {

		// Implementar Bien

		return false;
	}

	private Boolean hayCampoInvalidoDtTurista(DtTurista turista) {

		Boolean hayCampoInvalido = turista.getNickname().isEmpty() || turista.getNombre().isEmpty()
				|| turista.getApellido().isEmpty() || turista.getEmail().isEmpty()
				|| turista.getFechaNacimiento() == null || turista.getNacionalidad().isEmpty();

		return hayCampoInvalido;
	}

	private Boolean hayCampoInvalidoDtProveedor(DtProovedor proveedor) {

		Boolean hayCampoInvalido = (proveedor.getNickname() == null || proveedor.getNickname().isEmpty())
				|| proveedor.getNombre().isEmpty() || proveedor.getApellido().isEmpty()
				|| proveedor.getEmail().isEmpty() || proveedor.getFechaNacimiento() == null
				|| (proveedor.getDescripcion() == null || proveedor.getDescripcion().isEmpty());

		return hayCampoInvalido;
	}

	private String mensajeErrorParaCampoInvalidoTurista(DtTurista turista) {
		String mensajeError = "";

		if (turista.getNombre().isEmpty()) {
			mensajeError = mensajeError.concat("nombre invalido ");
		}

		if (turista.getNickname().isEmpty()) {
			mensajeError = mensajeError.concat("nickname invalido ");
		}

		if (turista.getApellido().isEmpty()) {
			mensajeError = mensajeError.concat("apellido invalido ");
		}
		if (turista.getEmail().isEmpty()) {
			mensajeError = mensajeError.concat("email invalido ");
		}
		if (turista.getFechaNacimiento() == null) {
			mensajeError = mensajeError.concat("Fecha de nacimiento invalida ");
		}
		if (turista.getNacionalidad().isEmpty()) {
			mensajeError = mensajeError.concat("Nacionalidad invalida ");
		}
		return mensajeError;
	}

	private String mensajeErrorParaCampoInvalidoProveedor(DtProovedor proveedor) {
		String mensajeError = "";

		if (proveedor.getNombre() == null || proveedor.getNombre().isEmpty()) {
			mensajeError = mensajeError.concat("nombre invalido ");
		}

		if (proveedor.getNickname() == null || proveedor.getNickname().isEmpty()) {
			mensajeError = mensajeError.concat("nickname invalido ");
		}

		if (proveedor.getApellido().isEmpty()) {
			mensajeError = mensajeError.concat("apellido invalido ");
		}
		if (proveedor.getApellido().isEmpty()) {
			mensajeError = mensajeError.concat("email invalido ");
		}
		if (proveedor.getFechaNacimiento() == null) {
			mensajeError = mensajeError.concat("Fecha de nacimiento invalida ");
		}
		if (proveedor.getDescripcion() == null || proveedor.getDescripcion().isEmpty()) {
			mensajeError = mensajeError.concat("Descripcion invalida ");
		}
		return mensajeError;
	}

	private String mensajeErrorParaCampoInvalidoModificarUsuario(DtUsuario usuario) {
		// TODO: implementar mejor mensaje error
		return "Campo invalido";
	}
}
