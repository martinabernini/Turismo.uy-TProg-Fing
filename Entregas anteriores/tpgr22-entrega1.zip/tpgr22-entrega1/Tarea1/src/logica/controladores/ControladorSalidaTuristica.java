package logica.controladores;

import java.util.Map;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.MaximoDeTuristasAlcanzadoException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtSalidaTuristica;
import logica.entidades.ActividadTuristica;
import logica.entidades.InscripcionSalida;
import logica.entidades.SalidaTuristica;
import logica.entidades.Turista;
import logica.entidades.Usuario;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorInscripcionSalida;
import logica.interfaces.IManejadorSalidaTuristica;
import logica.interfaces.IManejadorUsuario;

public class ControladorSalidaTuristica implements IControladorSalidaTuristica {

	private IManejadorSalidaTuristica manejadorSalidaTuristica;
	private IManejadorUsuario manejadorUsuario;
	private IManejadorInscripcionSalida manejadorInscripcionSalida;
	private IManejadorActividadTuristica manejadorActividadTuristica;
	private ILogger logger;

	public ControladorSalidaTuristica(IManejadorSalidaTuristica manejadorSalidaTuristica,
			IManejadorUsuario manejadorUsuario, IManejadorInscripcionSalida manejadorInscripcionSalida,
			IManejadorActividadTuristica manejadorActividadTuristica, ILogger logger) {
		this.manejadorSalidaTuristica = manejadorSalidaTuristica;
		this.manejadorUsuario = manejadorUsuario;
		this.manejadorInscripcionSalida = manejadorInscripcionSalida;
		this.manejadorActividadTuristica = manejadorActividadTuristica;
		this.logger = logger;
	}

	public void darDeAltaSalidaTuristica(DtSalidaTuristica nuevaSalida)
			throws CampoInvalidoException, EntidadRepetidaException {

		logger.log("- ControladorSalidaTuristica.darDeAltaSalidaTuristica   " + nuevaSalida);
		
		// TODO: falta checkear la validez de las fechas
		Boolean hayCampoInvalido = (nuevaSalida.getNombreActividad() == null
				|| nuevaSalida.getNombreActividad().isEmpty() || nuevaSalida.getNombreSalida() == null
				|| nuevaSalida.getNombreSalida().isEmpty() || nuevaSalida.getLugarSalida() == null
				|| nuevaSalida.getLugarSalida().isEmpty() || nuevaSalida.getCantidadMaximaTuristas() < 0
				|| nuevaSalida.getFechaSalida() == null || nuevaSalida.getFechaAlta() == null
				|| nuevaSalida.getFechaSalida().before(nuevaSalida.getFechaAlta())
				);


		if (hayCampoInvalido) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalidoDtSalidaTuristica(nuevaSalida));
		}

		if (manejadorSalidaTuristica.contains(nuevaSalida.getNombreSalida())) {
			throw new EntidadRepetidaException("Ya hay una salida registrada con ese nombre");
		}

		if (!manejadorActividadTuristica.contains(nuevaSalida.getNombreActividad())) {
			throw new CampoInvalidoException("No hay actividad con ese nombre");
		}
		
		ActividadTuristica actividad = manejadorActividadTuristica.find(nuevaSalida.getNombreActividad());

		// Salida con link a Actividad
		SalidaTuristica salida = new SalidaTuristica(nuevaSalida.getNombreSalida(),
				nuevaSalida.getCantidadMaximaTuristas(), nuevaSalida.getFechaAlta(), nuevaSalida.getFechaSalida(),
				nuevaSalida.getLugarSalida(), actividad);


		// Link de Actividad a Salida
		actividad.agregarSalidaAsociada(salida);
		manejadorActividadTuristica.add(actividad);

		// Link de manejador a Salida
		manejadorSalidaTuristica.add(salida);
	}

	public String[] listarSalidasAsociadasAActividadTuristica(String nombreActividad)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		logger.log("- ControladorSalidaTuristica.listarSalidasAsociadasAActividadTuristica   nombreActividad:" + nombreActividad);
		
		if (nombreActividad.isEmpty()) {
			throw new CampoInvalidoException("Nombre de actividad invalido");
		}

		SalidaTuristica[] salidas = manejadorSalidaTuristica.getAllAsociadasAActividadTuristica(nombreActividad);

		if (salidas == null) {
			throw new NoHayEntidadesParaListarException("No hay salidas para listar");
		}

		String[] nombreSalidas = new String[salidas.length];

		for (int i = 0; i < salidas.length; i++) {
			nombreSalidas[i] = salidas[i].getNombre();
		}

		return nombreSalidas;

	}

	public DtSalidaTuristica getSalidaTuristica(String nombre) throws EntidadNoExisteException, CampoInvalidoException {
		
		logger.log("- ControladorSalidaTuristica.getSalidaTuristica   nombre:" + nombre);
		
		if (nombre.isEmpty()) {
			throw new CampoInvalidoException("Nombre salida invalido");
		}

		if (!manejadorSalidaTuristica.contains(nombre)) {
			throw new EntidadNoExisteException("No existe salida con ese nombre");
		}

		return manejadorSalidaTuristica.find(nombre).newDataType();
	}

	public String[] listarSalidasVigentesAsociadasAActividadTuristica(String nombreActividad)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		logger.log("- ControladorSalidaTuristica.listarSalidasVigentesAsociadasAActividadTuristica   nombre:" + nombreActividad);
		
		if (nombreActividad.isEmpty()) {
			throw new CampoInvalidoException("Nombre de actividad invalido");
		}

		SalidaTuristica[] salidas = manejadorSalidaTuristica.getAllVigentesAsociadasAActividad(nombreActividad);

		if (salidas == null) {
			throw new NoHayEntidadesParaListarException("No hay salidas para listar");
		}

		String[] nombreSalidas = new String[salidas.length];

		for (int i = 0; i < salidas.length; i++) {
			nombreSalidas[i] = salidas[i].getNombre();
		}
		
		return nombreSalidas;
	}

	public void inscribirTuristaASalidaTuristica(DtInscripcionSalida nuevaInscripcion)
			throws EntidadRepetidaException, CampoInvalidoException, MaximoDeTuristasAlcanzadoException {

		logger.log("- ControladorSalidaTuristica.inscribirTuristaASalidaTuristica   " + nuevaInscripcion);
		
		if (hayCampoInvalidoEnInscripcionSalida(nuevaInscripcion)) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalidoDtInscripcionSalida(nuevaInscripcion));
		}

		if (!manejadorSalidaTuristica.contains(nuevaInscripcion.getNombreSalidaTuristica())) {
			throw new CampoInvalidoException("No hay salida turistica con ese nombre: " + nuevaInscripcion.getNombreSalidaTuristica());
		}

		SalidaTuristica salida = manejadorSalidaTuristica.find(nuevaInscripcion.getNombreSalidaTuristica());

		if (!manejadorUsuario.contains(nuevaInscripcion.getNickname())) {
			throw new CampoInvalidoException("No hay usuario con ese nickname");
		}

		Usuario usuario = manejadorUsuario.find(nuevaInscripcion.getNickname());
		
		
		
		if (!(usuario instanceof Turista)) {
			throw new CampoInvalidoException("No hay turista con ese nickname");
		}
		
		if(usuario instanceof Turista) {
			Boolean actuar = mensajeErrorUsrRepetido((Turista) usuario, nuevaInscripcion);
			if (actuar) {
				throw new EntidadRepetidaException("Este usuario ya tiene una inscripcion a la salida seleccionada");
			}
		}

		if (salida.cuposDisponibles() <= 0) {
			throw new MaximoDeTuristasAlcanzadoException("No hay cupos disponibles para esa salida");
		}

		if (salida.cuposDisponibles() < nuevaInscripcion.getCantidadTuristas()) {
			throw new MaximoDeTuristasAlcanzadoException("Solo quedan " + Integer.toString(salida.cuposDisponibles())
					+ " cupos disponibles para esa salida");
		}

		Turista turista = (Turista) usuario;

		// Se crea InscripcionSalida con link a Salida
		InscripcionSalida inscripcion = new InscripcionSalida(manejadorInscripcionSalida.count(),
				nuevaInscripcion.getFechaInscripcion(), nuevaInscripcion.getCantidadTuristas(), salida, nuevaInscripcion.getCosto());

		// Link turista a InscripcionSalida
		turista.agregarInscripcionASalida(inscripcion);
		manejadorUsuario.add(turista);

		// Link manejador a InscripcionSalida
		manejadorInscripcionSalida.add(inscripcion);

	}

	// ------------------------------------------------------------------------------

	private Boolean hayCampoInvalidoEnInscripcionSalida(DtInscripcionSalida nuevaInscripcio) {
		// TODO: Implementar chequeos de validez
		return false;
	}

	
	
	private String mensajeErrorParaCampoInvalidoDtSalidaTuristica(DtSalidaTuristica salida) {
		// TODO: Implementar
		return "Campo invalido";
	};

	private String mensajeErrorParaCampoInvalidoDtInscripcionSalida(DtInscripcionSalida inscripcionSalida) {
		// TODO: Implementar falta implementar en controlador salida turistica
		return "Campo invalido";
	}

	private Boolean mensajeErrorUsrRepetido(Turista tur, DtInscripcionSalida nuevaInscripcion) {
		Map<Integer, InscripcionSalida> inscripciones= tur.getInscripciones();
		for (InscripcionSalida salida : inscripciones.values()) {
	        if(salida.getSalida().getNombre() == nuevaInscripcion.getNombreSalidaTuristica()) {
	        	return true;
	        }
	    }
		return false;
	}
}
