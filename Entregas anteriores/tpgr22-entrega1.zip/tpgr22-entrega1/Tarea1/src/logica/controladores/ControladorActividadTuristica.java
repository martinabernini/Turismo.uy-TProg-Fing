
package logica.controladores;

import logica.datatypes.DtActividadTuristica;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.ILogger;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.entidades.ActividadTuristica;
import logica.entidades.Departamento;
import logica.entidades.Proveedor;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;
import logica.interfaces.IManejadorUsuario;

public class ControladorActividadTuristica implements IControladorActividadTuristica {

	private IManejadorActividadTuristica manejadorActividadTuristica;
	private IManejadorDepartamento manejadorDepartamento;
	private IManejadorUsuario manejadorUsuario;
	private ILogger logger;

	public ControladorActividadTuristica(IManejadorActividadTuristica manejadorActividadTuristica,
			IManejadorDepartamento manejadorDepartamento, IManejadorUsuario manejadorUsuario, ILogger logger) {
		this.manejadorActividadTuristica = manejadorActividadTuristica;
		this.manejadorDepartamento = manejadorDepartamento;
		this.manejadorUsuario = manejadorUsuario;
		this.logger = logger;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public void darDeAltaActividadTuristica(DtActividadTuristica nuevaActividad)
			throws CampoInvalidoException, EntidadRepetidaException {

		logger.log("- ControladorActividadTuristica.darDeAltaActividadTuristica: " + nuevaActividad.toString());

		if (hayCampoInvalido(nuevaActividad)) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalido(nuevaActividad));
		}

		if (manejadorActividadTuristica.contains(nuevaActividad.getNombre()))
			throw new EntidadRepetidaException("Ya hay una actividad turistica con ese nombre");

		if (!manejadorDepartamento.contains(nuevaActividad.getDepartamento())) {
			throw new CampoInvalidoException(
					"No existe ese departamento en el sistema: " + nuevaActividad.getDepartamento());
		}

		Departamento depto = manejadorDepartamento.find(nuevaActividad.getDepartamento());

		Proveedor proveedor = (Proveedor) manejadorUsuario.find(nuevaActividad.getProovedor());

		if (proveedor == null) {
			throw new CampoInvalidoException("Nombre de proveedor invalido: " + nuevaActividad.getProovedor());
		}

		// Se crea la actividad con link al Departamento
		ActividadTuristica act = new ActividadTuristica(nuevaActividad.getNombre(), nuevaActividad.getDescripcion(),
				nuevaActividad.getDuracionHrs(), nuevaActividad.getCostoPorPersona(), nuevaActividad.getCiudad(),
				nuevaActividad.getFechaAlta(), depto, proveedor);

		// Link de majeador a Actividad
		manejadorActividadTuristica.add(act);

		// Link de Departamento a Actividad
		depto.agregarActividadTuristica(act);
		manejadorDepartamento.update(depto);

		proveedor.agregarActividadTuristica(act);
		manejadorUsuario.update(proveedor);
	}

	public String[] listarActividadesAsociadasADepartamento(String nombreDepartamento)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		logger.log("- ControladorActividadTuristica.listarActividadesAsociadasADepartamento: " + nombreDepartamento);

		if (nombreDepartamento == null || nombreDepartamento.isEmpty()) {
			throw new CampoInvalidoException("Nombre de departamento invalido");
		}

		if (!manejadorDepartamento.contains(nombreDepartamento)) {
			throw new CampoInvalidoException("No existe ese departamento en el sistema");
		}

		ActividadTuristica[] actividades = manejadorDepartamento
				.getAllActividadesAsociadasADepartamento(nombreDepartamento);

		if (actividades == null) {
			throw new NoHayEntidadesParaListarException("No hay actividades asociadas a departamento");
		}

		String[] nombreActs = new String[actividades.length];

		for (int i = 0; i < actividades.length; i++) {
			nombreActs[i] = actividades[i].getNombre();
		}

		return nombreActs;
	}

	public DtActividadTuristica getActividadTuristica(String nombre)
			throws EntidadNoExisteException, CampoInvalidoException {

		logger.log("- ControladorActividadTuristica.getActividadTuristica: " + nombre);

		if (nombre == null || nombre.isEmpty()) {
			throw new CampoInvalidoException("Nombre actividad invalido: " + nombre);
		}

		if (!manejadorActividadTuristica.contains(nombre)) {
			throw new EntidadNoExisteException("No existe actividad con ese nombre");
		}

		return manejadorActividadTuristica.find(nombre).newDataType();
	}

	public String[] listarActividadesAsocadasADepartamentoNoEnPaquete(String nombreDepartamento, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		logger.log("- ControladorActividadTuristica.listarActividadesAsocadasADepartamentoNoEnPaquete  departamento: '"
				+ nombreDepartamento + "', paquete: '" + nombrePaquete + "'");

		if (nombreDepartamento.isEmpty() || nombrePaquete.isEmpty()) {
			throw new CampoInvalidoException("Campo invalido");
		}

		ActividadTuristica[] actividadesNoEnPaquete = manejadorDepartamento
				.getAllActividadesAsociadasADepartamentoNoEnPaquete(nombreDepartamento, nombrePaquete);

		if (actividadesNoEnPaquete == null) {
			throw new NoHayEntidadesParaListarException("No hay actividades para listar que no esten en ese paquete");
		}

		String[] nombreActividadesNoEnPaquete = new String[actividadesNoEnPaquete.length];

		for (int i = 0; i < actividadesNoEnPaquete.length; i++) {
			nombreActividadesNoEnPaquete[i] = actividadesNoEnPaquete[i].getNombre();
		}

		return nombreActividadesNoEnPaquete;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	private Boolean hayCampoInvalido(DtActividadTuristica actividad) {
		Boolean hayCampoInvalido = (actividad.getNombre() == null || actividad.getNombre().isEmpty()
				|| actividad.getDescripcion() == null || actividad.getDescripcion().isEmpty()
				|| actividad.getDuracionHrs() < 0 || actividad.getCostoPorPersona() < 0 || actividad.getCiudad() == null
				|| actividad.getCiudad().isEmpty() || actividad.getFechaAlta() == null
				|| actividad.getDepartamento() == null || actividad.getDepartamento().isEmpty()
				|| actividad.getProovedor() == null || actividad.getProovedor().isEmpty());

		return hayCampoInvalido;
	}

	private String mensajeErrorParaCampoInvalido(DtActividadTuristica actividad) {
		String mensajeError = "";

		if (actividad.getNombre() == null || actividad.getNombre().isEmpty()) {
			mensajeError = mensajeError.concat("Nombre invalido. ");
		}

		if (actividad.getDescripcion() == null || actividad.getDescripcion().isEmpty()) {
			mensajeError = mensajeError.concat("Descripcion invalida. ");
		}

		if (actividad.getDuracionHrs() < 0) {
			mensajeError = mensajeError.concat("Duracion en horas invilida. ");
		}
		if (actividad.getCostoPorPersona() < 0) {
			mensajeError = mensajeError.concat("Costo por persona invilido. ");
		}
		if (actividad.getCiudad() == null || actividad.getCiudad().isEmpty()) {
			mensajeError = mensajeError.concat("Ciudad invilida. ");
		}
		if (actividad.getFechaAlta() == null) {
			mensajeError = mensajeError.concat("Fecha de alta invilida. ");
		}
		if (actividad.getDepartamento() == null || actividad.getDepartamento().isEmpty()) {
			mensajeError = mensajeError.concat("Departamento invilido. ");
		}
		if (actividad.getProovedor() == null || actividad.getProovedor().isEmpty()) {
			mensajeError = mensajeError.concat("Proovedor invilido. ");
		}
		return mensajeError;
		//return "falta implementar mensaje error en cotnrolador actividad";
	}

}
