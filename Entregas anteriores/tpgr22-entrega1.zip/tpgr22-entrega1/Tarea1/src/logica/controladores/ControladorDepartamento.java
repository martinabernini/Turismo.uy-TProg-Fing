package logica.controladores;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.entidades.Departamento;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorDepartamento;

public class ControladorDepartamento implements IControladorDepartamento {

	private IManejadorDepartamento manejadorDepartamento;
	private ILogger logger;


	public ControladorDepartamento(IManejadorDepartamento manejadorDepartamento, ILogger logger) {
		this.manejadorDepartamento = manejadorDepartamento;
		this.logger = logger;
	}
	
	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public String[] listarDepartamentos() throws NoHayEntidadesParaListarException {
		logger.log("- ControladorDepartamento.listarDepartamentos" );
		
		Departamento[] listaDepartamentos = manejadorDepartamento.getAll();

		if (listaDepartamentos == null) {
			throw new NoHayEntidadesParaListarException("No hay departamentos para listar");
		}

		String[] listaNombres = new String[listaDepartamentos.length];

		for (int i = 0; i < listaDepartamentos.length; i++) {
			listaNombres[i] = listaDepartamentos[i].getNombre();
		}

		return listaNombres;
	}
	
	public void darDeAltaDepartamento(String nombre, String descripcion, String url)
			throws CampoInvalidoException, EntidadRepetidaException {

		logger.log("- ControladorDepartamento.darDeAltaDepartamento   nombre: '" + nombre  + "' desc: '" + descripcion + "', url: '" + url + "'" );
		
		Boolean hayCampoInvalido = (nombre.isEmpty() || descripcion.isEmpty() || url.isEmpty());

		if (hayCampoInvalido) {
			throw new CampoInvalidoException(mensajeErrorParaCampoInvalido(nombre, descripcion, url));
		}
		
		if (manejadorDepartamento.contains(nombre)) {
			throw new EntidadRepetidaException("Ya hay un departamento registrado con ese nombre");
		}

		manejadorDepartamento.add(new Departamento(nombre, descripcion, url));

	}

	// ----------------------------------------------------------------
	// Metodos auxiliares
	
	private String mensajeErrorParaCampoInvalido(String nombre, String descripcion, String url) {
		String mensajeError = "";

		if (nombre.isEmpty()) {
			mensajeError= mensajeError.concat("nombre invalido ");
		}

		if (descripcion.isEmpty()) {
			mensajeError= mensajeError.concat("descripcion invalida ");
		}

		if (url.isEmpty()) {
			mensajeError= mensajeError.concat("url invalida ");
		}
		return mensajeError;
	}
	
}
