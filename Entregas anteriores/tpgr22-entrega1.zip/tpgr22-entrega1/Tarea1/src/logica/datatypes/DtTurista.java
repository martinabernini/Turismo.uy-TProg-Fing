package logica.datatypes;

import java.util.Date;
import java.util.Map;
import java.util.Objects;

import logica.entidades.InscripcionSalida;

public class DtTurista extends DtUsuario {

	private String nacionalidad;

	private Map<Integer, InscripcionSalida> inscripcionesASalidas;

	// constructor

	public DtTurista() {
		super();
	}

	public DtTurista(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
			String nacionalidad, Map<Integer, InscripcionSalida> inscripcionesASalidas) {
		super(nickname, nombre, apellido, email, fechaNacimiento);
		this.nacionalidad = nacionalidad;
		this.inscripcionesASalidas = inscripcionesASalidas;
	}

	public DtTurista(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
			String nacionalidad) {
		super(nickname, nombre, apellido, email, fechaNacimiento);
		this.nacionalidad = nacionalidad;
		this.inscripcionesASalidas = null;
	}

	// Getters y setters

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String[] getInscripcionesASalidas() {
		String[] res = new String[inscripcionesASalidas.size()];
		int i = 0;
		for (InscripcionSalida salida : inscripcionesASalidas.values()) {
			res[i] = salida.getSalida().getNombre();
			i++;
		}
		return res;
	}

	public void setInscripcionesASalidas(Map<Integer, InscripcionSalida> inscripcionesASalidas) {
		this.inscripcionesASalidas = inscripcionesASalidas;
	}

	// ---------------------------------------------------------------

	@Override
	public String toString() {
		return "DtTurista [nacionalidad=" + nacionalidad + ", inscripcionesASalidas=" + inscripcionesASalidas
				+ ", getNickname()=" + getNickname() + ", getNombre()=" + getNombre() + ", getApellido()="
				+ getApellido() + ", getEmail()=" + getEmail() + ", getFechaNacimiento()=" + getFechaNacimiento()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtTurista other = (DtTurista) obj;
		return Objects.equals(inscripcionesASalidas, other.inscripcionesASalidas)
				&& Objects.equals(nacionalidad, other.nacionalidad);
	}

}
