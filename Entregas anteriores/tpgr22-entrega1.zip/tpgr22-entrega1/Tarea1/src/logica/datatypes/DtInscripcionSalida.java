package logica.datatypes;

import java.util.Date;
import java.util.Objects;

public class DtInscripcionSalida {

	private String nickname;
	private String nombreSalidaTuristica;
	private int cantidadTuristas;
	private Date fechaInscripcion;
	private float costo;

	// Constructor

	public DtInscripcionSalida() {
	}

	public DtInscripcionSalida(String nickname, String nombreSalidaTuristica, int cantidadTuristas, float costo,
			Date fechaInscripcion) {

		this.nickname = nickname;
		this.nombreSalidaTuristica = nombreSalidaTuristica;
		this.cantidadTuristas = cantidadTuristas;
		this.costo= costo;
		this.fechaInscripcion = fechaInscripcion;

	}

	// ----------------------------------------------------------------

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getNombreSalidaTuristica() {
		return nombreSalidaTuristica;
	}

	public void setNombreSalidaTuristica(String nombreSalidaTuristica) {
		this.nombreSalidaTuristica = nombreSalidaTuristica;
	}

	public int getCantidadTuristas() {
		return cantidadTuristas;
	}

	public void setCantidadTuristas(int cantidadTuristas) {
		this.cantidadTuristas = cantidadTuristas;
	}

	public Date getFechaInscripcion() {
		return fechaInscripcion;
	}

	public void setFechaInscripcion(Date fechaInscripcion) {
		this.fechaInscripcion = fechaInscripcion;
	}
	
	public float getCosto() {
		return costo;
	}
	
	public void setCosto(float costo) {
		this.costo=costo;
	}

	// ----------------------------------------------------------------

	@Override
	public String toString() {
		return "DtInscripcionSalida [nickname=" + nickname + ", nombreSalidaTuristica=" + nombreSalidaTuristica
				+ ", cantidadTuristas=" + cantidadTuristas + ", fechaInscripcion=" + fechaInscripcion + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtInscripcionSalida other = (DtInscripcionSalida) obj;
		return cantidadTuristas == other.cantidadTuristas && Objects.equals(fechaInscripcion, other.fechaInscripcion)
				&& Objects.equals(nickname, other.nickname)
				&& Objects.equals(nombreSalidaTuristica, other.nombreSalidaTuristica);
	}

}
