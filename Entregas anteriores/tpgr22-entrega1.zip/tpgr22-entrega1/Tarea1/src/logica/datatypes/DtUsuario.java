package logica.datatypes;

import java.util.Date;
import java.util.Objects;

public class DtUsuario {

	
	private String nickname;
	private String nombre;
	private String Apellido;
	private String email;
	private Date fechaNacimiento;
	
	//Constructor
	
	public DtUsuario() {
	}
	
	
	public DtUsuario(String nickname, String nombre, String apellido, String email, Date fechaNacimiento) {
		super();
		this.nickname = nickname;
		this.nombre = nombre;
		Apellido = apellido;
		this.email = email;
		this.fechaNacimiento = fechaNacimiento;
	}

	//Getters y setters
	
	
	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	// ---------------------------------------------------------------

	@Override
	public String toString() {
		return "DtUsuario [nickname=" + nickname + ", nombre=" + nombre + ", Apellido=" + Apellido + ", email=" + email
				+ ", fechaNacimiento=" + fechaNacimiento + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtUsuario other = (DtUsuario) obj;
		return Objects.equals(Apellido, other.Apellido) && Objects.equals(email, other.email)
				&& Objects.equals(fechaNacimiento, other.fechaNacimiento) && Objects.equals(nickname, other.nickname)
				&& Objects.equals(nombre, other.nombre);
	}
	
	
	
	
	
}
