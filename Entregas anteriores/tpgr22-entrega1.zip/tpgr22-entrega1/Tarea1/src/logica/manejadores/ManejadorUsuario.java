package logica.manejadores;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import logica.entidades.Proveedor;
import logica.entidades.Turista;
import logica.entidades.Usuario;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorUsuario;

public class ManejadorUsuario implements IManejadorUsuario {
	
	private Map<String, Usuario> usuarios;
	private Set<String> emailRegistrado;
	

	private static ILogger logger;
	private static ManejadorUsuario instancia = null;


	private ManejadorUsuario() {
		usuarios = new HashMap<String, Usuario>();
		emailRegistrado = new HashSet<String>();
	}
	
	public static ManejadorUsuario getInstance(ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorUsuario();
		
		ManejadorUsuario.logger = logger;
		
		return instancia;
	}

	public void add(Usuario usuario) {
		logger.log("-- ManejadorUsuario.add: " + usuario.toString());
		usuarios.put(usuario.getNickname(), usuario);
		emailRegistrado.add(usuario.getEmail());
	}
	

	public void update(Usuario usuario) {
		logger.log("-- ManejadorUsuario.update: " + usuario.toString());
		usuarios.put(usuario.getNickname(), usuario);
	}

	public Usuario[] getAll() {
		logger.log("-- ManejadorUsuario.getAll");
		if (usuarios.isEmpty()) {
			logger.log("---- usuarios esta vacio");
			return null;
		}
		Usuario[] allUsuarios = usuarios.values().toArray(new Usuario[0]);
		
		logger.log("---- se devulven: " + allUsuarios.length + " usuarios");
		
		return allUsuarios;
	}

	public Usuario find(String nickname) {
		logger.log("-- ManejadorUsuario.find para el nickname: '" + nickname + "'");
		return usuarios.get(nickname);
	}

	public boolean contains(String nicknameUsuario) {
		logger.log("-- ManejadorUsuario.contains para el nickname: '" + nicknameUsuario  + "'");
		return usuarios.containsKey(nicknameUsuario);
	}

	public Proveedor[] getAllProveedores() {
		logger.log("-- ManejadorUsuario.getAllProveedores ");
		
		List<Proveedor> listaProveedores = new ArrayList<Proveedor>();
		
		for (Usuario usuario: usuarios.values()) {
			if (usuario instanceof Proveedor) {
				listaProveedores.add((Proveedor) usuario);
			}
		}

		logger.log("---- se devuelve: " + listaProveedores.toString());
		
		return listaProveedores.toArray(new Proveedor[0]);
	}

	public Turista[] getAllTuristas() {
		logger.log("-- ManejadorUsuario.getAllTuristas ");
		
		List<Turista> listaTuristas = new ArrayList<Turista>();

		for (Usuario usuario : usuarios.values()) {
			if (usuario instanceof Turista) {
				listaTuristas.add((Turista) usuario);
			}
		}

		logger.log("---- se devuelve: " + listaTuristas.toString());
		
		return listaTuristas.toArray(new Turista[0]);
	}
	
	public boolean emailYaRegistrado(String email) {
		return emailRegistrado.contains(email);
	}

}
