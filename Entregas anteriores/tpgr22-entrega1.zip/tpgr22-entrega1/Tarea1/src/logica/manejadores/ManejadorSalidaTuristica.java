package logica.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import logica.entidades.ActividadTuristica;
import logica.entidades.SalidaTuristica;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorSalidaTuristica;

public class ManejadorSalidaTuristica implements IManejadorSalidaTuristica {

	private static IManejadorActividadTuristica manejadorActividadTuristica;
	private static ILogger logger;

	private Map<String, SalidaTuristica> salidas;

	private static ManejadorSalidaTuristica instancia = null;

	private ManejadorSalidaTuristica() {
		salidas = new HashMap<String, SalidaTuristica>();
	}

	public static ManejadorSalidaTuristica getInstance(IManejadorActividadTuristica manejadorActividadTuristica,
			ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorSalidaTuristica();

		ManejadorSalidaTuristica.manejadorActividadTuristica = manejadorActividadTuristica;
		ManejadorSalidaTuristica.logger = logger;

		return instancia;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------
	
	public void add(SalidaTuristica salida) {
		logger.log("-- ManejadorSalidaTuristica.add salida: " + salida.toString());
		salidas.put(salida.getNombre(), salida);
	}

	public SalidaTuristica[] getAllAsociadasAActividadTuristica(String nombreActividad) {
		logger.log("-- ManejadorSalidaTuristica.getAllAsociadasAActividadTuristica nombreActividad: '" + nombreActividad + "'");
		if (!manejadorActividadTuristica.contains(nombreActividad)) {
			return null;
		}

		ActividadTuristica actividad = manejadorActividadTuristica.find(nombreActividad);

		List<SalidaTuristica> salidasList = actividad.getSalidasAsociadas().values().stream()
				.collect(Collectors.toList());

		SalidaTuristica[] salidasArray = salidasList.toArray(new SalidaTuristica[0]);

		return salidasArray;
	}

	public SalidaTuristica find(String nombre) {
		logger.log("-- ManejadorSalidaTuristica.find nombre: '" + nombre + "'");
		return salidas.get(nombre);
	}

	public SalidaTuristica[] getAllVigentesAsociadasAActividad(String nombreActividad) {
		logger.log("-- ManejadorSalidaTuristica.getAllVigentesAsociadasAActividad nombreActividad: '" + nombreActividad + "'");
		if (!manejadorActividadTuristica.contains(nombreActividad)) {
			return null;
		}

		ActividadTuristica actividad = manejadorActividadTuristica.find(nombreActividad);

		List<SalidaTuristica> salidasList = actividad.getSalidasAsociadas().values().stream()
				.collect(Collectors.toList());

		List<SalidaTuristica> salidasVigentesList = new ArrayList<SalidaTuristica>();

		for (SalidaTuristica salida : salidasList) {
			if (esVigenteSalida(salida))
				salidasVigentesList.add(salida);
		}

		return salidasVigentesList.toArray(new SalidaTuristica[0]);
	}

	public Boolean contains(String nombreSalida) {
		logger.log("-- ManejadorSalidaTuristica.contains nombreSalida: '" + nombreSalida + "'");
		return salidas.containsKey(nombreSalida);
	}

	// -----------------------------------------------------------------------------------

	private Boolean esVigenteSalida(SalidaTuristica salida) {
		logger.log("-- ManejadorSalidaTuristica.esVigenteSalida salida: " + salida + "<-  FALTA IMPLEMENTAR!!!!");
		return salida.getFechaSalida().after(new Date());
	}

}
