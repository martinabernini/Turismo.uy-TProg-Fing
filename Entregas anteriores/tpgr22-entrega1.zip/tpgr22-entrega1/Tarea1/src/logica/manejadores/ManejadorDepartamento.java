package logica.manejadores;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import logica.entidades.ActividadTuristica;
import logica.entidades.Departamento;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorDepartamento;

public class ManejadorDepartamento implements IManejadorDepartamento {

	private Map<String, Departamento> departamentos;

	private static ILogger logger;

	private static ManejadorDepartamento instancia = null;

	private ManejadorDepartamento() {
		departamentos = new HashMap<String, Departamento>();
	}

	public static ManejadorDepartamento getInstance(ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorDepartamento();
		
		ManejadorDepartamento.logger = logger;
		
		return instancia;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public void add(Departamento departamento) {
		logger.log("-- ManejadorDepartamento.add departamento: " + departamento);
		departamentos.put(departamento.getNombre(), departamento);
	}

	public void update(Departamento departamento) {
		logger.log("-- ManejadorDepartamento.update departamento: " + departamento);
		departamentos.put(departamento.getNombre(), departamento);
	}

	public Departamento[] getAll() {
		logger.log("-- ManejadorDepartamento.getAll");

		if (departamentos.isEmpty()) {
			logger.log("---- departamentos esta vacio");
			return null;
		}

		Departamento[] allDepartamentos = departamentos.values().toArray(new Departamento[0]);

		for (Departamento departamento : allDepartamentos) {
			logger.log("---- se devulve: " + departamento);
		}

		return allDepartamentos;

	}

	public Boolean contains(String nombre) {
		logger.log("-- ManejadorDepartamento.contains para el nombre: '" + nombre + "'");
		return departamentos.containsKey(nombre);
	}

	public Departamento find(String nombre) {
		logger.log("-- ManejadorDepartamento.find para el nombre: '" + nombre + "'");
		return departamentos.get(nombre);
	}

	public ActividadTuristica[] getAllActividadesAsociadasADepartamento(String nombreDepartamento) {
		logger.log("-- ManejadorDepartamento.getAllActividadesAsociadasADepartamento para el departamento: '"
				+ nombreDepartamento + "'");
		if (!departamentos.containsKey(nombreDepartamento))
			return null;

		Map<String, ActividadTuristica> actividadesEnDepartamentoMap = departamentos.get(nombreDepartamento)
				.getActividadesTuristicas();

		if (actividadesEnDepartamentoMap.isEmpty())
			return null;

		List<ActividadTuristica> actividadesEnDepartamentoList = actividadesEnDepartamentoMap.values().stream()
				.collect(Collectors.toList());

		ActividadTuristica[] actividadesEnDepartamentoArray = actividadesEnDepartamentoList
				.toArray(new ActividadTuristica[0]);

		return actividadesEnDepartamentoArray;
	}

	public ActividadTuristica[] getAllActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepartamento,
			String nombrePaquete) {

		logger.log("-- ManejadorDepartamento.getAllActividadesAsociadasADepartamentoNoEnPaquete para el departamento: '"
				+ nombreDepartamento + "'. y paquete: '" + nombrePaquete + "'");

		if (!departamentos.containsKey(nombreDepartamento))
			return null;

		Map<String, ActividadTuristica> actividadesEnDepartamentoMap = departamentos.get(nombreDepartamento)
				.getActividadesTuristicas();

		if (actividadesEnDepartamentoMap.isEmpty())
			return null;

		List<ActividadTuristica> actividadesNoEnPaqueteList = new ArrayList<ActividadTuristica>();

		List<ActividadTuristica> actividadesEnDepartamentoList = actividadesEnDepartamentoMap.values().stream()
				.collect(Collectors.toList());

		for (ActividadTuristica actividad : actividadesEnDepartamentoList) {
			Boolean actividadEstaEnPaquete = actividad.getPaquetesAsociados().containsKey(nombrePaquete);
			if (!actividadEstaEnPaquete)
				actividadesNoEnPaqueteList.add(actividad);
		}

		ActividadTuristica[] actividadesEnDepartamentoNoEnPaqueteArray = actividadesNoEnPaqueteList
				.toArray(new ActividadTuristica[0]);

		return actividadesEnDepartamentoNoEnPaqueteArray;
	}

}
