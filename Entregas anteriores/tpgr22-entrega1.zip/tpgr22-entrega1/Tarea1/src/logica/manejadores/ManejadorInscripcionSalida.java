package logica.manejadores;

import java.util.HashMap;
import java.util.Map;

import logica.entidades.InscripcionSalida;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorInscripcionSalida;

public class ManejadorInscripcionSalida implements IManejadorInscripcionSalida {

	private Map<Integer, InscripcionSalida> inscripcionesSalidas;

	private static ILogger logger;

	private static ManejadorInscripcionSalida instancia = null;

	private ManejadorInscripcionSalida() {
		inscripcionesSalidas = new HashMap<Integer, InscripcionSalida>();
	}

	public static ManejadorInscripcionSalida getInstance(ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorInscripcionSalida();
		
		ManejadorInscripcionSalida.logger = logger;
		
		return instancia;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------
	
	public void add(InscripcionSalida nuevaInscripcion) {
		logger.log("-- ManejadorInscripcionSalida.add nuevaInscripcion: " + nuevaInscripcion.toString());
		inscripcionesSalidas.put(nuevaInscripcion.getId(), nuevaInscripcion);
	}

	public int count() {
		logger.log("-- ManejadorInscripcionSalida.count: " + inscripcionesSalidas.size());
		return inscripcionesSalidas.size();
	}

}
