package logica.manejadores;

import java.util.HashMap;
import java.util.Map;

import logica.entidades.PaqueteActividades;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorPaqueteActividades;

public class ManejadorPaqueteActividades implements IManejadorPaqueteActividades {

	private Map<String, PaqueteActividades> paquetes;
	
	private static ILogger logger;
	
	private static ManejadorPaqueteActividades instancia = null;

	private ManejadorPaqueteActividades(){
		paquetes = new HashMap<String, PaqueteActividades>();
	}
	
	public static ManejadorPaqueteActividades getInstance(ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorPaqueteActividades();
		
		ManejadorPaqueteActividades.logger = logger;
		
		return instancia;
	}
	
	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public void add(PaqueteActividades paquete) {
		logger.log("-- ManejadorPaqueteActividades.add paquete: " + paquete);
		paquetes.put(paquete.getNombre(), paquete);
	}

	public PaqueteActividades[] getAll() {
		logger.log("-- ManejadorPaqueteActividades.getAll");
		
		if (paquetes.isEmpty()) {
			logger.log("---- paquetes esta vacio");
			return null;
		}

		PaqueteActividades[] allPaquetes = paquetes.values().toArray(new PaqueteActividades[0]);

		for (PaqueteActividades paquete : allPaquetes) {
			logger.log("---- se devulve: " + paquete);
		}

		return allPaquetes;
	}

	public PaqueteActividades find(String nombre) {
		logger.log("-- ManejadorPaqueteActividades.find nombre: " + nombre);
		return paquetes.get(nombre);
	}

	public void update(PaqueteActividades paqueteModificado) {
		logger.log("-- ManejadorPaqueteActividades.update  " + paqueteModificado);
		paquetes.put(paqueteModificado.getNombre(), paqueteModificado);
	}

	public Boolean contains(String nombrePaqueteActividades) {
		logger.log("-- ManejadorPaqueteActividades.contains  " + nombrePaqueteActividades);
		return paquetes.containsKey(nombrePaqueteActividades);
	}

}
