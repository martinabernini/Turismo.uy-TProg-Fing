package logica.manejadores;

import java.util.HashMap;
import java.util.Map;

import logica.entidades.ActividadTuristica;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;

public class ManejadorActividadTuristica implements IManejadorActividadTuristica {

	private Map<String, ActividadTuristica> actividades;

	private static IManejadorDepartamento manejadorDepartamento;
	private static ILogger logger;

	private static ManejadorActividadTuristica instancia = null;

	public static ManejadorActividadTuristica getInstance(IManejadorDepartamento manejadorDepartamento,
			ILogger logger) {
		if (instancia == null)
			instancia = new ManejadorActividadTuristica();
		
		ManejadorActividadTuristica.manejadorDepartamento = manejadorDepartamento;
		ManejadorActividadTuristica.logger = logger;
		
		return instancia;
	}

	private ManejadorActividadTuristica() {
		actividades = new HashMap<String, ActividadTuristica>();
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public void add(ActividadTuristica actividad) {
		logger.log("-- ManejadorActividadTuristica.add actividad: " + actividad.toString());
		this.actividades.put(actividad.getNombre(), actividad);
	}

	public void update(ActividadTuristica actividadModificada) {
		logger.log("-- ManejadorActividadTuristica.update actividad: " + actividadModificada.toString());
		this.actividades.put(actividadModificada.getNombre(), actividadModificada);
	}
	
	
	public ActividadTuristica[] getAll() {
		logger.log("-- ManejadorActividadTuristica.getAll");
		if (actividades.isEmpty())
			return null;
		return actividades.values().toArray(new ActividadTuristica[0]);
	}

	public ActividadTuristica find(String nombre) {
		logger.log("-- ManejadorActividadTuristica.find nombre: '" + nombre + "'");
		return actividades.get(nombre);
	}

	public Boolean contains(String nombreActividad) {
		logger.log("-- ManejadorActividadTuristica.contains nombreActividad: '" + nombreActividad + "'");
		return actividades.containsKey(nombreActividad);
	}

	public ActividadTuristica[] getAllAsociadasADepartamento(String nombreDepartamento) {
		logger.log("-- ManejadorActividadTuristica.getAllAsociadasADepartamento nombreDepartamento: '"
				+ nombreDepartamento + "'");
		return manejadorDepartamento.getAllActividadesAsociadasADepartamento(nombreDepartamento);
	}

	public ActividadTuristica[] getAllAsociadasADepartamentoNoEnPaquete(String nombreDepartamento,
			String nombrePaquete) {
		logger.log("-- ManejadorActividadTuristica.getAllAsociadasADepartamentoNoEnPaquete nombreDepartamento: '"
				+ nombreDepartamento + "' , nombrePaquete: '" + nombrePaquete + "'");
		return manejadorDepartamento.getAllActividadesAsociadasADepartamentoNoEnPaquete(nombreDepartamento,
				nombrePaquete);
	}

}
