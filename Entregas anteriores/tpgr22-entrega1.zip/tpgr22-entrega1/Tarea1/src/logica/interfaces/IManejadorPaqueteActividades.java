package logica.interfaces;

import logica.entidades.PaqueteActividades;

public interface IManejadorPaqueteActividades {
	
	public void add(PaqueteActividades paquete);
	
	public PaqueteActividades[] getAll();
	
	public PaqueteActividades find(String nombre);
	
	void update(PaqueteActividades paqueteModificado);
	
	public Boolean contains(String nombrePaqueteActividades);

}
