package logica.interfaces;

import logica.entidades.Proveedor;
import logica.entidades.Turista;
import logica.entidades.Usuario;

public interface IManejadorUsuario {

	public void add(Usuario usuario);

	public void update(Usuario usuario);

	public Usuario[] getAll();

	public Proveedor[] getAllProveedores();

	public Turista[] getAllTuristas();

	public Usuario find(String nickname);

	public boolean contains(String nicknameUsuario);

	public boolean emailYaRegistrado(String email);

}
