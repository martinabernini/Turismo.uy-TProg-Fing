package logica.interfaces;

import logica.entidades.InscripcionSalida;

public interface IManejadorInscripcionSalida {

	public void add(InscripcionSalida nuevaInscripcion);
	
	public int count();  // devuelve la cantidad de inscripciones 
}
