package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtPaqueteActividades;

public interface IControladorPaqueteActividades {

	public void darDeAlta(DtPaqueteActividades nuevoPaquete) throws CampoInvalidoException, EntidadRepetidaException ;
	
	public String[] listarPaquetes() throws NoHayEntidadesParaListarException;
	
	public String[] listarActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepartamento, String nombrePaquete) throws NoHayEntidadesParaListarException, CampoInvalidoException;
	
	public void ingresarActividadTuristicaAPaquete(String nombreActividad, String nombrePaquete) throws EntidadRepetidaException, CampoInvalidoException;
	  
	public DtPaqueteActividades find(String nombre) throws EntidadRepetidaException, CampoInvalidoException;
	
	
}
