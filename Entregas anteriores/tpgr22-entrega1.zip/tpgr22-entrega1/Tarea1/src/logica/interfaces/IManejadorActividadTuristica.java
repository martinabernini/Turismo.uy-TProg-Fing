package logica.interfaces;

import logica.entidades.ActividadTuristica;

public interface IManejadorActividadTuristica {

	public void add(ActividadTuristica actividad);
	
	public void update(ActividadTuristica actividadModificada);
	
	public ActividadTuristica[] getAll();
	
	public ActividadTuristica find(String nombre);
	
	public ActividadTuristica[] getAllAsociadasADepartamento(String nombreDepartamento);
	
	public ActividadTuristica[] getAllAsociadasADepartamentoNoEnPaquete(String nombreDepartamento, String nombrePaquete);
	
	public Boolean contains(String nombreActividad);
	
}
