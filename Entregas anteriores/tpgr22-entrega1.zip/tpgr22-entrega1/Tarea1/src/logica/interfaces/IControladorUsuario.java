package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtUsuario;

public interface IControladorUsuario {
	
	public void darDeAltaUsuario(DtUsuario nuevoUsuario) throws CampoInvalidoException, EntidadRepetidaException;
	
	public String[] listarUsuarios() throws NoHayEntidadesParaListarException;
	
	public DtUsuario getUsuario(String nickname) throws EntidadNoExisteException, CampoInvalidoException;
	
	public void modificarUsuario(DtUsuario usuarioModificado) throws CampoInvalidoException;
	
	public String[] listarTuristas() throws NoHayEntidadesParaListarException;
	
	public String[] listarProveedores() throws NoHayEntidadesParaListarException;
	
}
