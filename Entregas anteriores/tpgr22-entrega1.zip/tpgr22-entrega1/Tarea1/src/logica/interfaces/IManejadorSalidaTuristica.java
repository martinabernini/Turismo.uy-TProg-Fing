package logica.interfaces;

import logica.entidades.SalidaTuristica;

public interface IManejadorSalidaTuristica {

	public void add(SalidaTuristica salida);

	public SalidaTuristica[] getAllAsociadasAActividadTuristica(String nombreActividad);

	public SalidaTuristica find(String nombre);

	public SalidaTuristica[] getAllVigentesAsociadasAActividad(String nombreActividad);

	public Boolean contains(String nombreSalida);

}
