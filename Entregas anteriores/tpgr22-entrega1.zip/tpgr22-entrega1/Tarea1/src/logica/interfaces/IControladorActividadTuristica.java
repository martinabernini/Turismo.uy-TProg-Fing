package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
//import logica.datatypes.DtInscripcionSalida;

public interface IControladorActividadTuristica {

	public void darDeAltaActividadTuristica(DtActividadTuristica nuevaActividad)
			throws CampoInvalidoException, EntidadRepetidaException;

	public String[] listarActividadesAsociadasADepartamento(String nombreDepartamento)
			throws NoHayEntidadesParaListarException, CampoInvalidoException;

	public DtActividadTuristica getActividadTuristica(String nombre)
			throws EntidadNoExisteException, CampoInvalidoException;

	public String[] listarActividadesAsocadasADepartamentoNoEnPaquete(String nombreDepartamento, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException;

}
