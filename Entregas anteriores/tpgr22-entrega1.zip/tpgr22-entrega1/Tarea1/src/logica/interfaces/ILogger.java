package logica.interfaces;

public interface ILogger {

	public void log(String mensaje);
	
}
