package logica.interfaces;

import logica.entidades.ActividadTuristica;
import logica.entidades.Departamento;

public interface IManejadorDepartamento {

	public void add(Departamento departamento);
	
	public void update(Departamento departamento);

	public Departamento[] getAll();

	public Boolean contains(String nombre);

	public ActividadTuristica[] getAllActividadesAsociadasADepartamento(String nombreDepartamento);

	public ActividadTuristica[] getAllActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepartamento, String nombrePaquete);

	public Departamento find(String nombre);
	
	
}
