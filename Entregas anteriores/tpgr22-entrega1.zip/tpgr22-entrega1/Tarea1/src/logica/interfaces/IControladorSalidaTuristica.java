package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.MaximoDeTuristasAlcanzadoException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtSalidaTuristica;

public interface IControladorSalidaTuristica {
	
	public void darDeAltaSalidaTuristica(DtSalidaTuristica nuevaSalida) throws CampoInvalidoException, EntidadRepetidaException ;
	
	public String[] listarSalidasAsociadasAActividadTuristica(String nombreActividad) throws NoHayEntidadesParaListarException, CampoInvalidoException;
	
	public DtSalidaTuristica getSalidaTuristica(String nombre) throws EntidadNoExisteException, CampoInvalidoException;
	
	public String[] listarSalidasVigentesAsociadasAActividadTuristica(String nombreActividad) throws NoHayEntidadesParaListarException, CampoInvalidoException ;
	
	public void inscribirTuristaASalidaTuristica(DtInscripcionSalida nuevaInscripcion) throws EntidadRepetidaException, CampoInvalidoException, MaximoDeTuristasAlcanzadoException;
	
}
