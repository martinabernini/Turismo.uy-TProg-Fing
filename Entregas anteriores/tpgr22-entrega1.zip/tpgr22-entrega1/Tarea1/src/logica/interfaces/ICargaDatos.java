package logica.interfaces;

public interface ICargaDatos {

	public void cargar();
	
}
