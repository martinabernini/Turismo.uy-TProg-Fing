package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;

public interface IControladorDepartamento {

	public String[] listarDepartamentos() throws NoHayEntidadesParaListarException;

	public void darDeAltaDepartamento(String nombre, String descripcion, String url) throws CampoInvalidoException, EntidadRepetidaException;
	
}
