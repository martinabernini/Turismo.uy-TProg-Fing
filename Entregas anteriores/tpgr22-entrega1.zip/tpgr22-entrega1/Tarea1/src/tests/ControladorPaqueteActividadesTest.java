package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import excepciones.CampoInvalidoException;
import logica.datatypes.DtPaqueteActividades;
import logica.interfaces.IControladorPaqueteActividades;
import utils.Fabrica;

class ControladorPaqueteActividadesTest {
	private static IControladorPaqueteActividades controladorPaquete;
	private static DtPaqueteActividades paquete1;
	private static DtPaqueteActividades paquete2;
	private static DtPaqueteActividades paquete3;

	@BeforeAll
	public static void start() {
		controladorPaquete = Fabrica.getInstance().getIControladorPaqueteActividades();

		String act1[] = { "paseo", "vuelta", "juegos" };
		String act2[] = { "ponypisador", "vueltita", "juegosmasdivertidos", "cumpleanios" };
		String act3[] = { "elmejorponypisador", "mejorvueltita", "juegosmuchomasdivertidos", "altocumpleanios" };
		Date FechaAlta1 = new Date("05/09/2022");
		Date FechaAlta2 = new Date("10/09/2022");
		Date FechaAlta3 = new Date("15/09/2022");

		paquete1 = new DtPaqueteActividades("nuevopaquete", "divertido", 30, FechaAlta1, act1, 25);
		paquete2 = new DtPaqueteActividades("mejorpaquete", "mas divertido", 31, FechaAlta2, act2, 40);
		paquete3 = new DtPaqueteActividades("muchomejorpauqete", "mucho mas divertido", 50, FechaAlta3, act3, 50);

	}

	@Test
	void testDarDeAltaPaquete() {

		try {
			
		controladorPaquete.darDeAlta(paquete1);
		controladorPaquete.darDeAlta(paquete2);

		DtPaqueteActividades paqueteuno;
		paqueteuno = controladorPaquete.find("nuevopaquete");
		assertEquals(paquete1.getNombre(), paqueteuno.getNombre());
		assertEquals(paquete1.getDescripcion(), paqueteuno.getDescripcion());

		DtPaqueteActividades paquetedos;
		paquetedos = controladorPaquete.find("mejorpaquete");
		assertEquals(paquete2.getValidezEnDias(), paquetedos.getValidezEnDias());
		assertEquals(paquete2.getDescuento(), paquetedos.getDescuento());

		assertThrows(CampoInvalidoException.class, () -> controladorPaquete.darDeAlta(paquete1));
		assertThrows(CampoInvalidoException.class, () -> controladorPaquete.darDeAlta(paquete2));
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testListarPaquetes() {
		try {
			String[] listaPaquetes = controladorPaquete.listarPaquetes();

			// Assert
			assertEquals(listaPaquetes[2], paquete1);
			assertEquals(listaPaquetes[1], "paquete2");
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	void testListarPaquetesConDatos() {
		try {
			DtPaqueteActividades p1 = new DtPaqueteActividades("paquete0", "divertido", 30, null, null, 11);
			DtPaqueteActividades p2 = new DtPaqueteActividades("paquete1", "buen", 12, null, null, 17);
			controladorPaquete.darDeAlta(p1);
			controladorPaquete.darDeAlta(p2);
			String[] listaPaquetes = controladorPaquete.listarPaquetes();
			// Assert
			assertEquals(listaPaquetes[0], "p1");
			assertEquals(listaPaquetes[1], "p2");
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testListarActividadesAsociadasADepartamentoNoEnPaquete() {
		fail("Not yet implemented");
	}

	@Test
	void testIngresarActividadTuristicaAPaquete() {
		fail("Not yet implemented");
	}
	
	@Test
	void testGetPaquete() {	
		try {
			assertEquals(controladorPaquete.find("paquete1"), paquete1);
			assertEquals(controladorPaquete.find("paquete2"), paquete2);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
}
