package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import logica.interfaces.IManejadorActividadTuristica;
import utils.Fabrica;

class ManejadorActividadTuristicaTest {

	private static IManejadorActividadTuristica mjdrActTur;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Fabrica f = Fabrica.getInstance();
		mjdrActTur = f.getIManejadorActividadTuristica();
		f.getICargaDatos().cargar();
	}

	@Test
	void CuandoHayActividadesParaListar_NoTiraError() {
		try {
			mjdrActTur.getAll();
		}
		catch(Exception e) {
			fail("Not yet implemented");			
		}
	}
	
	@Test
	void CuandoHayActividadesParaListarAsociadasADepartamento_NoTiraError() {
		try {
			mjdrActTur.getAllAsociadasADepartamento("rocha");
		}
		catch(Exception e) {
			fail("Not yet implemented");			
		}
	}
	
	@Test
	void CuandoHayActividadesParaListarAsociadasADepartamentoNoEnPaquete_NoTiraError() {
		try {
			mjdrActTur.getAllAsociadasADepartamentoNoEnPaquete("rocha", "disfrutar rocha");
		}
		catch(Exception e) {
			fail("Not yet implemented");			
		}
	}
	
}
