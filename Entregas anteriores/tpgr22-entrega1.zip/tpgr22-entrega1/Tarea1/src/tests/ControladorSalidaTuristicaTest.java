package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtSalidaTuristica;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorInscripcionSalida;
import utils.Fabrica;

class ControladorSalidaTuristicaTest {

	public static IControladorSalidaTuristica ctrlSalida;
	public static IManejadorInscripcionSalida mjdrInscSalida;
	public static ILogger logger;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Fabrica f = Fabrica.getInstance();
		ctrlSalida = f.getIControladorSalidaTuristica();
		mjdrInscSalida = f.getIManejadorInscripcionSalida();
		logger = f.getILoggerTests();

		f.getICargaDatos().cargar();

		logger.log(
				"----------------------------------  Testeando Salida Turistica   -----------------------------------");
	}
	
	@Test
	void campoVacioAlAgregar_TiraExcepcionCorrecta() {
		logger.log("");
		logger.log(
				"----------------------------  campoVacioAlAgregar_TiraExcepcionCorrecta --------------------------");

		DtSalidaTuristica nuevaSalida = new DtSalidaTuristica();
		nuevaSalida.setNombreSalida("");
		nuevaSalida.setNombreActividad("");
		nuevaSalida.setFechaAlta(null);
		nuevaSalida.setFechaSalida(null);
		nuevaSalida.setLugarSalida(null);
		nuevaSalida.setCantidadMaximaTuristas(0);

		assertThrows(CampoInvalidoException.class, () -> ctrlSalida.darDeAltaSalidaTuristica(nuevaSalida));
	}
	
	@Test
	void CampoInvalidoAlAgregar_TiraExcepcionCorrecta() {
		logger.log("");
		logger.log(
				"----------------------------  campoVacioAlAgregar_TiraExcepcionCorrecta --------------------------");

		DtSalidaTuristica nuevaSalida = new DtSalidaTuristica();
		nuevaSalida.setNombreSalida("Ahiva");
		nuevaSalida.setNombreActividad("nada");
		nuevaSalida.setFechaAlta(new Date("02/02/2000"));
		nuevaSalida.setFechaSalida(new Date("01/02/2022"));
		nuevaSalida.setLugarSalida("dsfgashasjk");
		nuevaSalida.setCantidadMaximaTuristas(5);

		assertThrows(CampoInvalidoException.class, () -> ctrlSalida.darDeAltaSalidaTuristica(nuevaSalida));
	}

	@Test
	void cuandoCamposValidos_AgregaYObtieneCorrectamenteUnaActividad() {
		logger.log("");
		logger.log(
				"----------------------------  cuandoCamposValidos_AgregaYObtieneCorrectamenteUnaActividad --------------------------");

		DtSalidaTuristica nuevaSalida = new DtSalidaTuristica();
		nuevaSalida.setNombreSalida("salida test");
		nuevaSalida.setNombreActividad("teatro con sabores");
		nuevaSalida.setFechaAlta(new Date("02/02/2000"));
		nuevaSalida.setFechaSalida(new Date("01/02/2022"));
		nuevaSalida.setLugarSalida("dsfghjk");
		nuevaSalida.setCantidadMaximaTuristas(15);

		// Act
		try {
			ctrlSalida.darDeAltaSalidaTuristica(nuevaSalida);
			DtSalidaTuristica obtenida = ctrlSalida.getSalidaTuristica("salida test");

			// Assert
			assertEquals(nuevaSalida, obtenida);

		} catch (EntidadRepetidaException | CampoInvalidoException | EntidadNoExisteException e) {
			fail(e.getMessage());
		}
	}

	
	@Test
	void EntidadNoExiste_ObtieneUnaSalida() {
		logger.log("");
		logger.log(
				"----------------------------  EntidadNoExiste_ObtieneUnaSalida --------------------------");


			// Assert
			assertThrows(EntidadNoExisteException.class, () -> ctrlSalida.getSalidaTuristica("Prueba no correcta"));
		
	}
	
	@Test
	void CampoNoValido_ObtieneUnaSalida() {
		logger.log("");
		logger.log(
				"----------------------------  CampoNoValido_ObtieneUnaSalida --------------------------");

			// Assert
			assertThrows(CampoInvalidoException.class, () -> ctrlSalida.getSalidaTuristica(""));
		
	}
	
	
	@Test
	void cuandoDatosCorrectos_SeListanSalidasAsociadasAActividadTuristicaCorrectamente() {
		try {
			logger.log("");
			logger.log(
					"----------------------------  cuandoDatosCorrectos_SeListanSalidasAsociadasAActividadTuristicaCorrectamente -------------------------- ");

			Set<String> esperadas = new HashSet<String>();
			esperadas.add("teatro con sabores 1");
			esperadas.add("teatro con sabores 2");

			Set<String> obtenidas = new HashSet<String>();

			String[] obtenidasArray = ctrlSalida.listarSalidasAsociadasAActividadTuristica("teatro con sabores");

			// como puede ser que se agregue una durante el test (la de nombre "salida
			// test")
			assertTrue(obtenidasArray.length == esperadas.size() || obtenidasArray.length == esperadas.size() + 1);

			for (String salida : obtenidasArray) {
				obtenidas.add(salida);
			}

			assertTrue(obtenidas.containsAll(esperadas));

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void cuandoDatosCorrectos_SeListanSalidasVigentesAsociadasAActividadTuristicaCorrectamente() {
		try {
			logger.log("");
			logger.log(
					"----------------------------  cuandoDatosCorrectos_SeListanSalidasVigentesAsociadasAActividadTuristicaCorrectamente -- ------------------------");

			Set<String> esperadas = new HashSet<String>();
			esperadas.add("cabalgata 1");
			esperadas.add("cabalgata 2");

			Set<String> obtenidas = new HashSet<String>();

			String[] obtenidasArray = ctrlSalida
					.listarSalidasVigentesAsociadasAActividadTuristica("cabalgata en valle del lunarejo");

			assertTrue(obtenidasArray.length == esperadas.size() || obtenidasArray.length == esperadas.size() + 1);

			for (String salida : obtenidasArray) {
				obtenidas.add(salida);
			}

			assertEquals(esperadas, obtenidas);

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void cuandoDatosCorrectosYSalidaNoVigente_SeListanSalidasVigentesAsociadasAActividadTuristicaCorrectamente() {
		try {
			logger.log("");
			logger.log(
					"----------------------------  cuandoDatosCorrectosYSalidaNoVigente_SeListanSalidasVigentesAsociadasAActividadTuristicaCorrectamente -- ------------------------");

			Set<String> esperadas = new HashSet<String>();
			esperadas.add("degusta setiembre");

			Set<String> obtenidas = new HashSet<String>();

			String[] obtenidasArray = ctrlSalida.listarSalidasVigentesAsociadasAActividadTuristica("degusta");

			for (String salida : obtenidasArray) {
				obtenidas.add(salida);
			}

			assertEquals(esperadas, obtenidas);

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	void cuandoDatosCorrectos_SeInscribirTuristaASalidaTuristicaCorrectamente() {
		try {
			logger.log("");
			logger.log(
					"----------------------------  cuandoDatosCorrectos_SeInscribirTuristaASalidaTuristicaCorrectamente --------------------------");

			DtInscripcionSalida nuevaInscripcion = new DtInscripcionSalida();

			nuevaInscripcion.setNickname("waston");
			nuevaInscripcion.setNombreSalidaTuristica("cabalgata 1");
			nuevaInscripcion.setFechaInscripcion(new Date("20/08/2022"));
			nuevaInscripcion.setCantidadTuristas(1);

			int cantidadPreviaAInscripcion = mjdrInscSalida.count();
			ctrlSalida.inscribirTuristaASalidaTuristica(nuevaInscripcion);
			assertEquals(cantidadPreviaAInscripcion + 1, mjdrInscSalida.count());

		} catch (Exception e) {
			fail(e.getMessage());
		}

	}

	@Test
	void testInscripcionSalidaValida() {
		Date FechaNacimientoPro = new Date("01/01/1990");
		DtInscripcionSalida inscripcion = new DtInscripcionSalida("pancho", "nomsal", 2, 3, new Date("01/01/1990"));

		DtInscripcionSalida inscripcion2 = new DtInscripcionSalida();
		inscripcion2.setNickname("pancho");
		inscripcion2.setNombreSalidaTuristica("nomsal");
		inscripcion2.setCantidadTuristas(2);
		inscripcion2.setCosto(3);
		inscripcion2.setFechaInscripcion(new Date("01/01/1990"));

		assertEquals(inscripcion2.getNickname(), inscripcion.getNickname());
		assertEquals(inscripcion2.getCantidadTuristas(), inscripcion.getCantidadTuristas());
		assertEquals(inscripcion2.getCosto(), inscripcion.getCosto());
		assertEquals(inscripcion2.getNombreSalidaTuristica(), inscripcion.getNombreSalidaTuristica());

		assertEquals(true, inscripcion2.equals(inscripcion));
		assertEquals(true, inscripcion2.equals(inscripcion2));
		assertEquals(false, inscripcion2.equals(null));

		assertEquals(false, inscripcion2.equals(new DtActividadTuristica()));

	}

}
