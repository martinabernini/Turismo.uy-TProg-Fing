package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import logica.datatypes.DtProovedor;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.interfaces.IControladorUsuario;
import utils.Fabrica;

class ControladorUsuarioTest {
	
	private static IControladorUsuario controladorUsuario;
	private static DtUsuario turista;
	private static DtUsuario turista2;
	private static DtUsuario proveedor;
	private static DtUsuario proveedor2;
	
	@BeforeAll
	public static void start() {
		controladorUsuario = Fabrica.getInstance().getIControladorUsuario();
		
		Date FechaNacimientoTur = new Date("01/01/1990");
		Date FechaNacimientoPro = new Date("01/05/1990");
		
		turista = new DtTurista("pepe", "Pedro", "Gonzalez", "pedro@gmail.com", FechaNacimientoTur,
				"Uruguayo");
		proveedor = new DtProovedor("Pancho", "Francisco", "Perez", "Pancho@gmail.com", FechaNacimientoPro,
				"Descripcion", "www.panchoviajes.com");
		turista2 = new DtTurista("Sofi", "Sofia", "Acosta", "sofia@gmail.com", FechaNacimientoTur,
				"Argentina");
		proveedor2 = new DtProovedor("Nacho", "Ignacio", "Nunez", "ignacio@gmail.com", FechaNacimientoPro,
				"Descripcion de Nacho", "www.nachoviajes.com");
		
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
			controladorUsuario.darDeAltaUsuario(proveedor2);
			controladorUsuario.darDeAltaUsuario(turista);
			controladorUsuario.darDeAltaUsuario(turista2);
		} catch (CampoInvalidoException | EntidadRepetidaException e) {
			
		}
		
		
	}

	@Test
	void testDarDeAltaUsuario() {
			
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			e.printStackTrace();
		} catch (EntidadRepetidaException e) {
			e.printStackTrace();
		}
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException | EntidadRepetidaException e) {
			e.printStackTrace();
		}
		
		DtUsuario turistaSalida;
		try {
			turistaSalida = controladorUsuario.getUsuario("pepe");
			assertEquals(turista.getNombre(), turistaSalida.getNombre()); 
			assertEquals(turista.getNickname(), turistaSalida.getNickname());
		} catch (EntidadNoExisteException | CampoInvalidoException e) {
			e.printStackTrace();
		}
		DtUsuario proveedorSalida;
		try {
			proveedorSalida = controladorUsuario.getUsuario("Pancho");
			assertEquals(proveedor.getNombre(), proveedorSalida.getNombre());
		} catch (EntidadNoExisteException | CampoInvalidoException e) {
		}

	}
	
	@Test
	void testDarDeAltaUsuarioCampoInvalido() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("", "Pedro", "Gonzalez", "pedrdo@gmail.com", FechaNacimientoTur,
				"Uruguayo");
		
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			
			assertNotEquals((CampoInvalidoException) e, null);;
			//e.printStackTrace();
		} catch (EntidadRepetidaException e) {
			e.printStackTrace();
		}
		
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	@Test
	void testDarDeAltaUsuarioMailRepetido() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("Nick23", "Pedro", "Gonzalez", "pedro@gmail.com", FechaNacimientoTur,
				"Uruguayo");
		
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			
			assertNotEquals((CampoInvalidoException) e, null);;
			//e.printStackTrace();
		} catch (EntidadRepetidaException e) {
			e.printStackTrace();
		}
		
		assertThrows(EntidadRepetidaException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	
	@Test
	void testDarDeAltaUsuarioEntidadRepetida() {
		Date FechaNacimientoTur2 = new Date("01/01/1968");
		
		DtTurista turista = new DtTurista("pepe", "Diego", "Gonzalez", "diego@gmail.com", FechaNacimientoTur2,
				"Uruguayo");
				
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			e.printStackTrace();
		} catch (EntidadRepetidaException e) {
			
			assertNotEquals((EntidadRepetidaException) e, null);;
			//e.printStackTrace();
		}
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException | EntidadRepetidaException e) {
			e.printStackTrace();
		}
		
		assertThrows(EntidadRepetidaException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}

	@Test
	void testListarUsuarios() {
		try {
			String[] listaUsuarios = controladorUsuario.listarUsuarios();		

			Set<String> setUsuarios = new HashSet<String>();
				
			for (String usuario : listaUsuarios) {
				setUsuarios.add(usuario);
			}
			
			assertTrue(setUsuarios.contains("Pancho"));
			assertTrue(setUsuarios.contains("Sofi"));
			assertTrue(setUsuarios.contains("pepe"));
			assertTrue(setUsuarios.contains("Nacho"));
			
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	void testListarTuristas() {
		try {
			
			
			String[] listaTuristas = controladorUsuario.listarTuristas();		

		// Assert
			assertEquals(listaTuristas[0] , "Sofi");
			assertEquals(listaTuristas[1], "pepe");
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	void testListarProveedores() {
		try {
			String[] listaProveedores = controladorUsuario.listarProveedores();		

		// Assert
			assertEquals(listaProveedores[0], "Pancho");
			assertEquals(listaProveedores[1], "Nacho");
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}


	
	@Test
	void testDarDeAltaTuristaCampoInvalidoApellido() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("nick1", "nombre", "", "pedro1@gmail.com", FechaNacimientoTur,
				"Uruguayo");
		
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	@Test
	void testDarDeAltaTuristaCampoInvalidoEmail() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("nick", "nombre", "apellido", "", FechaNacimientoTur,
				"Uruguayo");
		
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	@Test
	void testDarDeAltaTuristaCampoInvalidoFechaNacimiento() {
		// Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("nick", "nombre", "apellido", "email", null,
				"Uruguayo");
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	@Test
	void testDarDeAltaTuristaCampoInvalidoNacionalidad() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtTurista turista = new DtTurista("nick", "nombre", "apellido", "email", FechaNacimientoTur,
				"");
		try {
			controladorUsuario.darDeAltaUsuario(turista);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(turista));
	}
	
	
	//ALTA PROVEEDOR ERRORES
	
	
	@Test
	void testDarDeAltaProveedorCampoInvalidoNombre() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtProovedor proveedor = new DtProovedor("nickname", "", "apellido" , "email" , FechaNacimientoTur,
				"descripcion" , "urlSitioWeb");
		
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(proveedor));
	}
	
	@Test
	void testDarDeAltaProveedorCampoInvalidoApellido() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtProovedor proveedor = new DtProovedor("nickname", "nombre", "" , "email" , FechaNacimientoTur,
				"descripcion" , "urlSitioWeb");
		
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(proveedor));
	}
	
	@Test
	void testDarDeAltaProveedorCampoInvalidoEmail() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtProovedor proveedor = new DtProovedor("nickname", "nombre", "apellido" , "" , FechaNacimientoTur,
				"descripcion" , "urlSitioWeb");
		
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(proveedor));
	}
	
	@Test
	void testDarDeAltaProveedorCampoInvalidoFechaNacimiento() {
		// Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtProovedor proveedor = new DtProovedor("nickname", "nombre", "apellido" , "email" , null ,
				"descripcion" , "urlSitioWeb");
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(proveedor));
	}
	
	@Test
	void testDarDeAltaProveedorCampoInvalidoDescripcion() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		
		DtProovedor proveedor = new DtProovedor("nickname", "nombre", "apellido" , "email" , FechaNacimientoTur,
				"" , "urlSitioWeb");
		try {
			controladorUsuario.darDeAltaUsuario(proveedor);
		} catch (CampoInvalidoException e) {
			assertNotEquals((CampoInvalidoException) e, null);;
		} catch (EntidadRepetidaException e) {
		}
		assertThrows(CampoInvalidoException.class, ()->controladorUsuario.darDeAltaUsuario(proveedor));
	}
	
	@Test
	void testModificarTuristaValido() {
		Date FechaNacimientoTur = new Date("01/01/1990");
		DtTurista turistaModificado = new DtTurista("pepe", "Pablo", "Picapiedra", "pedro@gmail.com", FechaNacimientoTur,
				"Paraguay");
		DtTurista turEjemplo= new DtTurista("pepe", "Pablo", "Picapiedra", "pedro@gmail.com", FechaNacimientoTur,
				"Uruguayo", null);
		
		turEjemplo.setNacionalidad("Paraguay");
		turEjemplo.setNacionalidad(null);
		
		try {
			controladorUsuario.modificarUsuario(turistaModificado);
		} catch (CampoInvalidoException e) {
		}
		
		DtUsuario turistaSalida;
		try {
			turistaSalida = controladorUsuario.getUsuario("pepe");
			
			assertEquals(turistaModificado.getNickname(), turistaSalida.getNickname());
			assertEquals(turistaModificado.getNombre(), turistaSalida.getNombre()); 
			assertEquals(turistaModificado.getApellido(), turistaSalida.getApellido());
			assertEquals(turistaModificado.getEmail(), turistaSalida.getEmail());
			
			Boolean res1= turistaModificado.equals(turistaSalida);
			Boolean res2= turistaModificado.equals(turistaModificado);
			Boolean res3= turistaModificado.equals(null);
			Boolean res4= turistaModificado.equals(proveedor);
			
		} catch (EntidadNoExisteException | CampoInvalidoException e) {
		}
	}
		
		@Test
		void testModificarProveedorValido() {
			Date FechaNacimientoPro = new Date("01/01/1990");
			DtProovedor proveedorModificado = new DtProovedor("Pancho", "nombresito", "apellidoOo", "Pancho@gmail.com", FechaNacimientoPro,
					"Descripcionesss", "www.panchoviajes.commm");
			try {
				controladorUsuario.modificarUsuario(proveedorModificado);
			} catch (CampoInvalidoException e) {
			}
			
			DtProovedor proveedorSalida;
			try {
				proveedorSalida = (DtProovedor) controladorUsuario.getUsuario("Pancho");
				
				assertEquals(proveedorModificado.getNickname(), proveedorSalida.getNickname());
				assertEquals(proveedorModificado.getNombre(), proveedorSalida.getNombre()); 
				assertEquals(proveedorModificado.getApellido(), proveedorSalida.getApellido());
				assertEquals(proveedorModificado.getEmail(), proveedorSalida.getEmail());
				
				assertEquals(true,proveedorModificado.equals(proveedorSalida));
				assertEquals(true,proveedorModificado.equals(proveedorModificado));
				assertEquals(false,proveedorModificado.equals(null));
				assertEquals(false,proveedorModificado.equals(turista));
				assertEquals(null,proveedorModificado.getActividadesTuristicas());
				
				proveedorSalida.setDescripcion("holaaa");
				proveedorSalida.setUrlSitioWeb("papasito");
				proveedorSalida.setActividadesTuristicas(null);
				
				
				
			} catch (EntidadNoExisteException | CampoInvalidoException e) {
				fail();
			}	
	}
		
		void testCrearUsuarioVacio() {
		
	}

}
