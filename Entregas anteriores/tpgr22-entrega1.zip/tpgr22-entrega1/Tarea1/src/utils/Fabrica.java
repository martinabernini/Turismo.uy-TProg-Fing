package utils;

import logica.cargadatos.CargaDatos;
import logica.controladores.ControladorActividadTuristica;
import logica.controladores.ControladorDepartamento;
import logica.controladores.ControladorPaqueteActividades;
import logica.controladores.ControladorSalidaTuristica;
import logica.controladores.ControladorUsuario;
import logica.manejadores.ManejadorActividadTuristica;
import logica.manejadores.ManejadorDepartamento;
import logica.manejadores.ManejadorInscripcionSalida;
import logica.manejadores.ManejadorPaqueteActividades;
import logica.manejadores.ManejadorSalidaTuristica;
import logica.manejadores.ManejadorUsuario;
import logica.interfaces.ICargaDatos;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorUsuario;
import logica.interfaces.ILogger;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;
import logica.interfaces.IManejadorInscripcionSalida;
import logica.interfaces.IManejadorPaqueteActividades;
import logica.interfaces.IManejadorSalidaTuristica;
import logica.interfaces.IManejadorUsuario;

public class Fabrica {

	private Boolean logManejadores = true;
	private Boolean logControladores = true;
	private Boolean logPresentacion = true;
	private Boolean logTests = true;

	private static Fabrica instancia;

	private Fabrica() {
	};

	public static Fabrica getInstance() {
		if (instancia == null) {
			instancia = new Fabrica();
		}

		return instancia;
	}

	// ----------------------------------------------------------------

	public IControladorActividadTuristica getIControladorActividadTuristica() {
		return new ControladorActividadTuristica(getIManejadorActividadTuristica(), getIManejadorDepartamento(),
				getIManejadorUsuario(), getILoggerControlador());
	}

	public IControladorDepartamento getIControladorDepartamento() {
		return new ControladorDepartamento(getIManejadorDepartamento(), getILoggerControlador());
	}

	public IControladorPaqueteActividades getIControladorPaqueteActividades() {
		return new ControladorPaqueteActividades(getIManejadorPaqueteActividades(), getIManejadorActividadTuristica(), getILoggerControlador());
	}

	public IControladorSalidaTuristica getIControladorSalidaTuristica() {
		return new ControladorSalidaTuristica(getIManejadorSalidaTuristica(), getIManejadorUsuario(),
				getIManejadorInscripcionSalida(), getIManejadorActividadTuristica(), getILoggerControlador());
	}

	public IControladorUsuario getIControladorUsuario() {
		return new ControladorUsuario(getIManejadorUsuario(), getILoggerControlador());
	}

	// ----------------------------------------------------------------

	public IManejadorActividadTuristica getIManejadorActividadTuristica() {
		return ManejadorActividadTuristica.getInstance(getIManejadorDepartamento(), getILoggerManejador());
	}

	public IManejadorDepartamento getIManejadorDepartamento() {
		return ManejadorDepartamento.getInstance(getILoggerManejador());
	}

	public IManejadorPaqueteActividades getIManejadorPaqueteActividades() {
		return ManejadorPaqueteActividades.getInstance(getILoggerManejador());
	}

	public IManejadorSalidaTuristica getIManejadorSalidaTuristica() {
		return ManejadorSalidaTuristica.getInstance(getIManejadorActividadTuristica(), getILoggerManejador());
	}

	public IManejadorUsuario getIManejadorUsuario() {
		return ManejadorUsuario.getInstance(getILoggerManejador());
	}

	public IManejadorInscripcionSalida getIManejadorInscripcionSalida() {
		return ManejadorInscripcionSalida.getInstance(getILoggerManejador());
	}

	// ----------------------------------------------------------------

	public ILogger getILoggerManejador() {
		if (logManejadores) {
			return new DevLogger();
		}
		return new ProdLogger();
	}

	public ILogger getILoggerControlador() {
		if (logControladores) {
			return new DevLogger();
		}
		return new ProdLogger();
	}

	public ILogger getILoggerPresentacion() {
		if (logPresentacion) {
			return new DevLogger();
		}
		return new ProdLogger();
	}

	public ILogger getILoggerTests() {
		if (logTests) {
			return new DevLogger();
		}
		return new ProdLogger();
	}
	
	public void setLogManejadores(Boolean log) {
		logManejadores = log;
	};

	public void setLogControladores(Boolean log) {
		logControladores = log;
	};

	public void setLogPresentacion(Boolean log) {
		logPresentacion = log;
	};
	
	public void setLogTests(Boolean log) {
		logTests = log;
	};
	
	// ----------------------------------------------------------------

	public ICargaDatos getICargaDatos() {
		return new CargaDatos(getIControladorActividadTuristica(), getIControladorDepartamento(),
				getIControladorPaqueteActividades(), getIControladorSalidaTuristica(), getIControladorUsuario());
	}

}
