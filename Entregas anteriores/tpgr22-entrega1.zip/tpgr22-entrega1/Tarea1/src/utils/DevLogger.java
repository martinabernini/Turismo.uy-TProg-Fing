package utils;

import logica.interfaces.ILogger;

public class DevLogger implements ILogger {

	public void log(String mensaje) {
		System.out.println(mensaje);		
	}
	
}
