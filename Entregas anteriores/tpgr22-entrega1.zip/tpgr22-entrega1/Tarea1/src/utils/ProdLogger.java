package utils;

import logica.interfaces.ILogger;

public class ProdLogger implements ILogger {

	public void log(String mensaje) {
	}
	
}
