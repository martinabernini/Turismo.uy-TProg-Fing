package excepciones;

public class EntidadRepetidaException extends Exception{

	public EntidadRepetidaException(String string) {
		super(string);
	}
	
}

