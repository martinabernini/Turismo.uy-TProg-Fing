# Tprog Tarea 1:

## Progreso

### Casos de Uso:
- Alta de Usuario
  - [x] Implementar
  - [x] Testear
- Consulta de Usuario
    - [x] Implementar
    - [x] Testear
- Modificar datos de Usuario - OPCIONAL
  - [x] Implementar
  - [x] Testear
- Alta de Actividad Turística
    - [x] Implementar
    - [x] Testear
- Consulta de Actividad Turística
    - [x] Implementar
    - [x] Testear
- Alta de Salida Turística
  - [x] Implementar
  - [x] Testear
- Consulta de Salida Turística
    - [x] Implementar
    - [x] Testear
- Inscripcion a Salida Turística
  - [x] Implementar
  - [x] Testear
- Crear Paquete de Actividades Turísticas - OPCIONAL
    - [ ] Implementar
    - [ ] Testear
- Agregar Actividad Turística a Paquete - OPCIONAL
  - [ ] Implementar
  - [ ] Testear
- Consulta de Paquete de Actividades Turísticas - OPCIONAL
    - [ ] Implementar
    - [ ] Testear
- Alta de Departamento
    - [x] Implementar (SOLO LÓGICA)
    - [x] Testear


---

### Controlador Usuario:
- darDeAltaUsuario(nuevoUsuario: DtUsuario)
  - [x] Implementar
  - [x] Testear
- listarUsuarios(): Set(String)
    - [x] Implementar
    - [x] Testear
- getUsuario(nickname: String): DtUsuario
  - [x] Implementar
  - [x] Testear
- modificarUsuario(usuarioModificado: DtUsuario)
    - [x] Implementar
    - [x] Testear
- listarTuristas(): Set(String)
  - [x] Implementar
  - [x] Testear
- listarProveedores(): Set(String)
    - [x] Implementar
    - [x] Testear

### Controlador Actividad Turística 
***(Falta implementar alguno chequeos de validez)***

- darDeAltaActividadTuristica(nuevaActividad: DtActividadTuristica)
  - [x] Implementar
  - [x] Testear
- listarActividadesAsociadasADepartamento(nombreDepartamento: String): Set(String)
    - [x] Implementar
    - [x] Testear
- getActividadTuristica(nombre: String): DtActividadTuristica
  - [x] Implementar
  - [x] Testear
- listarActividadesAsociadasADepartamentoNoEnPaquete(nombreDepartamento: String, nombrePaquete:String): Set(String)
    - [x] Implementar
    - [x] Testear

### Controlador Departamento
- listarDepartamentos(): Set(String)
  - [x] Implementar
  - [x] Testear
- darDeAltaDepartamento(nombre: String, descripcion: String, url: URL)
    - [x] Implementar
    - [x] Testear

### Controlador Salida Turística
- darDeAltaSalidaTuristica(nuevaSalida: DtSalidaTuristica) 
  - [x] Implementar    **(falta checkear la validez de las fechas)**
  - [x] Testear
- listarSalidasAsociadasAActividadTuristica(nombreActividad: String): Set(String)
    - [x] Implementar
    - [x] Testear
- getSalidaTuristica(nombre: String): DtSalidaTuristica
  - [x] Implementar
  - [x] Testear
- listarSalidasVigentesAsociadasAActividadTuristica(nombreActividad: String): Set(String)
    - [x] Implementar    **(falta ver como se calcula la validez)**
    - [x] Testear
- inscribirTuristaASalidaTuristica(nuevaInscripcion: DtInscipcionSalida)
    - [x] Implementar  
    - [x] Testear

### Controlador Paquete Actividades
- darDeAltaPaquete(nuevoPaquete: DtPaqueteActvididades)
  - [ ] Implementar
  - [ ] Testear
- listarPaquetes(): Set(String)
    - [ ] Implementar
    - [ ] Testear
- ingresarActividadTuristicaAPaquete(nombreActividad: String, nombrePaquete: String)
  - [ ] Implementar
  - [ ] Testear
- getPaquete(nombre: String): DtPaquete
    - [ ] Implementar
    - [ ] Testear

---

### Data Types
- DtActividadTuristica
  - [x] Implementar
  - [ ] Testear
- DtInscipcionSalida
    - [x] Implementar
    - [ ] Testear
- DtProveedor
  - [x] Implementar
  - [ ] Testear
- DtSalidaTuristica
    - [x] Implementar
    - [ ] Testear
- DtTurista
  - [x] Implementar
  - [ ] Testear
- DtUsuario
    - [x] Implementar
    - [ ] Testear

---
### Entidades
- [x] ActividadTuristica
- [ ] CompraPaquete
- [x] Departamento
- [x] InscripcionSalida 
- [x] PaqueteActividades
- [x] Proveedor
- [x] SalidaTuristica
- [x] Turista
- [x] Usuario
---

### Manejadores:
- [x] Manejador Usuario
- [x] Manejador Actividad Turística
- [x] Manejador Salida Turística
- [x] Manejador Departamento
- [x] Manejador Paquete Actividades
- [x] Manejador Inscripcion Salida

---
### Fabrica
- [x] getIControladorActividadTuristica
- [x] getIControladorActividad
- [x] getIControladorDepartamento
- [x] getIControladorPaqueteActividades
- [x] getIControladorSalidaTuristica
- [x] getIControladorUsuario

- [x] getIManejadorActividadTuristica
- [x] getIManejadorActividad
- [x] getIManejadorDepartamento
- [x] getIManejadorPaqueteActividades
- [x] getIManejadorSalidaTuristica
- [x] getIManejadorUsuario
---

## Bugs - Problemas
- [ ] 000 - ejemplo de bug abierto
- [x] ~~001 - ejemplo de bug resuelto~~
- [x] ~~002 - falta implementar chequeos de validez en controladorSalida~~
- [ ] 003 - falta implementar mensajes de error en controladorSalida
