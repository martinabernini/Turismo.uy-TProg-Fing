package cargadatos;

import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtSalidaTuristica;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.interfaces.ICargaDatos;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorUsuario;

public class CargaDatos implements ICargaDatos {

    private Iterable<CSVRecord> recordsActividades;
    private Iterable<CSVRecord> recordsActividadesPaquetes;
    private Iterable<CSVRecord> recordsDepartamentos;
    private Iterable<CSVRecord> recordsInscripciones;
    private Iterable<CSVRecord> recordsPaquetes;
    private Iterable<CSVRecord> recordsSalidas;
    private Iterable<CSVRecord> recordsUsuarios;
    private Iterable<CSVRecord> recordsTuristas;
    private Iterable<CSVRecord> recordsProveedores;

    private Map<String, Map<String, String>> mapRecordsActividades = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsActividadesPaquetes = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsDepartamentos = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsInscripciones = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsPaquetes = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsSalidas = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsUsuarios = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsTuristas = new HashMap<String, Map<String, String>>();
    private Map<String, Map<String, String>> mapRecordsProveedores = new HashMap<String, Map<String, String>>();

    IControladorActividadTuristica controladorActividadTuristica;
    IControladorDepartamento controladorDepartamento;
    IControladorPaqueteActividades controladorPaqueteActividades;
    IControladorSalidaTuristica controladorSalidaTuristica;
    IControladorUsuario controladorUsuario;

    private static Boolean seCargoDatosAntes = false;

    public CargaDatos(IControladorActividadTuristica controladorActividadTuristica,
                      IControladorDepartamento controladorDepartamento,
                      IControladorPaqueteActividades controladorPaqueteActividades,
                      IControladorSalidaTuristica controladorSalidaTuristica, IControladorUsuario controladorUsuario) {

        this.controladorActividadTuristica = controladorActividadTuristica;
        this.controladorDepartamento = controladorDepartamento;
        this.controladorPaqueteActividades = controladorPaqueteActividades;
        this.controladorSalidaTuristica = controladorSalidaTuristica;
        this.controladorUsuario = controladorUsuario;
    }

    public void cargar() {
        if (seCargoDatosAntes) {
            return;
        }
        try {

            CSVFormat formatActividades = CSVFormat.DEFAULT.builder().setDelimiter(',').setHeader("Ref", "NombreActiv",
                            "Descripcion", "Duracion", "Costo", "Ciudad", "Departamento", "FechaAlta", "Ref.Proveedor")
                    .setSkipHeaderRecord(true).build();

            CSVFormat formatActividadesPaquetes = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("ref", "RefPaq", "RefActiv").setSkipHeaderRecord(true).build();

            CSVFormat formatDepartamento = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "Nombre", "Descripción", "Web").setSkipHeaderRecord(true).build();

            CSVFormat formatInscripciones = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "RefSal", "RefTur", "CantTur", "Costo", "FechaInscrip").setSkipHeaderRecord(true)
                    .build();

            CSVFormat formatPaquetes = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "Nombre", "Validez", "Descuento", "FechaAlta", "Descripción")
                    .setSkipHeaderRecord(true).build();

            CSVFormat formatSalidas = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "RefActiv", "Nombre", "Fecha", "Hora", "TuristaMax", "Lugar", "FechaAlta")
                    .setSkipHeaderRecord(true).build();

            CSVFormat formatUsuarios = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "Tipo", "Nickname", "Nombre", "Apellido", "EMail", "FechaNac")
                    .setSkipHeaderRecord(true).build();

            CSVFormat formatTuristas = CSVFormat.DEFAULT.builder().setDelimiter(',').setHeader("Ref", "Nacionalidad")
                    .setSkipHeaderRecord(true).build();

            CSVFormat formatProveedores = CSVFormat.DEFAULT.builder().setDelimiter(',')
                    .setHeader("Ref", "Descripción", "Web").setSkipHeaderRecord(true).build();


            // Chequea si se esta ejecutando desde la raiz del proyecto
            // y agrega un prefijo con la tarea que se esta ejecutando
            File file = new File(".");
            String prefijo = "";
            for (String fileNames : Objects.requireNonNull(file.list())) {
                if (fileNames.contains("Tarea") || fileNames.endsWith("1") || fileNames.endsWith("2") || fileNames.endsWith("3")) {
                    prefijo = fileNames + "/";
                }
            }

            recordsActividades = formatActividades.parse(new FileReader(prefijo + DatosPaths.ACTIVIDADES));
            recordsActividadesPaquetes = formatActividadesPaquetes.parse(new FileReader(prefijo + DatosPaths.ACTIVIDADES_PAQUETES));
            recordsDepartamentos = formatDepartamento.parse(new FileReader(prefijo + DatosPaths.DEPARTAMENTOS));
            recordsInscripciones = formatInscripciones.parse(new FileReader(prefijo + DatosPaths.INSCRIPCIONES));
            recordsPaquetes = formatPaquetes.parse(new FileReader(prefijo + DatosPaths.PAQUETES));
            recordsSalidas = formatSalidas.parse(new FileReader(prefijo + DatosPaths.SALIDAS));
            recordsUsuarios = formatUsuarios.parse(new FileReader(prefijo + DatosPaths.USUARIOS));
            recordsTuristas = formatTuristas.parse(new FileReader(prefijo + DatosPaths.USUARIOS_TURISTAS));
            recordsProveedores = formatProveedores.parse(new FileReader(prefijo + DatosPaths.USUARIOS_PROVEEDORES));

            llenarMapRecordsActividades();
            llenarMapRecordsActividadesPaquetes();
            llenarMapRecordsDepartamentos();
            llenarMapRecordsInscripciones();
            llenarMapRecordsPaquetes();
            llenarMapRecordsSalidas();
            llenarMapRecordsUsuarios();
            llenarMapRecordsTuristas();
            llenarMapRecordsProveedores();

            cargarUsuarios();
            cargarDepartamentos();
            cargarActividades();
            cargarSalidas();
            cargarInscripciones();
            cargarPaquetes();

            System.out.println("");
            System.out.println("- Finaliza carga      -------------------------------------------------");
            System.out.println("");

            seCargoDatosAntes = true;

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void cargarActividades() {
        System.out.println("");
        System.out.println("- Cargando actividades      -------------------------------------------------");

        try {

            for (Map<String, String> col : mapRecordsActividades.values()) {

                DtActividadTuristica nuevaActividad = new DtActividadTuristica();
                nuevaActividad.setNombre(col.get("NombreActiv"));
                nuevaActividad.setDescripcion(col.get("Descripcion"));
                nuevaActividad.setDuracionHrs(Integer.parseInt(col.get("Duracion").strip()));
                nuevaActividad.setCostoPorPersona(Float.parseFloat(col.get("Duracion").strip()));
                nuevaActividad.setCiudad(col.get("Ciudad"));
                nuevaActividad.setDepartamento(col.get("Departamento").strip());
                nuevaActividad.setFechaAlta(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaAlta")));
                String refProveedor = col.get("Ref.Proveedor").strip();
                String nickNameProveedor = mapRecordsUsuarios.get(refProveedor).get("Nickname");
                nuevaActividad.setProovedor(nickNameProveedor);
                try {
                    controladorActividadTuristica.darDeAltaActividadTuristica(nuevaActividad);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void cargarDepartamentos() {
        System.out.println("");
        System.out.println("- Cargando departamentos      -------------------------------------------------");

        try {
            for (Map<String, String> record : mapRecordsDepartamentos.values()) {
                String nombre = record.get("Nombre").strip();
                String descripcion = record.get("Descripción");
                String web = record.get("Web");

                // System.out.println("---------- agregando " + nombre);
                controladorDepartamento.darDeAltaDepartamento(nombre, descripcion, web);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void cargarInscripciones() {
        System.out.println("");
        System.out.println("- Cargando inscripciones      -------------------------------------------------");

        for (Map<String, String> col : mapRecordsInscripciones.values()) {
            DtInscripcionSalida nuevaInscripcion = new DtInscripcionSalida();

            try {
                nuevaInscripcion
                        .setNombreSalidaTuristica(mapRecordsSalidas.get(col.get("RefSal").strip()).get("Nombre"));
                nuevaInscripcion.setNickname(mapRecordsUsuarios.get(col.get("RefTur").strip()).get("Nickname"));
                nuevaInscripcion.setCantidadTuristas(Integer.parseInt(col.get("CantTur").strip()));
                nuevaInscripcion
                        .setFechaInscripcion(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaInscrip").strip()));

                controladorSalidaTuristica.inscribirTuristaASalidaTuristica(nuevaInscripcion);
            } catch (Exception e) {
                e.printStackTrace();
            }
            // System.out.println(nuevaInscripcion.toString());
        }
    }

    private void cargarPaquetes() {
        System.out.println("");
        System.out.println("- Cargando paquetes de actividades      --------------------------------------------");

        for (Map<String, String> col : mapRecordsPaquetes.values()) {

            DtPaqueteActividades nuevoPaquete = new DtPaqueteActividades();
            try {

                nuevoPaquete.setNombre(col.get("Nombre"));
                nuevoPaquete.setDescripcion(col.get("Descripción"));
                nuevoPaquete.setFechaAlta(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaAlta")));
                nuevoPaquete.setValidezEnDias(Integer.parseInt(col.get("Validez")));
                try {
                    nuevoPaquete.setDescuento(Float.parseFloat(col.get("Descuento")) / 100);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }

                controladorPaqueteActividades.darDeAltaPaquete(nuevoPaquete);

                for (Map<String, String> colActPaq : mapRecordsActividadesPaquetes.values()) {

                    String refPaq = colActPaq.get("RefPaq").strip().substring(1, 2);
                    String paqueteActual = col.get("Ref").strip().substring(1, 2);

                    int refPaqInt = Integer.parseInt(refPaq);
                    int paqueteActualInt = Integer.parseInt(paqueteActual);

                    if (refPaqInt == paqueteActualInt) {
                        String nombreActividad = mapRecordsActividades.get(colActPaq.get("RefActiv"))
                                .get("NombreActiv");
                        controladorPaqueteActividades.ingresarActividadTuristicaAPaquete(nombreActividad,
                                nuevoPaquete.getNombre());
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @SuppressWarnings("deprecation")
    private void cargarSalidas() {
        System.out.println("");
        System.out.println("- Cargando salidas      -------------------------------------------------");

        // List<DtSalidaTuristica> nuevasSalidas = new ArrayList<DtSalidaTuristica>();

        for (Map<String, String> col : mapRecordsSalidas.values()) {

            DtSalidaTuristica nuevaSalida = new DtSalidaTuristica();
            try {
                int horaSalidaInt = Integer.parseInt(col.get("Hora").split("hs")[0].strip());
                Date fechaSalida = new SimpleDateFormat("dd/MM/yyyy").parse(col.get("Fecha").strip());
                fechaSalida.setHours(horaSalidaInt); // altertnativa int horaSalidaInt =
                // Integer.parseInt(horaSalida.strip().substring(0,2));

                nuevaSalida.setNombreSalida(col.get("Nombre"));
                nuevaSalida.setFechaSalida(fechaSalida);
                nuevaSalida.setCantidadMaximaTuristas(Integer.parseInt(col.get("TuristaMax").strip()));
                nuevaSalida.setLugarSalida(col.get("Lugar"));
                nuevaSalida.setFechaAlta(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaAlta").strip()));
                nuevaSalida
                        .setNombreActividad(mapRecordsActividades.get(col.get("RefActiv").strip()).get("NombreActiv"));

                controladorSalidaTuristica.darDeAltaSalidaTuristica(nuevaSalida);
                // System.out.println("------------"+ nuevaSalida.toString());

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // -----------------------------------------------------------------------------------------
    private void cargarUsuarios() {
        System.out.println("");
        System.out.println("- Cargando usuarios      -------------------------------------------------");

        List<DtUsuario> nuevosUsuarios = new ArrayList<DtUsuario>();

        for (Map<String, String> col : mapRecordsUsuarios.values()) {

            if (col.get("Tipo").contains("T")) {
                DtTurista nuevoTurista = new DtTurista();

                try {
                    nuevoTurista.setNickname(col.get("Nickname"));
                    nuevoTurista.setNombre(col.get("Nombre"));
                    nuevoTurista.setApellido(col.get("Apellido"));
                    nuevoTurista.setEmail(col.get("EMail"));
                    nuevoTurista.setFechaNacimiento(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaNac")));
                    nuevoTurista.setNacionalidad(mapRecordsTuristas.get(col.get("Ref")).get("Nacionalidad"));

                    nuevosUsuarios.add(nuevoTurista);

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            } else {
                DtProveedor nuevoProveedor = new DtProveedor();

                try {

                    nuevoProveedor.setNickname(col.get("Nickname"));
                    nuevoProveedor.setNombre(col.get("Nombre"));
                    nuevoProveedor.setApellido(col.get("Apellido"));
                    nuevoProveedor.setEmail(col.get("EMail"));
                    nuevoProveedor.setFechaNacimiento(new SimpleDateFormat("dd/MM/yyyy").parse(col.get("FechaNac")));

                    nuevoProveedor.setDescripcion(mapRecordsProveedores.get(col.get("Ref")).get("Descripción"));
                    nuevoProveedor.setUrlSitioWeb(mapRecordsProveedores.get(col.get("Ref")).get("Web"));

                    nuevosUsuarios.add(nuevoProveedor);
                } catch (ParseException e) {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        try {
            for (DtUsuario nuevoUsuario : nuevosUsuarios) {
                controladorUsuario.darDeAltaUsuario(nuevoUsuario);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ------------------------------------------------------------------------------------------
    private void llenarMapRecordsActividades() {
        for (CSVRecord record : recordsActividades) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("NombreActiv", record.get("NombreActiv").strip().toLowerCase());
            columnas.put("Descripcion", record.get("Descripcion").strip());
            columnas.put("Duracion", record.get("Duracion").strip());
            columnas.put("Costo", record.get("Costo").strip());
            columnas.put("Ciudad", record.get("Ciudad").strip());
            columnas.put("Departamento", record.get("Departamento").strip().toLowerCase());
            columnas.put("FechaAlta", record.get("FechaAlta").strip());
            columnas.put("Ref.Proveedor", record.get("Ref.Proveedor").strip().toLowerCase());

            mapRecordsActividades.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsActividadesPaquetes() {
        for (CSVRecord record : recordsActividadesPaquetes) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("ref", record.get("ref").strip().toLowerCase());
            columnas.put("RefPaq", record.get("RefPaq").strip().toLowerCase());
            columnas.put("RefActiv", record.get("RefActiv").strip().toLowerCase());

            mapRecordsActividadesPaquetes.put(record.get("ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsDepartamentos() {
        for (CSVRecord record : recordsDepartamentos) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("Nombre", record.get("Nombre").strip().toLowerCase());
            columnas.put("Descripción", record.get("Descripción").strip());
            columnas.put("Web", record.get("Web").strip());

            mapRecordsDepartamentos.put(record.get("Ref").strip().toLowerCase(), columnas);

        }
    }

    ;

    private void llenarMapRecordsInscripciones() {
        for (CSVRecord record : recordsInscripciones) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("RefSal", record.get("RefSal").strip().toLowerCase());
            columnas.put("RefTur", record.get("RefTur").strip().toLowerCase());
            columnas.put("CantTur", record.get("CantTur").strip());
            columnas.put("Costo", record.get("Costo").strip());
            columnas.put("FechaInscrip", record.get("FechaInscrip").strip());

            mapRecordsInscripciones.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsPaquetes() {
        for (CSVRecord record : recordsPaquetes) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("Nombre", record.get("Nombre").strip().toLowerCase());
            columnas.put("Validez", record.get("Validez").strip());
            columnas.put("Descuento", record.get("Descuento").strip());
            columnas.put("FechaAlta", record.get("FechaAlta").strip());
            columnas.put("Descripción", record.get("Descripción").strip());

            mapRecordsPaquetes.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsSalidas() {
        for (CSVRecord record : recordsSalidas) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("RefActiv", record.get("RefActiv").strip().toLowerCase());
            columnas.put("Nombre", record.get("Nombre").strip().toLowerCase());
            columnas.put("Fecha", record.get("Fecha").strip());
            columnas.put("Hora", record.get("Hora").strip());
            columnas.put("TuristaMax", record.get("TuristaMax").strip());
            columnas.put("Hora", record.get("Hora").strip());
            columnas.put("Lugar", record.get("Lugar").strip());
            columnas.put("FechaAlta", record.get("FechaAlta").strip());

            mapRecordsSalidas.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsUsuarios() {
        for (CSVRecord record : recordsUsuarios) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("Tipo", record.get("Tipo").strip());
            columnas.put("Nickname", record.get("Nickname").strip().toLowerCase());
            columnas.put("Nombre", record.get("Nombre").strip());
            columnas.put("Apellido", record.get("Apellido").strip());
            columnas.put("EMail", record.get("EMail").strip().toLowerCase());
            columnas.put("FechaNac", record.get("FechaNac").strip());

            mapRecordsUsuarios.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsTuristas() {
        for (CSVRecord record : recordsTuristas) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("Nacionalidad", record.get("Nacionalidad").strip());

            mapRecordsTuristas.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

    private void llenarMapRecordsProveedores() {
        for (CSVRecord record : recordsProveedores) {
            Map<String, String> columnas = new HashMap<String, String>();

            columnas.put("Ref", record.get("Ref").strip().toLowerCase());
            columnas.put("Descripción", record.get("Descripción").strip());
            columnas.put("Web", record.get("Web").strip());

            mapRecordsProveedores.put(record.get("Ref").strip().toLowerCase(), columnas);
        }
    }

    ;

}
