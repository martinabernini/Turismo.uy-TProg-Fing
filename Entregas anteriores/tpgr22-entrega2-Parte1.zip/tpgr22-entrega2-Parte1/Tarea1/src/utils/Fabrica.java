package utils;

import cargadatos.CargaDatos;
import logica.controladores.ControladorActividadTuristica;
import logica.controladores.ControladorDepartamento;
import logica.controladores.ControladorPaqueteActividades;
import logica.controladores.ControladorSalidaTuristica;
import logica.controladores.ControladorUsuario;
import logica.manejadores.ManejadorActividadTuristica;
import logica.manejadores.ManejadorDepartamento;
import logica.manejadores.ManejadorInscripcionSalida;
import logica.manejadores.ManejadorPaqueteActividades;
import logica.manejadores.ManejadorSalidaTuristica;
import logica.manejadores.ManejadorUsuario;
import logica.validacion.Validador;
import logica.interfaces.ICargaDatos;
import logica.interfaces.IControladorActividadTuristica;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IControladorSalidaTuristica;
import logica.interfaces.IControladorUsuario;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;
import logica.interfaces.IManejadorInscripcionSalida;
import logica.interfaces.IManejadorPaqueteActividades;
import logica.interfaces.IManejadorSalidaTuristica;
import logica.interfaces.IManejadorUsuario;
import logica.interfaces.IValidador;

public class Fabrica {

	private Boolean logManejadores = true;
	private Boolean logControladores = true;
	private Boolean logValidacion = true;

	private static Fabrica instancia;

	private Fabrica() {
	};

	public static Fabrica getInstance() {
		if (instancia == null) {
			instancia = new Fabrica();
		}

		return instancia;
	}

	// ----------------------------------------------------------------
	// ----------------------------------------------------------------

	public IControladorActividadTuristica getIControladorActividadTuristica() {

		IControladorActividadTuristica controladorActividades = new ControladorActividadTuristica(
				getIManejadorActividadTuristica(), getIManejadorDepartamento(), getIManejadorUsuario(),
				getIValidador());

		if (logControladores) {
			return DynamicProxy.withLogging(controladorActividades, IControladorActividadTuristica.class);
		}

		return controladorActividades;
	}

	public IControladorDepartamento getIControladorDepartamento() {

		IControladorDepartamento controladorDepartamento = new ControladorDepartamento(getIManejadorDepartamento());

		if (logControladores) {
			return DynamicProxy.withLogging(controladorDepartamento, IControladorDepartamento.class);
		}

		return controladorDepartamento;
	}

	public IControladorPaqueteActividades getIControladorPaqueteActividades() {

		IControladorPaqueteActividades controladorPaquetes = new ControladorPaqueteActividades(
				getIManejadorPaqueteActividades(), getIManejadorActividadTuristica(), getIValidador());

		if (logControladores) {
			return DynamicProxy.withLogging(controladorPaquetes, IControladorPaqueteActividades.class);
		}

		return controladorPaquetes;
	}

	public IControladorSalidaTuristica getIControladorSalidaTuristica() {

		IControladorSalidaTuristica controladorSalida = new ControladorSalidaTuristica(getIManejadorSalidaTuristica(),
				getIManejadorUsuario(), getIManejadorInscripcionSalida(), getIManejadorActividadTuristica(),
				getIValidador());

		if (logControladores) {
			return DynamicProxy.withLogging(controladorSalida, IControladorSalidaTuristica.class);
		}

		return controladorSalida;

	}

	public IControladorUsuario getIControladorUsuario() {

		IControladorUsuario controladorUsuario = new ControladorUsuario(getIManejadorUsuario(), getIValidador());

		if (logControladores) {
			return DynamicProxy.withLogging(controladorUsuario, IControladorUsuario.class);
		}

		return controladorUsuario;
	}

	// ----------------------------------------------------------------

	public IManejadorActividadTuristica getIManejadorActividadTuristica() {

		IManejadorActividadTuristica manejadorActividad = ManejadorActividadTuristica
				.getInstance(getIManejadorDepartamento());

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorActividad, IManejadorActividadTuristica.class);
		}

		return manejadorActividad;
	}

	public IManejadorDepartamento getIManejadorDepartamento() {

		IManejadorDepartamento manejadorDepartamento = ManejadorDepartamento.getInstance();

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorDepartamento, IManejadorDepartamento.class);
		}

		return manejadorDepartamento;
	}

	public IManejadorPaqueteActividades getIManejadorPaqueteActividades() {

		IManejadorPaqueteActividades manejadorPaquetes = ManejadorPaqueteActividades.getInstance();

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorPaquetes, IManejadorPaqueteActividades.class);
		}

		return manejadorPaquetes;
	}

	public IManejadorSalidaTuristica getIManejadorSalidaTuristica() {

		IManejadorSalidaTuristica manejadorSalida = ManejadorSalidaTuristica
				.getInstance(getIManejadorActividadTuristica());

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorSalida, IManejadorSalidaTuristica.class);
		}

		return manejadorSalida;
	}

	public IManejadorUsuario getIManejadorUsuario() {

		IManejadorUsuario manejadorUsuario = ManejadorUsuario.getInstance();

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorUsuario, IManejadorUsuario.class);
		}

		return manejadorUsuario;
	}

	public IManejadorInscripcionSalida getIManejadorInscripcionSalida() {

		IManejadorInscripcionSalida manejadorInscripcionSalida = ManejadorInscripcionSalida.getInstance();

		if (logManejadores) {
			return DynamicProxy.withLogging(manejadorInscripcionSalida, IManejadorInscripcionSalida.class);
		}

		return manejadorInscripcionSalida;
	}

	// ----------------------------------------------------------------

	public IValidador getIValidador() {

		if (logValidacion) {
			return DynamicProxy.withLogging(new Validador(), IValidador.class);
		}

		return new Validador();
	}

	public ICargaDatos getICargaDatos() {

		ICargaDatos cargaDatos = new CargaDatos(getIControladorActividadTuristica(), getIControladorDepartamento(),
				getIControladorPaqueteActividades(), getIControladorSalidaTuristica(), getIControladorUsuario());

		return cargaDatos;
	}
	// ----------------------------------------------------------------

	public void setLogManejadores(Boolean log) {
		logManejadores = log;
	};

	public void setLogControladores(Boolean log) {
		logControladores = log;
	};

	// ----------------------------------------------------------------

}
