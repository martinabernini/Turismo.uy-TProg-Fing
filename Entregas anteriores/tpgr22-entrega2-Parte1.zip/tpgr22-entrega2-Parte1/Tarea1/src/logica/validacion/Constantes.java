package logica.validacion;

public final class Constantes {
    public static int MENOR_CANTIDAD_MAXIMA_DE_TURISTAS_EN_SALIDA = 0;

    public static int MENOR_CANTIDAD_DE_TURISTAS_INSCRIBLES_A_SALIDA = 0;

}
