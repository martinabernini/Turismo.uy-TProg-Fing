package logica.validacion;

import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtSalidaTuristica;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;
import logica.entidades.InscripcionSalida;
import logica.entidades.Turista;
import logica.interfaces.IValidador;

public class Validador implements IValidador {

	public Boolean campoInvalidoAltaUsuario(DtUsuario usuario) {

		Boolean hayCampoInvalido;

		hayCampoInvalido = nullOrEmpty(usuario.getNickname()) || nullOrEmpty(usuario.getNombre())
				|| nullOrEmpty(usuario.getApellido()) || nullOrEmpty(usuario.getEmail())
				|| usuario.getFechaNacimiento() == null;

		if (usuario instanceof DtProveedor) {
			return hayCampoInvalido || nullOrEmpty(((DtProveedor) usuario).getDescripcion());
		}

		return hayCampoInvalido || nullOrEmpty(((DtTurista) usuario).getNacionalidad());

	}

	public Boolean campoInvalidoModificarUsuario(DtUsuario usuario) {
		// de momento es igual al alta, si quisieramos otro comportamiento se puede
		// cambiar
		return campoInvalidoAltaUsuario(usuario);
	}

	public Boolean campoInvalidoAltaActividad(DtActividadTuristica actividad) {

		return nullOrEmpty(actividad.getNombre()) || nullOrEmpty(actividad.getDescripcion())
				|| actividad.getDuracionHrs() < 0 || actividad.getCostoPorPersona() < 0
				|| nullOrEmpty(actividad.getCiudad()) || actividad.getFechaAlta() == null
				|| nullOrEmpty(actividad.getDepartamento()) || nullOrEmpty(actividad.getProovedor());

	}

	public Boolean campoInvalidoAltaSalida(DtSalidaTuristica salida) {

		return nullOrEmpty(salida.getNombreActividad()) || nullOrEmpty(salida.getNombreSalida())
				|| nullOrEmpty(salida.getLugarSalida()) || salida.getCantidadMaximaTuristas() < Constantes.MENOR_CANTIDAD_MAXIMA_DE_TURISTAS_EN_SALIDA
				|| salida.getFechaSalida() == null || salida.getFechaAlta() == null
				|| salida.getFechaSalida().before(salida.getFechaAlta());
	}

	public Boolean campoInvalidoInscripcionASalida(DtInscripcionSalida inscripcion) {

		return nullOrEmpty(inscripcion.getNickname()) || nullOrEmpty(inscripcion.getNombreSalidaTuristica())
				|| inscripcion.getCantidadTuristas() < 1;
	}

	public Boolean usuarioYaEstaRegistradoASalida(Turista turista, DtInscripcionSalida nuevaInscripcion) {

		for (InscripcionSalida inscripcion : turista.getInscripciones().values()) {
			if (inscripcion.getSalida().getNombre() == nuevaInscripcion.getNombreSalidaTuristica()) {
				return true;
			}
		}

		return false;
	}

	public Boolean campoInvalidoAltaPaquete(DtPaqueteActividades paquete) {
		// TODO implementar
		return false;
	}

	// -------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------

	private Boolean nullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

}
