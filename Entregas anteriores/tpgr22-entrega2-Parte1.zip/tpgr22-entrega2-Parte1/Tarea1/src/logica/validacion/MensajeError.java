package logica.validacion;

import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtProveedor;
import logica.datatypes.DtSalidaTuristica;
import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;

public class MensajeError {

	public static String campoInvalidoAltaUsuario(DtUsuario usuario) {
		String mensajeError = "";

		if (nullOrEmpty(usuario.getNombre())) {
			mensajeError += "Nombre invalido. ";
		}
		if (nullOrEmpty(usuario.getNickname())) {
			mensajeError += "Nickname invalido. ";
		}
		if (nullOrEmpty(usuario.getApellido())) {
			mensajeError += "Apellido invalido. ";
		}
		if (nullOrEmpty(usuario.getEmail())) {
			mensajeError += "Email invalido. ";
		}
		if (usuario.getFechaNacimiento() == null) {
			mensajeError += "Fecha de nacimiento invalida. ";
		}
		if (usuario instanceof DtProveedor) {

			if (nullOrEmpty(((DtProveedor) usuario).getDescripcion())) {
				mensajeError += "Descripcion invalida. ";
			}
			return mensajeError;
		}
		if (nullOrEmpty(((DtTurista) usuario).getNacionalidad())) {
			return mensajeError + "Nacionalidad invalida. ";
		}
		return mensajeError;

	}

	public static String campoInvalidoModificarUsuario(DtUsuario usuario) {
		// de momento es igual al alta, si quisieramos otro comportamiento se puede
		// cambiar
		return campoInvalidoAltaUsuario(usuario);
	}

	public static String campoInvalidoAltaActividad(DtActividadTuristica actividad) {
		String mensajeError = "";

		if (nullOrEmpty(actividad.getNombre())) {
			mensajeError += "Nombre invalido. ";
		}
		if (nullOrEmpty(actividad.getDescripcion())) {
			mensajeError += "Descripcion invalida. ";
		}
		if (actividad.getDuracionHrs() < 0) {
			mensajeError += "Duracion en horas invilida. ";
		}
		if (actividad.getCostoPorPersona() < 0) {
			mensajeError += "Costo por persona invilido. ";
		}
		if (nullOrEmpty(actividad.getCiudad())) {
			mensajeError += "Ciudad invilida. ";
		}
		if (actividad.getFechaAlta() == null) {
			mensajeError += "Fecha de alta invilida. ";
		}
		if (nullOrEmpty(actividad.getDepartamento())) {
			mensajeError += "Departamento invilido. ";
		}
		if (nullOrEmpty(actividad.getProovedor())) {
			mensajeError += "Proovedor invilido. ";
		}
		return mensajeError;
	}

	public static String campoInvalidoAltaSalida(DtSalidaTuristica salida) {
		String mensajeError = "";
		if (nullOrEmpty(salida.getNombreActividad())) {
			mensajeError += "Nombre actividad invalido. ";
		}
		if (nullOrEmpty(salida.getNombreSalida())) {
			mensajeError += "Nombre salida invalido. ";
		}
		if (salida.getFechaSalida() == null) {
			mensajeError += "Fecha salida invalida. ";
		}
		if (salida.getFechaAlta() == null) {
			mensajeError += "Fecha alta invalida. ";
		}
		if (nullOrEmpty(salida.getLugarSalida())) {
			mensajeError += "Lugar salida invalido. ";
		}
		if (salida.getCantidadMaximaTuristas() < Constantes.MENOR_CANTIDAD_MAXIMA_DE_TURISTAS_EN_SALIDA) {
			mensajeError += "Cantidad maxima de turistas invalida. ";
		}
		if (salida.getFechaSalida() != null && salida.getFechaAlta() != null && salida.getFechaSalida().before(salida.getFechaAlta())) {
			mensajeError += "La fecha de salida no puede ser anterior a la fecha de alta. ";
		}
		return mensajeError;
	}

	public static String campoInvalidoInscripcionASalida(DtInscripcionSalida inscripcionSalida) {
		String mensajeError = "";
		if (nullOrEmpty(inscripcionSalida.getNickname())) {
			mensajeError += "Nickname invalido. ";
		}
		if (nullOrEmpty(inscripcionSalida.getNombreSalidaTuristica())) {
			mensajeError += "Nombre salida turistica invalido. ";
		}
		if (inscripcionSalida.getCantidadTuristas() < Constantes.MENOR_CANTIDAD_DE_TURISTAS_INSCRIBLES_A_SALIDA) {
			mensajeError += "Cantidad turistas invalido. ";
		}
		return mensajeError;
	}

	public static String campoInvalidoAltaPaquete(DtPaqueteActividades paquete) {
		// TODO: implementar
		return "Campo invalido";
	}

	public static String campoInvalidoAltaDepartamento(String nombre, String descripcion, String url) {
		String mensajeError = "";

		if (nullOrEmpty(nombre)) {
			mensajeError += "Nombre invalido. ";
		}
		if (nullOrEmpty(descripcion)) {
			mensajeError += "Descripcion invalida. ";
		}
		if (nullOrEmpty(url)) {
			mensajeError += "Url invalida. ";
		}
		return mensajeError;
	}

	// --------------------------------------------------------------------
	// --------------------------------------------------------------------

	private static Boolean nullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

}
