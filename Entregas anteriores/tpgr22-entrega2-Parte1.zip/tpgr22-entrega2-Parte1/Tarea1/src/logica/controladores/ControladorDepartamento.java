package logica.controladores;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.entidades.Departamento;
import logica.interfaces.IControladorDepartamento;
import logica.interfaces.IManejadorDepartamento;
import logica.validacion.MensajeError;

public class ControladorDepartamento implements IControladorDepartamento {

	private final IManejadorDepartamento manejadorDepartamento;

	public ControladorDepartamento(IManejadorDepartamento manejadorDepartamento) {
		this.manejadorDepartamento = manejadorDepartamento;
	}

	// ---------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------

	public String[] listarDepartamentos() throws NoHayEntidadesParaListarException {

		Departamento[] listaDepartamentos = manejadorDepartamento.getAll();

		if (listaDepartamentos == null) {
			throw new NoHayEntidadesParaListarException("No hay departamentos para listar");
		}

		String[] listaNombres = new String[listaDepartamentos.length];

		for (int i = 0; i < listaDepartamentos.length; i++) {
			listaNombres[i] = listaDepartamentos[i].getNombre();
		}

		return listaNombres;
	}

	public void darDeAltaDepartamento(String nombre, String descripcion, String url)
			throws CampoInvalidoException, EntidadRepetidaException {

		Boolean hayCampoInvalido = nullOrEmpty(nombre) || nullOrEmpty(descripcion) || nullOrEmpty(url);

		if (hayCampoInvalido) {
			throw new CampoInvalidoException(MensajeError.campoInvalidoAltaDepartamento(nombre, descripcion, url));
		}

		if (manejadorDepartamento.contains(nombre)) {
			throw new EntidadRepetidaException("Ya hay un departamento registrado con ese nombre");
		}

		manejadorDepartamento.add(new Departamento(nombre, descripcion, url));

	}

	// ---------------------------------------------------------------------------------------------

	private Boolean nullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

}
