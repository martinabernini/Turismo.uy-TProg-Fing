
package logica.controladores;

import logica.datatypes.DtActividadTuristica;
import logica.interfaces.IControladorActividadTuristica;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.entidades.ActividadTuristica;
import logica.entidades.Departamento;
import logica.entidades.Proveedor;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;
import logica.interfaces.IManejadorUsuario;
import logica.interfaces.IValidador;
import logica.validacion.MensajeError;

public class ControladorActividadTuristica implements IControladorActividadTuristica {

	private final IManejadorActividadTuristica manejadorActividadTuristica;
	private final IManejadorDepartamento manejadorDepartamento;
	private final IManejadorUsuario manejadorUsuario;
	private final IValidador validador;

	public ControladorActividadTuristica(IManejadorActividadTuristica manejadorActividadTuristica,
			IManejadorDepartamento manejadorDepartamento, IManejadorUsuario manejadorUsuario, IValidador validador) {
		this.manejadorActividadTuristica = manejadorActividadTuristica;
		this.manejadorDepartamento = manejadorDepartamento;
		this.manejadorUsuario = manejadorUsuario;
		this.validador = validador;
	}

	// ---------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------

	public void darDeAltaActividadTuristica(DtActividadTuristica nuevaActividad)
			throws CampoInvalidoException, EntidadRepetidaException {

		if (validador.campoInvalidoAltaActividad(nuevaActividad)) {
			throw new CampoInvalidoException(MensajeError.campoInvalidoAltaActividad(nuevaActividad));
		}

		if (manejadorActividadTuristica.contains(nuevaActividad.getNombre()))
			throw new EntidadRepetidaException("Ya hay una actividad turistica con ese nombre");

		if (!manejadorDepartamento.contains(nuevaActividad.getDepartamento())) {
			throw new CampoInvalidoException(
					"No existe ese departamento en el sistema: " + nuevaActividad.getDepartamento());
		}

		Proveedor proveedor = (Proveedor) manejadorUsuario.find(nuevaActividad.getProovedor());

		if (proveedor == null) {
			throw new CampoInvalidoException("Nombre de proveedor invalido: " + nuevaActividad.getProovedor());
		}

		Departamento departamento = manejadorDepartamento.find(nuevaActividad.getDepartamento());
		
		// Se crea la actividad con link al Departamento
		ActividadTuristica actividad = new ActividadTuristica();
		actividad.setNombre(nuevaActividad.getNombre());
		actividad.setDescripcion(nuevaActividad.getDescripcion());
		actividad.setDuracionHrs(nuevaActividad.getDuracionHrs());
		actividad.setCostoPorPersona(nuevaActividad.getCostoPorPersona());
		actividad.setCiudad(nuevaActividad.getCiudad());
		actividad.setFechaAlta(nuevaActividad.getFechaAlta());
		actividad.setDepartamento(departamento);
		actividad.setProveedor(proveedor);

		// Link de majeador a Actividad
		manejadorActividadTuristica.add(actividad);

		// Link de Departamento a Actividad
		departamento.agregarActividadTuristica(actividad);
		manejadorDepartamento.update(departamento);

		proveedor.agregarActividadTuristica(actividad);
		manejadorUsuario.update(proveedor);
	}

	public String[] listarActividadesAsociadasADepartamento(String nombre)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		if (nullOrEmpty(nombre)) {
			throw new CampoInvalidoException("Nombre de departamento invalido");
		}

		if (!manejadorDepartamento.contains(nombre)) {
			throw new CampoInvalidoException("No existe ese departamento en el sistema");
		}

		ActividadTuristica[] actividades = manejadorDepartamento
				.getAllActividadesAsociadasADepartamento(nombre);

		if (actividades == null) {
			throw new NoHayEntidadesParaListarException("No hay actividades asociadas a departamento");
		}

		String[] nombreActs = new String[actividades.length];

		for (int i = 0; i < actividades.length; i++) {
			nombreActs[i] = actividades[i].getNombre();
		}

		return nombreActs;
	}

	public DtActividadTuristica getActividadTuristica(String nombre)
			throws EntidadNoExisteException, CampoInvalidoException {

		if (nullOrEmpty(nombre)) {
			throw new CampoInvalidoException("Nombre actividad invalido: " + nombre);
		}

		if (!manejadorActividadTuristica.contains(nombre)) {
			throw new EntidadNoExisteException("No existe actividad con ese nombre");
		}

		return manejadorActividadTuristica.find(nombre).newDataType();
	}

	public String[] listarActividadesAsocadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		if (nullOrEmpty(nombreDepto) || nullOrEmpty(nombrePaquete)) {
			throw new CampoInvalidoException("Campo invalido");
		}

		ActividadTuristica[] actividadesNoEnPaquete = manejadorDepartamento
				.getAllActividadesAsociadasADepartamentoNoEnPaquete(nombreDepto, nombrePaquete);

		if (actividadesNoEnPaquete == null) {
			throw new NoHayEntidadesParaListarException("No hay actividades para listar que no esten en ese paquete");
		}

		String[] nombreActividadesNoEnPaquete = new String[actividadesNoEnPaquete.length];

		for (int i = 0; i < actividadesNoEnPaquete.length; i++) {
			nombreActividadesNoEnPaquete[i] = actividadesNoEnPaquete[i].getNombre();
		}

		return nombreActividadesNoEnPaquete;
	}

	// ---------------------------------------------------------------------------------------------

	private Boolean nullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

}
