package logica.controladores;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtPaqueteActividades;
import logica.entidades.ActividadTuristica;
import logica.entidades.PaqueteActividades;
import logica.interfaces.IControladorPaqueteActividades;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorPaqueteActividades;
import logica.interfaces.IValidador;
import logica.validacion.MensajeError;

public class ControladorPaqueteActividades implements IControladorPaqueteActividades {

	private final IManejadorPaqueteActividades manejadorPaqueteActividades;
	private final IManejadorActividadTuristica manejadorActividadTuristica;
	private final IValidador validador;

	public ControladorPaqueteActividades(IManejadorPaqueteActividades manejadorPaqueteActividades,
			IManejadorActividadTuristica manejadorActividadTuristica, IValidador validador) {
		this.manejadorPaqueteActividades = manejadorPaqueteActividades;
		this.manejadorActividadTuristica = manejadorActividadTuristica;
		this.validador = validador;
	}

	// ---------------------------------------------------------------------------------------------------------
	// NO ESTAN IMPLEMENTADO LOS CHEQUEOS, ES SOLO PARA QUE FUNCIONE CON LOS DATOS
	// DE CARGA, LO QUE ESTA ACA ES TEMPORAL
	// ---------------------------------------------------------------------------------------------------------

	public void darDeAltaPaquete(DtPaqueteActividades nuevoPaquete)
			throws CampoInvalidoException, EntidadRepetidaException {
		// FALTAN TODOS LOS CHEQUEOS

		// No esta implementado campoInvalidoAltaPaquete en Validador, tira false por
		// ahora
		if (validador.campoInvalidoAltaPaquete(nuevoPaquete)) {
			throw new CampoInvalidoException(MensajeError.campoInvalidoAltaPaquete(nuevoPaquete));
		}

		PaqueteActividades paquete = new PaqueteActividades();
		paquete.setNombre(nuevoPaquete.getNombre());
		paquete.setDescripcion(nuevoPaquete.getDescripcion());
		paquete.setDescuento(nuevoPaquete.getDescuento());
		paquete.setNombre(nuevoPaquete.getNombre());
		paquete.setFechaAlta(nuevoPaquete.getFechaAlta());
		paquete.setValidezEnDias(nuevoPaquete.getValidezEnDias());

		manejadorPaqueteActividades.add(paquete);
	}

	public String[] listarPaquetes() throws NoHayEntidadesParaListarException {

		// HAY QUE TIRAR ERRORES EN REALIDAD

		PaqueteActividades[] paquetes = manejadorPaqueteActividades.getAll();
		if (paquetes == null || paquetes.length == 0) {
			// en realidad habria que tirar errores
			return new String[] { "" };
		}
		;
		String[] listaNombres = new String[paquetes.length];

		for (int i = 0; i < paquetes.length; i++) {
			listaNombres[i] = paquetes[i].getNombre();
		}

		return listaNombres;
	}

	public String[] listarActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException {

		return new String[] {};
	}

	public void ingresarActividadTuristicaAPaquete(String nombreActividad, String nombrePaquete)
			throws EntidadRepetidaException, CampoInvalidoException {

		// FALTAN TODOS LO CHEQUEOS Y TIRADAS DE ERROR

		PaqueteActividades paquete = manejadorPaqueteActividades.find(nombrePaquete);
		ActividadTuristica actividad = manejadorActividadTuristica.find(nombreActividad);

		paquete.agregarActividad(actividad);
		manejadorPaqueteActividades.update(paquete);

		actividad.agregarPaqueteAsociado(paquete);
		manejadorActividadTuristica.update(actividad);
	}

	public DtPaqueteActividades find(String nombre) throws EntidadRepetidaException, CampoInvalidoException {

		// FALTAN TODOS LO CHEQUEOS Y TIRADAS DE ERROR

		if (manejadorPaqueteActividades.contains(nombre)) {
			return manejadorPaqueteActividades.find(nombre).newDataType();
		}

		return null;
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

}
