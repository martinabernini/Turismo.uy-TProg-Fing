package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtPaqueteActividades;

public interface IControladorPaqueteActividades {

	void darDeAltaPaquete(DtPaqueteActividades nuevoPaquete) throws CampoInvalidoException, EntidadRepetidaException;

	String[] listarPaquetes() throws NoHayEntidadesParaListarException;

	String[] listarActividadesAsociadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException;

	void ingresarActividadTuristicaAPaquete(String nombreActividad, String nombrePaquete)
			throws EntidadRepetidaException, CampoInvalidoException;

	DtPaqueteActividades find(String nombre) throws EntidadRepetidaException, CampoInvalidoException;

}
