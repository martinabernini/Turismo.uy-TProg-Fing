package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;

public interface IControladorDepartamento {

	String[] listarDepartamentos() throws NoHayEntidadesParaListarException;

	void darDeAltaDepartamento(String nombre, String descripcion, String url) throws CampoInvalidoException, EntidadRepetidaException;
	
}
