package logica.interfaces;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
//import logica.datatypes.DtInscripcionSalida;

public interface IControladorActividadTuristica {

	void darDeAltaActividadTuristica(DtActividadTuristica nuevaActividad)
			throws CampoInvalidoException, EntidadRepetidaException;

	String[] listarActividadesAsociadasADepartamento(String nombre)
			throws NoHayEntidadesParaListarException, CampoInvalidoException;

	DtActividadTuristica getActividadTuristica(String nombre)
			throws EntidadNoExisteException, CampoInvalidoException;

	String[] listarActividadesAsocadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete)
			throws NoHayEntidadesParaListarException, CampoInvalidoException;

}
