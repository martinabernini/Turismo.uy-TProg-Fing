package logica.interfaces;

import logica.datatypes.DtActividadTuristica;
import logica.datatypes.DtInscripcionSalida;
import logica.datatypes.DtPaqueteActividades;
import logica.datatypes.DtSalidaTuristica;
import logica.datatypes.DtUsuario;
import logica.entidades.Turista;

public interface IValidador {

	Boolean campoInvalidoAltaUsuario(DtUsuario usuario);

	Boolean campoInvalidoModificarUsuario(DtUsuario usuario);

	Boolean campoInvalidoAltaActividad(DtActividadTuristica actividad);

	Boolean campoInvalidoAltaSalida(DtSalidaTuristica salida);

	Boolean campoInvalidoInscripcionASalida(DtInscripcionSalida inscripcion);
	
	Boolean usuarioYaEstaRegistradoASalida(Turista turista, DtInscripcionSalida nuevaInscripcion);

	Boolean campoInvalidoAltaPaquete(DtPaqueteActividades paquete);
	
}
