package logica.datatypes;

import java.util.Arrays;
import java.util.Date;
import java.util.Objects;

public class DtProveedor extends DtUsuario {
	private String descripcion;
	private String urlSitioWeb;
	private String[] actividadesTuristicas;

	// constructor
	
	public DtProveedor() {
		super();
	}
	
	
	public DtProveedor(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
					   String descripcion, String urlSitioWeb) {
		super(nickname, nombre, apellido, email, fechaNacimiento);
		this.descripcion = descripcion;
		this.urlSitioWeb = urlSitioWeb;
	}

	
	public DtProveedor(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
					   String descripcion, String urlSitioWeb, String[] actividades) {
		super(nickname, nombre, apellido, email, fechaNacimiento);
		this.descripcion = descripcion;
		this.urlSitioWeb = urlSitioWeb;
		this.actividadesTuristicas = actividades;
	}
	
	//setters y getters
	


	public String getDescripcion() {
		if (descripcion == null) {
			return "NO HAY TEXTO";
		} else {
			return descripcion;
		}
		
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUrlSitioWeb() {
		return urlSitioWeb;
	}

	public void setUrlSitioWeb(String urlSitioWeb) {
		this.urlSitioWeb = urlSitioWeb;
	}	
	public String[] getActividadesTuristicas() {
		return actividadesTuristicas;
	}

	public void setActividadesTuristicas(String[] actividadesTuristicas) {
		this.actividadesTuristicas = actividadesTuristicas;
	}
	
	
	// -------------------------------------------------------------------------
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtProveedor other = (DtProveedor) obj;
		return Objects.equals(descripcion, other.descripcion) && Objects.equals(urlSitioWeb, other.urlSitioWeb);
	}


	@Override
	public String toString() {
		return "DtProovedor [descripcion=" + descripcion + ", urlSitioWeb=" + urlSitioWeb + ", actividadesTuristicas="
				+ Arrays.toString(actividadesTuristicas) + ", toString()=" + super.toString() + "]";
	}
	
	


	
	// -------------------------------------------------------------------------
	
	
}
