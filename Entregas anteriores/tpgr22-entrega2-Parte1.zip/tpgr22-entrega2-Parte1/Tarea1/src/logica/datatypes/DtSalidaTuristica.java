package logica.datatypes;

import java.util.Date;
import java.util.Objects;

public class DtSalidaTuristica {

	private String nombreActividad; 
	private String nombreSalida;
	private int cantidadMaximaTuristas;
	private Date fechaAlta;
	private Date fechaSalida;
	private String lugarSalida;
	
	
	//Constructor
	
	
	public DtSalidaTuristica(String nombreActividad, String nombreSalida, int cantidadMaximaTuristas, Date fechaAlta,
			Date fechaSalida, String lugarSalida) {
		this.nombreActividad = nombreActividad;
		this.nombreSalida = nombreSalida;
		this.cantidadMaximaTuristas = cantidadMaximaTuristas;
		this.fechaAlta = fechaAlta;
		this.fechaSalida = fechaSalida;
		this.lugarSalida = lugarSalida;
	}
	
	//Setters y getters
	
	public DtSalidaTuristica() {
		// TODO Auto-generated constructor stub
	}

	public String getNombreActividad() {
		return nombreActividad;
	}


	public void setNombreActividad(String nombreActividad) {
		this.nombreActividad = nombreActividad;
	}


	public String getNombreSalida() {
		return nombreSalida;
	}


	public void setNombreSalida(String nombreSalida) {
		this.nombreSalida = nombreSalida;
	}


	public int getCantidadMaximaTuristas() {
		return this.cantidadMaximaTuristas;
	}


	public void setCantidadMaximaTuristas(int cantidadMaximaTuristas) {
		this.cantidadMaximaTuristas = cantidadMaximaTuristas;
	}


	public Date getFechaAlta() {
		return fechaAlta;
	}


	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}


	public Date getFechaSalida() {
		return fechaSalida;
	}


	public void setFechaSalida(Date fechaSalida) {
		this.fechaSalida = fechaSalida;
	}


	public String getLugarSalida() {
		return lugarSalida;
	}


	public void setLugarSalida(String lugarSalida) {
		this.lugarSalida = lugarSalida;
	}
	
	
	// ----------------------------------------------------------------

	@Override
	public String toString() {
		return "DtSalidaTuristica [nombreActividad=" + nombreActividad + ", nombreSalida=" + nombreSalida
				+ ", cantidadMaximaTuristas=" + cantidadMaximaTuristas + ", fechaAlta=" + fechaAlta + ", fechaSalida="
				+ fechaSalida + ", lugarSalida=" + lugarSalida + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cantidadMaximaTuristas, fechaAlta, fechaSalida, lugarSalida, nombreActividad, nombreSalida);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DtSalidaTuristica other = (DtSalidaTuristica) obj;
		return cantidadMaximaTuristas == other.cantidadMaximaTuristas && Objects.equals(fechaAlta, other.fechaAlta)
				&& Objects.equals(fechaSalida, other.fechaSalida) && Objects.equals(lugarSalida, other.lugarSalida)
				&& Objects.equals(nombreActividad, other.nombreActividad)
				&& Objects.equals(nombreSalida, other.nombreSalida);
	}
	
	
	
}
