package logica.entidades;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import logica.datatypes.DtTurista;
import logica.datatypes.DtUsuario;

public class Turista extends Usuario {

	// Atributos

	private String nacionalidad;
	private Map<Integer, InscripcionSalida> inscripciones = new HashMap<Integer, InscripcionSalida>();
	private Map<Integer, CompraPaquete> paquetes = new HashMap<Integer, CompraPaquete>();

	// Constructores

	public Turista() {
		super();
	}

	public Turista(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
			String nacionalidad) {

		super(nickname, nombre, apellido, email, fechaNacimiento);
		this.nacionalidad = nacionalidad;
	}

	// Getters y setters

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public Map<Integer, InscripcionSalida> getInscripciones() {
		return inscripciones;
	}

	public Map<Integer, CompraPaquete> getPaquetes() {
		return paquetes;
	}

	// -----------------------------------------------------------------

	public void agregarInscripcionASalida(InscripcionSalida inscripcion) {
		this.inscripciones.put(inscripcion.getId(), inscripcion);
	}

	public DtUsuario newDataType() {
		DtTurista res = new DtTurista(this.nickname, this.nombre, this.apellido, this.email, this.fechaNacimiento,
				this.nacionalidad, this.inscripciones);
		return res;
	}

	@Override
	public String toString() {
		return "Turista [nickname=" + nickname + ", email=" + email + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", nacionalidad=" + ", fechaNacimiento=" + fechaNacimiento + nacionalidad + ", inscripciones="
				+ inscripciones + ", paquetes=" + paquetes + "]";
	}

	// -----------------------------------------------------------------

}
