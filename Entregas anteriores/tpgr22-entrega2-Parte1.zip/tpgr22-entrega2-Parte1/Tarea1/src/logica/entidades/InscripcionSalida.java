package logica.entidades;

import java.util.Date;
import java.util.Objects;

public class InscripcionSalida {

	private int id;
	private Date fechaInscripcion;
	private int cantidadTuristas;
	private SalidaTuristica salida;
	private float costoTotal = 0;

	// ----------------------------------------------------------------
	// Constructores

	public InscripcionSalida() {
	}

	public void setCostoTotal(float costoTotal) {
		this.costoTotal = costoTotal;
	}

	public InscripcionSalida(int id, Date fechaInscripcin, int cantidadTuristas, SalidaTuristica salida,
			float costoSalida) {
		this.id = id;
		this.fechaInscripcion = fechaInscripcin;
		this.cantidadTuristas = cantidadTuristas;
		this.salida = salida;
		this.costoTotal = calcularCostoTotal(cantidadTuristas, costoSalida);
	}

	// ----------------------------------------------------------------
	// Getters y Setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getFechaInscripcion() {
		return fechaInscripcion;
	}

	public void setFechaInscripcion(Date fechaInscripcin) {
		this.fechaInscripcion = fechaInscripcin;
	}

	public int getCantidadTuristas() {
		return cantidadTuristas;
	}

	public void setCantidadTuristas(int cantidadTuristas) {
		this.cantidadTuristas = cantidadTuristas;
	}

	public SalidaTuristica getSalida() {
		return salida;
	}

	public void setSalida(SalidaTuristica salida) {
		this.salida = salida;
	}

	public float getCostoTotal() {
		return costoTotal;
	}

	// ----------------------------------------------------------------
	// Otros metodos

	// ----------------------------------------------------------------
	// Metodos auxliares

	private float calcularCostoTotal(int cantidadTuristas, float costoSalida) {
		return (cantidadTuristas * costoSalida);
	}

	// ----------------------------------------------------------------
	// Metodos de sobrecarga

	@Override
	public String toString() {
		return "InscripcionSalida [id=" + id + ", fechaInscripcin=" + fechaInscripcion + ", cantidadTuristas="
				+ cantidadTuristas + ", salida=" + salida + ", costoTotal=" + costoTotal + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cantidadTuristas, costoTotal, fechaInscripcion, id, salida);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InscripcionSalida other = (InscripcionSalida) obj;
		return cantidadTuristas == other.cantidadTuristas
				&& Float.floatToIntBits(costoTotal) == Float.floatToIntBits(other.costoTotal)
				&& Objects.equals(fechaInscripcion, other.fechaInscripcion) && id == other.id
				&& Objects.equals(salida, other.salida);
	};

}
