package logica.entidades;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import logica.datatypes.DtProveedor;
import logica.datatypes.DtUsuario;

public class Proveedor extends Usuario {

	// Atributos
	private String descripcion;
	private String urlSitioWeb;
	private List<ActividadTuristica> actividadesTuristicas = new ArrayList<ActividadTuristica>();

	// Constructor

	public Proveedor() {
		super();
	}

	public Proveedor(String nickname, String nombre, String apellido, String email, Date fechaNacimiento,
			String descripcion, String urlSitioWeb) {
		super(nickname, nombre, apellido, email, fechaNacimiento);

		this.descripcion = descripcion;
		this.urlSitioWeb = urlSitioWeb;

	}

	// Getters y setters

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUrlSitioWeb() {
		return urlSitioWeb;
	}

	public void setUrlSitioWeb(String urlSitioWeb) {
		this.urlSitioWeb = urlSitioWeb;
	}

	public List<ActividadTuristica> getActividadesTuristicas() {
		return actividadesTuristicas;
	}

	public void setActividadesTuristicas(List<ActividadTuristica> actividadesTuristicas) {
		this.actividadesTuristicas = actividadesTuristicas;
	}

	public DtUsuario newDataType() {
		String[] actividades = {};
		if (this.actividadesTuristicas != null) {
			actividades = new String[this.actividadesTuristicas.size()];
			for (int i = 0; i < this.actividadesTuristicas.size(); i++) {
				actividades[i] = this.actividadesTuristicas.get(i).getNombre();
			}
		}

		return new DtProveedor(this.nickname, this.nombre, this.apellido, this.email, this.fechaNacimiento,
				this.descripcion, this.urlSitioWeb, actividades);
	}

	// ---------------------------------------------------------------------------------------------

	public void agregarActividadTuristica(ActividadTuristica nuevaActividad) {
		actividadesTuristicas.add(nuevaActividad);
	}

	// ---------------------------------------------------------------------------------------------

	@Override
	public String toString() {
		return "Proveedor [nickname=" + nickname + ", email=" + email + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", fechaNacimiento=" + fechaNacimiento + ", descripcion=" + descripcion + ", urlSitioWeb="
				+ urlSitioWeb + ", actividadesTuristicas=" + actividadesTuristicas + "]";
	}

}
