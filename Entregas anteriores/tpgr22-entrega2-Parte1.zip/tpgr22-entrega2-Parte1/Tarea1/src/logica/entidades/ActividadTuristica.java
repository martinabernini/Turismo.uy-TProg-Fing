
package logica.entidades;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import logica.datatypes.DtActividadTuristica;

public class ActividadTuristica {
	private String nombre;
	private String descripcion;
	private int duracionHrs;
	private float costoPorPersona;
	private String ciudad;
	private Date fechaAlta;
	private Departamento departamento;
	private Map<String, PaqueteActividades> paquetesAsociados;
	private Map<String, SalidaTuristica> salidasAsociadas;
	private Proveedor proveedor;

	// ----------------------------------------------------------------
	// Constructores

	public ActividadTuristica() {
		this.paquetesAsociados = new HashMap<String, PaqueteActividades>();
		this.salidasAsociadas = new HashMap<String, SalidaTuristica>();
	}

	public ActividadTuristica(String nombre, String descripcion, int duracionHrs, float costoPorPersona, String ciudad,
			Date fechaAlta, Departamento departamento, Proveedor proveedor) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.duracionHrs = duracionHrs;
		this.costoPorPersona = costoPorPersona;
		this.ciudad = ciudad;
		this.fechaAlta = fechaAlta;
		this.departamento = departamento;
		this.paquetesAsociados = new HashMap<String, PaqueteActividades>();
		this.salidasAsociadas = new HashMap<String, SalidaTuristica>();
		this.proveedor = proveedor;
	}

	// ----------------------------------------------------------------
	// Getters y Setters

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getDuracionHrs() {
		return duracionHrs;
	}

	public void setDuracionHrs(int duracionHrs) {
		this.duracionHrs = duracionHrs;
	}

	public float getCostoPorPersona() {
		return costoPorPersona;
	}

	public void setCostoPorPersona(float costoPorPersona) {
		this.costoPorPersona = costoPorPersona;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public Departamento getDepartamento() {
		return departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}

	public Map<String, PaqueteActividades> getPaquetesAsociados() {
		return paquetesAsociados;
	}

	public void setPaquetesAsociados(Map<String, PaqueteActividades> paquetesAsociados) {
		this.paquetesAsociados = paquetesAsociados;
	}

	public Map<String, SalidaTuristica> getSalidasAsociadas() {
		return salidasAsociadas;
	}

	public void setSalidasAsociadas(Map<String, SalidaTuristica> salidasAsociadas) {
		this.salidasAsociadas = salidasAsociadas;
	}

	public Proveedor getProveedor() {
		return proveedor;
	}

	public void setProveedor(Proveedor proveedor) {
		this.proveedor = proveedor;
	}

	// ----------------------------------------------------------------
	// Otros metodos

	public void agregarPaqueteAsociado(PaqueteActividades paquete) {
		this.paquetesAsociados.put(paquete.getNombre(), paquete);
	}

	public void agregarSalidaAsociada(SalidaTuristica salida) {
		this.salidasAsociadas.put(salida.getNombre(), salida);
	}

	public DtActividadTuristica newDataType() {
		DtActividadTuristica actividad = new DtActividadTuristica();
		actividad.setNombre(this.getNombre());
		actividad.setDescripcion(this.getDescripcion());
		actividad.setDuracionHrs(this.getDuracionHrs());
		actividad.setCostoPorPersona(this.getCostoPorPersona());
		actividad.setCiudad(this.getCiudad());
		actividad.setFechaAlta(this.getFechaAlta());
		actividad.setSalidas(salidasAsociadas.keySet().toArray(new String[0]));
		actividad.setDepartamento(this.getDepartamento().getNombre());
		actividad.setProovedor(this.getProveedor().getNickname());
		actividad.setPaquetes(paquetesAsociados.keySet().toArray(new String[0]));
		return actividad;
	}

	// ----------------------------------------------------------------
	// Metodos de sobrecarga
	// Hechos automaticamente con Eclipse en la pestania Source:

	// Source > Generate toString()...
	@Override
	public String toString() {
		return "ActividadTuristica [nombre=" + nombre + ", descripcion=" + descripcion + ", duracionHrs=" + duracionHrs
				+ ", costoPorPersona=" + costoPorPersona + ", ciudad=" + ciudad + ", fechaAlta=" + fechaAlta
				+ ", departamento=" + departamento + ", paquetesAsociados=" + paquetesAsociados.keySet() + ", salidasAsociadas="
				+ salidasAsociadas.keySet() + ", proveedor=" + proveedor.getNombre() + "]";
	}

	// Source > Generate hashCode() and equals()...
	@Override
	public int hashCode() {
		return Objects.hash(ciudad, costoPorPersona, departamento, descripcion, duracionHrs, fechaAlta, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActividadTuristica other = (ActividadTuristica) obj;
		return Objects.equals(ciudad, other.ciudad) && Objects.equals(costoPorPersona, other.costoPorPersona)
				&& Objects.equals(departamento, other.departamento) && Objects.equals(descripcion, other.descripcion)
				&& Objects.equals(duracionHrs, other.duracionHrs) && Objects.equals(fechaAlta, other.fechaAlta)
				&& Objects.equals(nombre, other.nombre);
	}

}
