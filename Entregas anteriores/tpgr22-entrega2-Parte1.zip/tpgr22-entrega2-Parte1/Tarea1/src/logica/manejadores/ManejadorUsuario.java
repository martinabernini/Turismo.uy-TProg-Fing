package logica.manejadores;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import logica.entidades.Proveedor;
import logica.entidades.Turista;
import logica.entidades.Usuario;
import logica.interfaces.IManejadorUsuario;

public class ManejadorUsuario implements IManejadorUsuario {

	private Map<String, Usuario> usuarios;
	private Set<String> emailRegistrado;

	private static ManejadorUsuario instancia = null;

	private ManejadorUsuario() {
		usuarios = new HashMap<>();
		emailRegistrado = new HashSet<>();
	}

	public static ManejadorUsuario getInstance() {
		if (instancia == null)
			instancia = new ManejadorUsuario();

		return instancia;
	}

	public void add(Usuario usuario) {
		usuarios.put(usuario.getNickname(), usuario);
		emailRegistrado.add(usuario.getEmail());
	}

	public void update(Usuario usuario) {
		usuarios.put(usuario.getNickname(), usuario);
	}

	public Usuario[] getAll() {
		if (usuarios.isEmpty()) {
			return null;
		}

		return usuarios.values().toArray(new Usuario[0]);
	}

	public Usuario find(String nickname) {
		return usuarios.get(nickname);
	}

	public boolean contains(String nickname) {
		return usuarios.containsKey(nickname);
	}

	public Proveedor[] getAllProveedores() {

		List<Proveedor> listaProveedores = new ArrayList<>();

		for (Usuario usuario : usuarios.values()) {
			if (usuario instanceof Proveedor) {
				listaProveedores.add((Proveedor) usuario);
			}
		}

		return listaProveedores.toArray(new Proveedor[0]);
	}

	public Turista[] getAllTuristas() {

		List<Turista> listaTuristas = new ArrayList<>();

		for (Usuario usuario : usuarios.values()) {
			if (usuario instanceof Turista) {
				listaTuristas.add((Turista) usuario);
			}
		}

		return listaTuristas.toArray(new Turista[0]);
	}

	public boolean emailYaRegistrado(String email) {
		return emailRegistrado.contains(email);
	}

}
