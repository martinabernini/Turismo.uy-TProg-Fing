package logica.manejadores;

import java.util.HashMap;
import java.util.Map;

import logica.entidades.ActividadTuristica;
import logica.interfaces.IManejadorActividadTuristica;
import logica.interfaces.IManejadorDepartamento;

public final class ManejadorActividadTuristica implements IManejadorActividadTuristica {

	private Map<String, ActividadTuristica> actividades;

	private static IManejadorDepartamento manejadorDepartamento;

	private static ManejadorActividadTuristica instancia = null;

	public static ManejadorActividadTuristica getInstance(IManejadorDepartamento manejadorDepartamento) {
		if (instancia == null)
			instancia = new ManejadorActividadTuristica();

		ManejadorActividadTuristica.manejadorDepartamento = manejadorDepartamento;

		return instancia;
	}

	private ManejadorActividadTuristica() {
		actividades = new HashMap<>();
	}

	// ---------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------

	public void add(ActividadTuristica actividad) {
		this.actividades.put(actividad.getNombre(), actividad);
	}

	public void update(ActividadTuristica actividad) {
		this.actividades.put(actividad.getNombre(), actividad);
	}

	public ActividadTuristica[] getAll() {
		if (actividades.isEmpty())
			return null;
		return actividades.values().toArray(new ActividadTuristica[0]);
	}

	public ActividadTuristica find(String nombre) {
		return actividades.get(nombre);
	}

	public Boolean contains(String nombreActividad) {
		return actividades.containsKey(nombreActividad);
	}

	public ActividadTuristica[] getAllAsociadasADepartamento(String nombreDepto) {
		return manejadorDepartamento.getAllActividadesAsociadasADepartamento(nombreDepto);
	}

	public ActividadTuristica[] getAllAsociadasADepartamentoNoEnPaquete(String nombreDepto, String nombrePaquete) {
		return manejadorDepartamento.getAllActividadesAsociadasADepartamentoNoEnPaquete(nombreDepto, nombrePaquete);
	}

}
