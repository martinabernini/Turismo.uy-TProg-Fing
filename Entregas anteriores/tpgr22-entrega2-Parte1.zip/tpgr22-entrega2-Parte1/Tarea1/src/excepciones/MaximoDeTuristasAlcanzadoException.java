package excepciones;

public class MaximoDeTuristasAlcanzadoException extends Exception{
	public MaximoDeTuristasAlcanzadoException(String string) {
		super(string);
	}
	
}
