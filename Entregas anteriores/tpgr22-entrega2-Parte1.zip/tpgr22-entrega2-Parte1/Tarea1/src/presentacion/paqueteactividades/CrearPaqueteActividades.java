package presentacion.paqueteactividades;

import javax.swing.JInternalFrame;

import logica.interfaces.IControladorPaqueteActividades;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

public class CrearPaqueteActividades extends JInternalFrame {
	
	IControladorPaqueteActividades controladorPaqueteActividades;
	
	public CrearPaqueteActividades(IControladorPaqueteActividades controladorPaqueteActividades) {
		
		this.controladorPaqueteActividades = controladorPaqueteActividades;
		
		setResizable(true);
        setIconifiable(true);
        setMaximizable(true);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setClosable(true);
        setTitle("Crear paquete de actividades turisticas");
        setBounds(10, 40, 508, 268);
        getContentPane().setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Proximamente");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel.setBounds(85, 53, 291, 119);
        getContentPane().add(lblNewLabel);
	}
	
	
}