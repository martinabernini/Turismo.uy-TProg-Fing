package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import excepciones.CampoInvalidoException;
import logica.entidades.Departamento;
import logica.interfaces.IControladorDepartamento;
import utils.Fabrica;

class ControladorDepartamentoTest {

	private static IControladorDepartamento controladorDepartamento;
	private static String nombreDepto = "nombre de prueba";
	private static String descripcionDepto = "nombre de prueba";
	private static String urlDepto = "url";
	
	@BeforeAll
	public static void start() {
		Fabrica f = Fabrica.getInstance();
		controladorDepartamento = f.getIControladorDepartamento();
	}

	@Test
	void cuandoEstanLosCamposLlenos_AgregaYDevuelveBienUnDepartamento() {
		try {
			controladorDepartamento.darDeAltaDepartamento(nombreDepto, descripcionDepto, urlDepto);
			String[] devueltos = controladorDepartamento.listarDepartamentos();
			
			Boolean estaEnResultado = false;
			
			for (String depto: devueltos) {
				if (depto == nombreDepto) {
					estaEnResultado = true;
				}
			}
			
			assertTrue(estaEnResultado);

		} catch (Exception e) {
			fail("Se tira error cuando no se tenia que tirar");
		}
	}
	
	@Test
	void cuandoHayAlgunCampoVacio_TiraError() {
			assertThrows(CampoInvalidoException.class, () -> {
				controladorDepartamento.darDeAltaDepartamento("", "", "");
			});

	}
	
	@Test
	void chequearEquals() {
			Departamento dep= new Departamento("nombre de prueba", "depD", "depUrl");
			Departamento dep1= new Departamento(nombreDepto, descripcionDepto, urlDepto);
			
			assertEquals(false, dep.equals(dep1));
	}
}
