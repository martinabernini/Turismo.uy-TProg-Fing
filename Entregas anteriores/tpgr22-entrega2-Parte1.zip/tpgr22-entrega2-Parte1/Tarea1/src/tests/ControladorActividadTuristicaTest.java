package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import excepciones.CampoInvalidoException;
import excepciones.EntidadNoExisteException;
import excepciones.EntidadRepetidaException;
import excepciones.NoHayEntidadesParaListarException;
import logica.datatypes.DtActividadTuristica;
import logica.entidades.ActividadTuristica;
import logica.interfaces.IControladorActividadTuristica;
import utils.Fabrica;

class ControladorActividadTuristicaTest {

	public static IControladorActividadTuristica ctrlActividad;

	@BeforeAll
	public static void start() {
		Fabrica f = Fabrica.getInstance();
		ctrlActividad = f.getIControladorActividadTuristica();
		f.getICargaDatos().cargar();
	}
	
	@Test
	void campoVacioAlAgregar_TiraExcepcionCorrecta() {
		DtActividadTuristica nuevaActividad = new DtActividadTuristica();
		nuevaActividad.setCiudad("solymar");
		nuevaActividad.setDepartamento("");
		nuevaActividad.setCostoPorPersona(5);
		nuevaActividad.setDescripcion("descripcion");
		nuevaActividad.setDuracionHrs(7);
		nuevaActividad.setProovedor("meche");
		nuevaActividad.setNombre("");
		nuevaActividad.setFechaAlta(new Date(2323223232L));

		assertThrows(CampoInvalidoException.class,
				() -> ctrlActividad.darDeAltaActividadTuristica(nuevaActividad));
	}
	
	@Test
	void todosCampoVaciosAlAgregar_TiraExcepcionCorrecta() {
		DtActividadTuristica nuevaActividad = new DtActividadTuristica();
		nuevaActividad.setCiudad("");
		nuevaActividad.setDepartamento("");
		nuevaActividad.setCostoPorPersona(0);
		nuevaActividad.setDescripcion("");
		nuevaActividad.setDuracionHrs(0);
		nuevaActividad.setProovedor("");
		nuevaActividad.setNombre("");
		nuevaActividad.setFechaAlta(new Date(2323223232L));

		assertThrows(CampoInvalidoException.class,
				() -> ctrlActividad.darDeAltaActividadTuristica(nuevaActividad));
	}
	

	@Test
	void campoVacioAlConsultarAsociadasADepartamento_TiraExcepcionCorrecta() {
		assertThrows(CampoInvalidoException.class,
				() -> ctrlActividad.listarActividadesAsociadasADepartamento(""));
	}

	@Test
	void consultaPorAsociadasADepartamentoValidoQueNoTiene_TiraExcepcionCorrecta() {
		assertThrows(NoHayEntidadesParaListarException.class,
				() -> ctrlActividad.listarActividadesAsociadasADepartamento("soriano"));
	}

	@Test
	void consultaPorAsociadasADepartamentoQueExisteYTiene_ListaBien() {
		Set<String> esperadas = new HashSet<String>();
		esperadas.add("almuerzo en valle del lunarejo");
		esperadas.add("cabalgata en valle del lunarejo");

		Set<String> obtenidas = new HashSet<String>();
		try {
			for (String actividadObtenida : ctrlActividad.listarActividadesAsociadasADepartamento("rivera")) {
				obtenidas.add(actividadObtenida);
			}
			assertEquals(esperadas, obtenidas);

		} catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
			fail();
		}
	}
	
	@Test
	void agregarActividadConMismoNombre_TiraErrorCorrecto() {

		DtActividadTuristica nuevaActividad = new DtActividadTuristica();
		nuevaActividad.setNombre("degusta");
		nuevaActividad.setDescripcion("descripcion");
		nuevaActividad.setDuracionHrs(7);
		nuevaActividad.setCostoPorPersona(5);
		nuevaActividad.setCiudad("aduasdasd");
		nuevaActividad.setFechaAlta(new Date(2323223232L));
		nuevaActividad.setDepartamento("canelones");
		nuevaActividad.setProovedor("meche");
		
		assertThrows(EntidadRepetidaException.class, () -> ctrlActividad.darDeAltaActividadTuristica(nuevaActividad));
	}

	@Test
	void cuandoDatosCorrectos_SeListanAsociadasADeptoNoEnPaqueteCorrectamente() {
		Set<String> esperadas = new HashSet<String>();
		esperadas.add("almuerzo en valle del lunarejo");
		esperadas.add("cabalgata en valle del lunarejo");

		Set<String> obtenidas = new HashSet<String>();
		try {
			for (String actividadObtenida : ctrlActividad
					.listarActividadesAsocadasADepartamentoNoEnPaquete("rivera", "paquete que no existe")) {
				obtenidas.add(actividadObtenida);
			}
			assertEquals(esperadas, obtenidas);

		} catch (NoHayEntidadesParaListarException | CampoInvalidoException e) {
			fail(e.getMessage());
		}
	}

	@Test
	void cuandoCamposValidos_AgregaYObtieneCorrectamenteUnaActividad() {
		// Arrange
		DtActividadTuristica nuevaActividad = new DtActividadTuristica();
		nuevaActividad.setCiudad("solymar");
		nuevaActividad.setDepartamento("canelones");
		nuevaActividad.setCostoPorPersona(5);
		nuevaActividad.setDescripcion("descripcion");
		nuevaActividad.setDuracionHrs(7);
		nuevaActividad.setProovedor("meche");
		nuevaActividad.setNombre("nombre test");
		nuevaActividad.setFechaAlta(new Date(2323223232L));

		// Act
		try {
			ctrlActividad.darDeAltaActividadTuristica(nuevaActividad);
			DtActividadTuristica obtenida = ctrlActividad.getActividadTuristica("nombre test");

			// Assert
			assertEquals(nuevaActividad, obtenida);
			

		} catch (EntidadRepetidaException | CampoInvalidoException | EntidadNoExisteException e) {
			fail(e.getMessage());
		}
	}	
	
	@Test 
	void testEquals() {
		Date fecha= new Date(2323223232L);
		ActividadTuristica act1= new ActividadTuristica("nombre", "descripcion", 2, 200 , "ciudad",
				fecha, null ,  null);
		ActividadTuristica act2= new ActividadTuristica("nombree", "descripcionn", 2, 200 , "ciudadd",
				fecha, null ,  null);
		ActividadTuristica act3= new ActividadTuristica("nombre", "descripcion", 2, 200 , "ciudad",
				fecha, null ,  null);
		ActividadTuristica act4= new ActividadTuristica();
		
		assertEquals(true, act1.equals(act1));
		assertEquals(true, act1.equals(act3));
		assertEquals(false, act1.equals(act2));
		assertEquals(false, act1.equals(null));
		assertEquals(false,act1.equals(fecha));
	}

}
